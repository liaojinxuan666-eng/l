#!/bin/sh
set -eu
cd '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng'
[ "$(cksum < 'game/text/TextFile.h' | awk '{print $1 " " $2}')" = '1167145862 9043' ] || { echo 'STOP: external edit preserved: game/text/TextFile.h'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M02' 'game/text/TextFile.h'
[ "$(cksum < 'game/network/General/NetworkSerialisers.h' | awk '{print $1 " " $2}')" = '910721013 14803' ] || { echo 'STOP: external edit preserved: game/network/General/NetworkSerialisers.h'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M05' 'game/network/General/NetworkSerialisers.h'
[ "$(cksum < 'game/ai/debug/types/VehicleDebugInfo.h' | awk '{print $1 " " $2}')" = '1866653188 5965' ] || { echo 'STOP: external edit preserved: game/ai/debug/types/VehicleDebugInfo.h'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M06' 'game/ai/debug/types/VehicleDebugInfo.h'
[ "$(cksum < 'game/script/commands_ped.cpp' | awk '{print $1 " " $2}')" = '2110513725 559956' ] || { echo 'STOP: external edit preserved: game/script/commands_ped.cpp'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M07' 'game/script/commands_ped.cpp'
[ "$(cksum < 'game/event/Events.cpp' | awk '{print $1 " " $2}')" = '3109867177 207689' ] || { echo 'STOP: external edit preserved: game/event/Events.cpp'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M08' 'game/event/Events.cpp'
[ "$(cksum < 'game/Peds/Ped.cpp' | awk '{print $1 " " $2}')" = '2456424850 1294882' ] || { echo 'STOP: external edit preserved: game/Peds/Ped.cpp'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M09' 'game/Peds/Ped.cpp'
[ "$(cksum < 'game/renderer/rendertargets.h' | awk '{print $1 " " $2}')" = '3656637107 28831' ] || { echo 'STOP: external edit preserved: game/renderer/rendertargets.h'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M10' 'game/renderer/rendertargets.h'
[ "$(cksum < 'rage/framework/src/fwtl/customvertexpushbuffer.h' | awk '{print $1 " " $2}')" = '2082042855 39194' ] || { echo 'STOP: external edit preserved: rage/framework/src/fwtl/customvertexpushbuffer.h'; exit 2; }
cp -p '/private/var/mobile/Containers/Data/Application/7761C3F3-4061-4FEE-85A6-6CB74113D1B3/Documents/myFolder/GTAVSP/GTAV Source/src/dev_ng/rage/base/src/ios_port_fixer_app.q0jct7/before/M11' 'rage/framework/src/fwtl/customvertexpushbuffer.h'
[ "$(cksum < 'game/Peds/CombatData.h' | awk '{print $1 " " $2}')" = '1995586045 22857' ] || { echo 'STOP: external edit preserved: game/Peds/CombatData.h'; exit 2; }
rm -f 'game/Peds/CombatData.h'
[ "$(cksum < 'game/Peds/CombatData.cpp' | awk '{print $1 " " $2}')" = '1275136991 1239' ] || { echo 'STOP: external edit preserved: game/Peds/CombatData.cpp'; exit 2; }
rm -f 'game/Peds/CombatData.cpp'
[ "$(cksum < 'game/Peds/CombatData_parser.h' | awk '{print $1 " " $2}')" = '2307467002 15755' ] || { echo 'STOP: external edit preserved: game/Peds/CombatData_parser.h'; exit 2; }
rm -f 'game/Peds/CombatData_parser.h'
[ "$(cksum < 'game/scene/loader/MapData_Misc.h' | awk '{print $1 " " $2}')" = '853658687 6391' ] || { echo 'STOP: external edit preserved: game/scene/loader/MapData_Misc.h'; exit 2; }
rm -f 'game/scene/loader/MapData_Misc.h'
[ "$(cksum < 'game/scene/loader/MapData_Misc.cpp' | awk '{print $1 " " $2}')" = '3861395456 2647' ] || { echo 'STOP: external edit preserved: game/scene/loader/MapData_Misc.cpp'; exit 2; }
rm -f 'game/scene/loader/MapData_Misc.cpp'
[ "$(cksum < 'game/scene/loader/MapData_Misc_parser.h' | awk '{print $1 " " $2}')" = '896353921 51544' ] || { echo 'STOP: external edit preserved: game/scene/loader/MapData_Misc_parser.h'; exit 2; }
rm -f 'game/scene/loader/MapData_Misc_parser.h'
[ "$(cksum < 'game/Vehicles/Metadata/VehicleEnterExitFlags.h' | awk '{print $1 " " $2}')" = '4213405568 16950' ] || { echo 'STOP: external edit preserved: game/Vehicles/Metadata/VehicleEnterExitFlags.h'; exit 2; }
rm -f 'game/Vehicles/Metadata/VehicleEnterExitFlags.h'
[ "$(cksum < 'game/Vehicles/Metadata/VehicleEnterExitFlags.cpp' | awk '{print $1 " " $2}')" = '3205255869 1315' ] || { echo 'STOP: external edit preserved: game/Vehicles/Metadata/VehicleEnterExitFlags.cpp'; exit 2; }
rm -f 'game/Vehicles/Metadata/VehicleEnterExitFlags.cpp'
[ "$(cksum < 'game/Vehicles/Metadata/VehicleEnterExitFlags_parser.h' | awk '{print $1 " " $2}')" = '2737481575 8428' ] || { echo 'STOP: external edit preserved: game/Vehicles/Metadata/VehicleEnterExitFlags_parser.h'; exit 2; }
rm -f 'game/Vehicles/Metadata/VehicleEnterExitFlags_parser.h'
[ "$(cksum < 'game/animation/AnimScene/AnimSceneEntityTypes.h' | awk '{print $1 " " $2}')" = '1231365095 2195' ] || { echo 'STOP: external edit preserved: game/animation/AnimScene/AnimSceneEntityTypes.h'; exit 2; }
rm -f 'game/animation/AnimScene/AnimSceneEntityTypes.h'
[ "$(cksum < 'game/animation/AnimScene/AnimSceneEntityTypes.cpp' | awk '{print $1 " " $2}')" = '2818693551 1314' ] || { echo 'STOP: external edit preserved: game/animation/AnimScene/AnimSceneEntityTypes.cpp'; exit 2; }
rm -f 'game/animation/AnimScene/AnimSceneEntityTypes.cpp'
[ "$(cksum < 'game/animation/AnimScene/AnimSceneEntityTypes_parser.h' | awk '{print $1 " " $2}')" = '1805496181 3289' ] || { echo 'STOP: external edit preserved: game/animation/AnimScene/AnimSceneEntityTypes_parser.h'; exit 2; }
rm -f 'game/animation/AnimScene/AnimSceneEntityTypes_parser.h'
[ "$(cksum < 'game/system/control_mapping.h' | awk '{print $1 " " $2}')" = '687071075 61135' ] || { echo 'STOP: external edit preserved: game/system/control_mapping.h'; exit 2; }
rm -f 'game/system/control_mapping.h'
[ "$(cksum < 'game/system/control_mapping.cpp' | awk '{print $1 " " $2}')" = '2264959710 8568' ] || { echo 'STOP: external edit preserved: game/system/control_mapping.cpp'; exit 2; }
rm -f 'game/system/control_mapping.cpp'
[ "$(cksum < 'game/system/control_mapping_parser.h' | awk '{print $1 " " $2}')" = '3116796350 218033' ] || { echo 'STOP: external edit preserved: game/system/control_mapping_parser.h'; exit 2; }
rm -f 'game/system/control_mapping_parser.h'
echo 'ROLLBACK_COMPLETE'
