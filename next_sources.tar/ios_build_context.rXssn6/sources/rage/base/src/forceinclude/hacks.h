#define HACK_GTA4	1
#define HACK_MC4	0
#define HACK_RDR2	0
#define HACK_MP3	0
#define HACK_JIMMY	0
#define HACK_BULLY2	0
#define HACK_MC5	0
#define HACK_RDR3	0

#define GTA_VERSION 501
#define RDR_VERSION 0
