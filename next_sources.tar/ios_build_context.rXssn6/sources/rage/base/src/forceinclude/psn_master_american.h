#include "psn_final.h"
#define __MASTER			1
#define __GERMAN_BUILD		0
#define __EUROPEAN_BUILD	0
#define __AMERICAN_BUILD	1
#define __JAPANESE_BUILD	0
#define __AUSSIE_BUILD		0
