#ifdef USING_RAGE
using namespace rage;
#endif // USING_RAGE

#endif //_RSG_FORCE_INCLUDE_