// Build type definitions
#define __DEV		1
#define __OPTIMIZED	1
#define __BANK		1
#define __ASSERT	1
#define __FINAL		0
#define __MASTER	0
#define __EDITOR	0
#define __TOOL		1
#define __EXPORTER	0
#define	__PROFILE	0
