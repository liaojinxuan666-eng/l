#define RAGE_RELEASE            378
#define RAGE_RELEASE_STRING     "378"
#define RAGE_MAJOR_VERSION      1
#define RAGE_MINOR_VERSION      15
