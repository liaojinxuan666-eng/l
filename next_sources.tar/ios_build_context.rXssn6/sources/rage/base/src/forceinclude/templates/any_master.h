// Build type definitions
#define __DEV		0
#define __OPTIMIZED	1
#define __BANK		0
#define __ASSERT	0
#define __FINAL		1
#define __MASTER	1
#define __EDITOR	0
#define __TOOL		0
#define __EXPORTER	0
#define	__PROFILE	0
