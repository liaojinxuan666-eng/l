fp_sum() { cksum < "$1" | awk '{print $1 " " $2}'; }
fp_safe() {
    fp_part=$1
    case "$fp_part" in ''|/*|../*|*/../*|*/..|./*|*/./*) return 1 ;; esac
    while :; do
        [ ! -L "$fp_part" ] || return 1
        case "$fp_part" in */*) fp_part=${fp_part%/*} ;; *) break ;; esac
    done
}
fp_restore_all() {
    fp_restore_failed=0
    while IFS='|' read -r fp_id fp_path fp_pre fp_post; do
        [ -n "$fp_id" ] || continue
        if [ "$fp_pre" != ABSENT ]; then
            echo 'RESTORE_SKIPPED: unexpected pre-existing output record.'; fp_restore_failed=1; continue
        fi
        if ! fp_safe "$fp_path"; then
            printf 'RESTORE_SKIPPED: unsafe %s\n' "$fp_path"; fp_restore_failed=1; continue
        fi
        if [ "$(fp_sum "$fp_out/candidate/$fp_id.h")" != "$fp_post" ]; then
            echo 'RESTORE_SKIPPED: candidate integrity failed.'; fp_restore_failed=1; continue
        fi
        if [ ! -e "$fp_path" ]; then continue; fi
        if [ ! -f "$fp_out/published/$fp_id" ] || [ -L "$fp_out/published/$fp_id" ] ||
           [ ! "$fp_path" -ef "$fp_out/published/$fp_id" ]; then
            printf 'RESTORE_SKIPPED: output ownership changed: %s\n' "$fp_path"; fp_restore_failed=1; continue
        fi
        if [ ! -f "$fp_path" ] || ! cmp -s "$fp_path" "$fp_out/candidate/$fp_id.h"; then
            printf 'RESTORE_SKIPPED: external edit preserved in %s\n' "$fp_path"; fp_restore_failed=1; continue
        fi
        if rm "$fp_path"; then printf 'REMOVED_CREATED_OUTPUT: %s\n' "$fp_path"; else fp_restore_failed=1; fi
    done < "$fp_out/metadata/armed.txt"
    if [ "$fp_restore_failed" -eq 0 ]; then : > "$fp_out/metadata/armed.txt"; return 0; fi
    return 1
}
