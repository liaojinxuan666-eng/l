#include "input/mapper_defs.h"
namespace iosMapperReference {
enum ioMapperSource {
    IOMS_UNDEFINED = -1,
    IOMS_KEYBOARD,
    IOMS_MOUSE_ABSOLUTEAXIS,
    IOMS_MOUSE_CENTEREDAXIS,
    IOMS_MOUSE_RELATIVEAXIS,
    IOMS_MOUSE_SCALEDAXIS,
    IOMS_MOUSE_NORMALIZED,
    IOMS_MOUSE_WHEEL,
    IOMS_MOUSE_BUTTON,
    IOMS_MOUSE_BUTTONANY,
    IOMS_PAD_DIGITALBUTTON,
    IOMS_PAD_DIGITALBUTTONANY,
    IOMS_PAD_ANALOGBUTTON,
    IOMS_PAD_AXIS,
    IOMS_JOYSTICK_BUTTON,
    IOMS_JOYSTICK_AXIS,
    IOMS_JOYSTICK_IAXIS,
    IOMS_JOYSTICK_AXIS_NEGATIVE,
    IOMS_JOYSTICK_AXIS_POSITIVE,
    IOMS_JOYSTICK_POV,
    IOMS_JOYSTICK_POV_AXIS,
    IOMS_PAD_DEBUGBUTTON,
    IOMS_DIGITALBUTTON_AXIS,
    IOMS_MKB_AXIS,
    IOMS_TOUCHPAD_ABSOLUTE_AXIS,
    IOMS_TOUCHPAD_CENTERED_AXIS,
    IOMS_GAME_CONTROLLED,
    IOMS_FORCE32 = 0x7FFFFFFF,
};
enum ioConstants {
    IOMC_MKB_AXIS_MASK = 0x000FF,
    IOMC_MKB_POSITIVE_AXIS_SHIFT = 0x00008,
    IOMC_MKB_AXIS_NEGATIVE_IS_MOUSE = 0x10000,
    IOMC_MKB_AXIS_POSITIVE_IS_MOUSE = 0x20000,
    IOMC_MKB_AXIS_NEGATIVE_IS_WHEEL = 0x40000,
    IOMC_MKB_AXIS_POSITIVE_IS_WHEEL = 0x80000,
};
enum ioParameterMask {
    IOMT_KEYBOARD = 0x00000000,
    IOMT_MOUSE_AXIS = 0x00000200,
    IOMT_MOUSE_WHEEL = 0x00000400,
    IOMT_MOUSE_BUTTON = 0x00000800,
    IOMT_PAD_AXIS = 0x00001000,
    IOMT_PAD_INDEX = 0x00002000,
    IOMT_JOYSTICK_POV = 0x00004000,
    IOMT_JOYSTICK_BUTTON = 0x00008000,
    IOMT_JOYSTICK_AXIS = 0x00010000,
    IOMT_PAD_BUTTON = 0x00020000,
    IOMT_JOYSTICK_AXIS_NEGATIVE = 0x00040000,
    IOMT_JOYSTICK_AXIS_POSITIVE = 0x00080000,
};
enum ioMapperParameter {
    KEY_NULL = 0x00,
    KEY_BACK = 0x08,
    KEY_TAB = 0x09,
    KEY_RETURN = 0x0D,
    KEY_PAUSE = 0x13,
    KEY_CAPITAL = 0x14,
    KEY_ESCAPE = 0x1B,
    KEY_SPACE = 0x20,
    KEY_PAGEUP = 0x21,
    KEY_PRIOR = 0x21,
    KEY_PAGEDOWN = 0x22,
    KEY_NEXT = 0x22,
    KEY_END = 0x23,
    KEY_HOME = 0x24,
    KEY_LEFT = 0x25,
    KEY_UP = 0x26,
    KEY_RIGHT = 0x27,
    KEY_DOWN = 0x28,
    KEY_SNAPSHOT = 0x2C,
    KEY_SYSRQ = 0x2C,
    KEY_INSERT = 0x2D,
    KEY_DELETE = 0x2E,
    KEY_0 = 0x30,
    KEY_1 = 0x31,
    KEY_2 = 0x32,
    KEY_3 = 0x33,
    KEY_4 = 0x34,
    KEY_5 = 0x35,
    KEY_6 = 0x36,
    KEY_7 = 0x37,
    KEY_8 = 0x38,
    KEY_9 = 0x39,
    KEY_A = 0x41,
    KEY_B = 0x42,
    KEY_C = 0x43,
    KEY_D = 0x44,
    KEY_E = 0x45,
    KEY_F = 0x46,
    KEY_G = 0x47,
    KEY_H = 0x48,
    KEY_I = 0x49,
    KEY_J = 0x4A,
    KEY_K = 0x4B,
    KEY_L = 0x4C,
    KEY_M = 0x4D,
    KEY_N = 0x4E,
    KEY_O = 0x4F,
    KEY_P = 0x50,
    KEY_Q = 0x51,
    KEY_R = 0x52,
    KEY_S = 0x53,
    KEY_T = 0x54,
    KEY_U = 0x55,
    KEY_V = 0x56,
    KEY_W = 0x57,
    KEY_X = 0x58,
    KEY_Y = 0x59,
    KEY_Z = 0x5A,
    KEY_LWIN = 0x5B,
    KEY_RWIN = 0x5C,
    KEY_APPS = 0x5D,
    KEY_NUMPAD0 = 0x60,
    KEY_NUMPAD1 = 0x61,
    KEY_NUMPAD2 = 0x62,
    KEY_NUMPAD3 = 0x63,
    KEY_NUMPAD4 = 0x64,
    KEY_NUMPAD5 = 0x65,
    KEY_NUMPAD6 = 0x66,
    KEY_NUMPAD7 = 0x67,
    KEY_NUMPAD8 = 0x68,
    KEY_NUMPAD9 = 0x69,
    KEY_MULTIPLY = 0x6A,
    KEY_ADD = 0x6B,
    KEY_SUBTRACT = 0x6D,
    KEY_DECIMAL = 0x6E,
    KEY_DIVIDE = 0x6F,
    KEY_F1 = 0x70,
    KEY_F2 = 0x71,
    KEY_F3 = 0x72,
    KEY_F4 = 0x73,
    KEY_F5 = 0x74,
    KEY_F6 = 0x75,
    KEY_F7 = 0x76,
    KEY_F8 = 0x77,
    KEY_F9 = 0x78,
    KEY_F10 = 0x79,
    KEY_F11 = 0x7A,
    KEY_F12 = 0x7B,
    KEY_F13 = 0x7C,
    KEY_F14 = 0x7D,
    KEY_F15 = 0x7E,
    KEY_F16 = 0x7F,
    KEY_F17 = 0x80,
    KEY_F18 = 0x81,
    KEY_F19 = 0x82,
    KEY_F20 = 0x83,
    KEY_F21 = 0x84,
    KEY_F22 = 0x85,
    KEY_F23 = 0x86,
    KEY_F24 = 0x87,
    KEY_NUMLOCK = 0x90,
    KEY_SCROLL = 0x91,
    KEY_NUMPADEQUALS = 0x92,
    KEY_LSHIFT = 0xA0,
    KEY_RSHIFT = 0xA1,
    KEY_LCONTROL = 0xA2,
    KEY_RCONTROL = 0xA3,
    KEY_LMENU = 0xA4,
    KEY_RMENU = 0xA5,
    KEY_SEMICOLON = 0xBA,
    KEY_OEM_1 = 0xBA,
    KEY_PLUS = 0xBB,
    KEY_EQUALS = 0xBB,
    KEY_COMMA = 0xBC,
    KEY_MINUS = 0xBD,
    KEY_PERIOD = 0xBE,
    KEY_SLASH = 0xBF,
    KEY_OEM_2 = 0xBF,
    KEY_GRAVE = 0xC0,
    KEY_OEM_3 = 0xC0,
    KEY_LBRACKET = 0xDB,
    KEY_OEM_4 = 0xDB,
    KEY_BACKSLASH = 0xDC,
    KEY_OEM_5 = 0xDC,
    KEY_RBRACKET = 0xDD,
    KEY_OEM_6 = 0xDD,
    KEY_APOSTROPHE = 0xDE,
    KEY_OEM_7 = 0xDE,
    KEY_OEM_102 = 0xE2,
    KEY_RAGE_EXTRA1 = 0xF0,
    KEY_RAGE_EXTRA2 = 0xF1,
    KEY_RAGE_EXTRA3 = 0xF2,
    KEY_RAGE_EXTRA4 = 0xF4,
    KEY_NUMPADENTER = 0xFD,
    KEY_CHATPAD_GREEN_SHIFT = 0xFE,
    KEY_CHATPAD_ORANGE_SHIFT = 0xFF,
    IOM_AXIS_UNDEFINED = -1,
    IOM_UNDEFINED = -1,
    IOM_WHEEL_UNDEFINED = -1,
    IOM_POV_UNDEFINED = -1,
    IOM_ANY_BUTTON = -1,
    IOM_AXIS_X = iosMapperReference::IOMT_MOUSE_AXIS,
    IOM_AXIS_Y,
    IOM_IAXIS_X,
    IOM_IAXIS_Y,
    BASIC_MOUSE_AXIS_MAX,
    IOM_AXIS_X_LEFT,
    IOM_AXIS_X_RIGHT,
    IOM_AXIS_Y_UP,
    IOM_AXIS_Y_DOWN,
    MOUSE_AXIS_MAX,
    IOM_WHEEL_UP = iosMapperReference::IOMT_MOUSE_WHEEL,
    IOM_WHEEL_DOWN,
    IOM_AXIS_WHEEL_DELTA,
    IOM_IAXIS_WHEEL_DELTA,
    IOM_AXIS_WHEEL,
    IOM_IAXIS_WHEEL,
    IOM_AXIS_WHEEL_RELATIVE,
    IOM_IAXIS_WHEEL_RELATIVE,
    MOUSE_LEFT = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_LEFT,
    MOUSE_RIGHT = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_RIGHT,
    MOUSE_MIDDLE = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_MIDDLE,
    MOUSE_EXTRABTN1 = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_EXTRABTN1,
    MOUSE_EXTRABTN2 = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_EXTRABTN2,
    MOUSE_EXTRABTN3 = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_EXTRABTN3,
    MOUSE_EXTRABTN4 = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_EXTRABTN4,
    MOUSE_EXTRABTN5 = iosMapperReference::IOMT_MOUSE_BUTTON | rage::ioMouse::MOUSE_EXTRABTN5,
    L2 = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::L2_INDEX,
    R2 = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::R2_INDEX,
    L1 = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::L1_INDEX,
    R1 = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::R1_INDEX,
    RUP = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::RUP_INDEX,
    RRIGHT = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::RRIGHT_INDEX,
    RDOWN = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::RDOWN_INDEX,
    RLEFT = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::RLEFT_INDEX,
    SELECT = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::SELECT_INDEX,
    L3 = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::L3_INDEX,
    R3 = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::R3_INDEX,
    START = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::START_INDEX,
    LUP = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::LUP_INDEX,
    LRIGHT = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::LRIGHT_INDEX,
    LDOWN = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::LDOWN_INDEX,
    LLEFT = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::LLEFT_INDEX,
    TOUCH = iosMapperReference::IOMT_PAD_BUTTON | rage::ioPad::TOUCH_INDEX,
    L2_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::L2_INDEX,
    R2_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::R2_INDEX,
    L1_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::L1_INDEX,
    R1_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::R1_INDEX,
    RUP_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::RUP_INDEX,
    RRIGHT_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::RRIGHT_INDEX,
    RDOWN_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::RDOWN_INDEX,
    RLEFT_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::RLEFT_INDEX,
    SELECT_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::SELECT_INDEX,
    L3_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::L3_INDEX,
    R3_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::R3_INDEX,
    START_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::START_INDEX,
    LUP_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::LUP_INDEX,
    LRIGHT_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::LRIGHT_INDEX,
    LDOWN_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::LDOWN_INDEX,
    LLEFT_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::LLEFT_INDEX,
    TOUCH_INDEX = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::TOUCH_INDEX,
    NUMBUTTONS = iosMapperReference::IOMT_PAD_INDEX | rage::ioPad::NUMBUTTONS,
    IOM_AXIS_LX = iosMapperReference::IOMT_PAD_AXIS,
    IOM_AXIS_LY,
    IOM_AXIS_RX,
    IOM_AXIS_RY,
    IOM_AXIS_LUP,
    IOM_AXIS_LDOWN,
    IOM_AXIS_LLEFT,
    IOM_AXIS_LRIGHT,
    IOM_AXIS_LUR,
    IOM_AXIS_LUL,
    IOM_AXIS_LDR,
    IOM_AXIS_LDL,
    IOM_AXIS_RUP,
    IOM_AXIS_RDOWN,
    IOM_AXIS_RLEFT,
    IOM_AXIS_RRIGHT,
    IOM_AXIS_RUR,
    IOM_AXIS_RUL,
    IOM_AXIS_RDR,
    IOM_AXIS_RDL,
    IOM_AXIS_DPADX,
    IOM_AXIS_DPADY,
    IOM_AXIS_LY_UP,
    IOM_AXIS_LY_DOWN,
    IOM_AXIS_LX_LEFT,
    IOM_AXIS_LX_RIGHT,
    IOM_AXIS_RY_UP,
    IOM_AXIS_RY_DOWN,
    IOM_AXIS_RX_LEFT,
    IOM_AXIS_RX_RIGHT,
    IOM_JOYSTICK_BUTTON1 = iosMapperReference::IOMT_JOYSTICK_BUTTON,
    IOM_JOYSTICK_BUTTON2,
    IOM_JOYSTICK_BUTTON3,
    IOM_JOYSTICK_BUTTON4,
    IOM_JOYSTICK_BUTTON5,
    IOM_JOYSTICK_BUTTON6,
    IOM_JOYSTICK_BUTTON7,
    IOM_JOYSTICK_BUTTON8,
    IOM_JOYSTICK_BUTTON9,
    IOM_JOYSTICK_BUTTON10,
    IOM_JOYSTICK_BUTTON11,
    IOM_JOYSTICK_BUTTON12,
    IOM_JOYSTICK_BUTTON13,
    IOM_JOYSTICK_BUTTON14,
    IOM_JOYSTICK_BUTTON15,
    IOM_JOYSTICK_BUTTON16,
    IOM_JOYSTICK_BUTTON17,
    IOM_JOYSTICK_BUTTON18,
    IOM_JOYSTICK_BUTTON19,
    IOM_JOYSTICK_BUTTON20,
    IOM_JOYSTICK_BUTTON21,
    IOM_JOYSTICK_BUTTON22,
    IOM_JOYSTICK_BUTTON23,
    IOM_JOYSTICK_BUTTON24,
    IOM_JOYSTICK_BUTTON25,
    IOM_JOYSTICK_BUTTON26,
    IOM_JOYSTICK_BUTTON27,
    IOM_JOYSTICK_BUTTON28,
    IOM_JOYSTICK_BUTTON29,
    IOM_JOYSTICK_BUTTON30,
    IOM_JOYSTICK_BUTTON31,
    IOM_JOYSTICK_BUTTON32,
    IOM_JOYSTICK_AXIS1 = iosMapperReference::IOMT_JOYSTICK_AXIS,
    IOM_JOYSTICK_AXIS2,
    IOM_JOYSTICK_AXIS3,
    IOM_JOYSTICK_AXIS4,
    IOM_JOYSTICK_AXIS5,
    IOM_JOYSTICK_AXIS6,
    IOM_JOYSTICK_AXIS7,
    IOM_JOYSTICK_AXIS8,
    IOM_POV1_UP = iosMapperReference::IOMT_JOYSTICK_POV,
    IOM_POV1_RIGHT,
    IOM_POV1_DOWN,
    IOM_POV1_LEFT,
    IOM_POV2_UP,
    IOM_POV2_RIGHT,
    IOM_POV2_DOWN,
    IOM_POV2_LEFT,
    IOM_POV3_UP,
    IOM_POV3_RIGHT,
    IOM_POV3_DOWN,
    IOM_POV3_LEFT,
    IOM_POV4_UP,
    IOM_POV4_RIGHT,
    IOM_POV4_DOWN,
    IOM_POV4_LEFT,
};
}
static_assert(rage::ioMapperSource_NUM_ENUMS == 28, "schema enum count");
static_assert(static_cast<long long>(rage::IOMS_UNDEFINED) == static_cast<long long>(iosMapperReference::IOMS_UNDEFINED), "PSC value: IOMS_UNDEFINED");
static_assert(static_cast<long long>(rage::IOMS_KEYBOARD) == static_cast<long long>(iosMapperReference::IOMS_KEYBOARD), "PSC value: IOMS_KEYBOARD");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_ABSOLUTEAXIS) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_ABSOLUTEAXIS), "PSC value: IOMS_MOUSE_ABSOLUTEAXIS");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_CENTEREDAXIS) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_CENTEREDAXIS), "PSC value: IOMS_MOUSE_CENTEREDAXIS");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_RELATIVEAXIS) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_RELATIVEAXIS), "PSC value: IOMS_MOUSE_RELATIVEAXIS");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_SCALEDAXIS) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_SCALEDAXIS), "PSC value: IOMS_MOUSE_SCALEDAXIS");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_NORMALIZED) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_NORMALIZED), "PSC value: IOMS_MOUSE_NORMALIZED");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_WHEEL) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_WHEEL), "PSC value: IOMS_MOUSE_WHEEL");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_BUTTON) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_BUTTON), "PSC value: IOMS_MOUSE_BUTTON");
static_assert(static_cast<long long>(rage::IOMS_MOUSE_BUTTONANY) == static_cast<long long>(iosMapperReference::IOMS_MOUSE_BUTTONANY), "PSC value: IOMS_MOUSE_BUTTONANY");
static_assert(static_cast<long long>(rage::IOMS_PAD_DIGITALBUTTON) == static_cast<long long>(iosMapperReference::IOMS_PAD_DIGITALBUTTON), "PSC value: IOMS_PAD_DIGITALBUTTON");
static_assert(static_cast<long long>(rage::IOMS_PAD_DIGITALBUTTONANY) == static_cast<long long>(iosMapperReference::IOMS_PAD_DIGITALBUTTONANY), "PSC value: IOMS_PAD_DIGITALBUTTONANY");
static_assert(static_cast<long long>(rage::IOMS_PAD_ANALOGBUTTON) == static_cast<long long>(iosMapperReference::IOMS_PAD_ANALOGBUTTON), "PSC value: IOMS_PAD_ANALOGBUTTON");
static_assert(static_cast<long long>(rage::IOMS_PAD_AXIS) == static_cast<long long>(iosMapperReference::IOMS_PAD_AXIS), "PSC value: IOMS_PAD_AXIS");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_BUTTON) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_BUTTON), "PSC value: IOMS_JOYSTICK_BUTTON");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_AXIS) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_AXIS), "PSC value: IOMS_JOYSTICK_AXIS");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_IAXIS) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_IAXIS), "PSC value: IOMS_JOYSTICK_IAXIS");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_AXIS_NEGATIVE) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_AXIS_NEGATIVE), "PSC value: IOMS_JOYSTICK_AXIS_NEGATIVE");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_AXIS_POSITIVE) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_AXIS_POSITIVE), "PSC value: IOMS_JOYSTICK_AXIS_POSITIVE");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_POV) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_POV), "PSC value: IOMS_JOYSTICK_POV");
static_assert(static_cast<long long>(rage::IOMS_JOYSTICK_POV_AXIS) == static_cast<long long>(iosMapperReference::IOMS_JOYSTICK_POV_AXIS), "PSC value: IOMS_JOYSTICK_POV_AXIS");
static_assert(static_cast<long long>(rage::IOMS_PAD_DEBUGBUTTON) == static_cast<long long>(iosMapperReference::IOMS_PAD_DEBUGBUTTON), "PSC value: IOMS_PAD_DEBUGBUTTON");
static_assert(static_cast<long long>(rage::IOMS_DIGITALBUTTON_AXIS) == static_cast<long long>(iosMapperReference::IOMS_DIGITALBUTTON_AXIS), "PSC value: IOMS_DIGITALBUTTON_AXIS");
static_assert(static_cast<long long>(rage::IOMS_MKB_AXIS) == static_cast<long long>(iosMapperReference::IOMS_MKB_AXIS), "PSC value: IOMS_MKB_AXIS");
static_assert(static_cast<long long>(rage::IOMS_TOUCHPAD_ABSOLUTE_AXIS) == static_cast<long long>(iosMapperReference::IOMS_TOUCHPAD_ABSOLUTE_AXIS), "PSC value: IOMS_TOUCHPAD_ABSOLUTE_AXIS");
static_assert(static_cast<long long>(rage::IOMS_TOUCHPAD_CENTERED_AXIS) == static_cast<long long>(iosMapperReference::IOMS_TOUCHPAD_CENTERED_AXIS), "PSC value: IOMS_TOUCHPAD_CENTERED_AXIS");
static_assert(static_cast<long long>(rage::IOMS_GAME_CONTROLLED) == static_cast<long long>(iosMapperReference::IOMS_GAME_CONTROLLED), "PSC value: IOMS_GAME_CONTROLLED");
static_assert(static_cast<long long>(rage::IOMS_FORCE32) == static_cast<long long>(iosMapperReference::IOMS_FORCE32), "PSC value: IOMS_FORCE32");
static_assert(rage::ioConstants_NUM_ENUMS == 6, "schema enum count");
static_assert(static_cast<long long>(rage::IOMC_MKB_AXIS_MASK) == static_cast<long long>(iosMapperReference::IOMC_MKB_AXIS_MASK), "PSC value: IOMC_MKB_AXIS_MASK");
static_assert(static_cast<long long>(rage::IOMC_MKB_POSITIVE_AXIS_SHIFT) == static_cast<long long>(iosMapperReference::IOMC_MKB_POSITIVE_AXIS_SHIFT), "PSC value: IOMC_MKB_POSITIVE_AXIS_SHIFT");
static_assert(static_cast<long long>(rage::IOMC_MKB_AXIS_NEGATIVE_IS_MOUSE) == static_cast<long long>(iosMapperReference::IOMC_MKB_AXIS_NEGATIVE_IS_MOUSE), "PSC value: IOMC_MKB_AXIS_NEGATIVE_IS_MOUSE");
static_assert(static_cast<long long>(rage::IOMC_MKB_AXIS_POSITIVE_IS_MOUSE) == static_cast<long long>(iosMapperReference::IOMC_MKB_AXIS_POSITIVE_IS_MOUSE), "PSC value: IOMC_MKB_AXIS_POSITIVE_IS_MOUSE");
static_assert(static_cast<long long>(rage::IOMC_MKB_AXIS_NEGATIVE_IS_WHEEL) == static_cast<long long>(iosMapperReference::IOMC_MKB_AXIS_NEGATIVE_IS_WHEEL), "PSC value: IOMC_MKB_AXIS_NEGATIVE_IS_WHEEL");
static_assert(static_cast<long long>(rage::IOMC_MKB_AXIS_POSITIVE_IS_WHEEL) == static_cast<long long>(iosMapperReference::IOMC_MKB_AXIS_POSITIVE_IS_WHEEL), "PSC value: IOMC_MKB_AXIS_POSITIVE_IS_WHEEL");
static_assert(rage::ioParameterMask_NUM_ENUMS == 12, "schema enum count");
static_assert(static_cast<long long>(rage::IOMT_KEYBOARD) == static_cast<long long>(iosMapperReference::IOMT_KEYBOARD), "PSC value: IOMT_KEYBOARD");
static_assert(static_cast<long long>(rage::IOMT_MOUSE_AXIS) == static_cast<long long>(iosMapperReference::IOMT_MOUSE_AXIS), "PSC value: IOMT_MOUSE_AXIS");
static_assert(static_cast<long long>(rage::IOMT_MOUSE_WHEEL) == static_cast<long long>(iosMapperReference::IOMT_MOUSE_WHEEL), "PSC value: IOMT_MOUSE_WHEEL");
static_assert(static_cast<long long>(rage::IOMT_MOUSE_BUTTON) == static_cast<long long>(iosMapperReference::IOMT_MOUSE_BUTTON), "PSC value: IOMT_MOUSE_BUTTON");
static_assert(static_cast<long long>(rage::IOMT_PAD_AXIS) == static_cast<long long>(iosMapperReference::IOMT_PAD_AXIS), "PSC value: IOMT_PAD_AXIS");
static_assert(static_cast<long long>(rage::IOMT_PAD_INDEX) == static_cast<long long>(iosMapperReference::IOMT_PAD_INDEX), "PSC value: IOMT_PAD_INDEX");
static_assert(static_cast<long long>(rage::IOMT_JOYSTICK_POV) == static_cast<long long>(iosMapperReference::IOMT_JOYSTICK_POV), "PSC value: IOMT_JOYSTICK_POV");
static_assert(static_cast<long long>(rage::IOMT_JOYSTICK_BUTTON) == static_cast<long long>(iosMapperReference::IOMT_JOYSTICK_BUTTON), "PSC value: IOMT_JOYSTICK_BUTTON");
static_assert(static_cast<long long>(rage::IOMT_JOYSTICK_AXIS) == static_cast<long long>(iosMapperReference::IOMT_JOYSTICK_AXIS), "PSC value: IOMT_JOYSTICK_AXIS");
static_assert(static_cast<long long>(rage::IOMT_PAD_BUTTON) == static_cast<long long>(iosMapperReference::IOMT_PAD_BUTTON), "PSC value: IOMT_PAD_BUTTON");
static_assert(static_cast<long long>(rage::IOMT_JOYSTICK_AXIS_NEGATIVE) == static_cast<long long>(iosMapperReference::IOMT_JOYSTICK_AXIS_NEGATIVE), "PSC value: IOMT_JOYSTICK_AXIS_NEGATIVE");
static_assert(static_cast<long long>(rage::IOMT_JOYSTICK_AXIS_POSITIVE) == static_cast<long long>(iosMapperReference::IOMT_JOYSTICK_AXIS_POSITIVE), "PSC value: IOMT_JOYSTICK_AXIS_POSITIVE");
static_assert(rage::ioMapperParameter_NUM_ENUMS == 288, "schema enum count");
static_assert(static_cast<long long>(rage::KEY_NULL) == static_cast<long long>(iosMapperReference::KEY_NULL), "PSC value: KEY_NULL");
static_assert(static_cast<long long>(rage::KEY_BACK) == static_cast<long long>(iosMapperReference::KEY_BACK), "PSC value: KEY_BACK");
static_assert(static_cast<long long>(rage::KEY_TAB) == static_cast<long long>(iosMapperReference::KEY_TAB), "PSC value: KEY_TAB");
static_assert(static_cast<long long>(rage::KEY_RETURN) == static_cast<long long>(iosMapperReference::KEY_RETURN), "PSC value: KEY_RETURN");
static_assert(static_cast<long long>(rage::KEY_PAUSE) == static_cast<long long>(iosMapperReference::KEY_PAUSE), "PSC value: KEY_PAUSE");
static_assert(static_cast<long long>(rage::KEY_CAPITAL) == static_cast<long long>(iosMapperReference::KEY_CAPITAL), "PSC value: KEY_CAPITAL");
static_assert(static_cast<long long>(rage::KEY_ESCAPE) == static_cast<long long>(iosMapperReference::KEY_ESCAPE), "PSC value: KEY_ESCAPE");
static_assert(static_cast<long long>(rage::KEY_SPACE) == static_cast<long long>(iosMapperReference::KEY_SPACE), "PSC value: KEY_SPACE");
static_assert(static_cast<long long>(rage::KEY_PAGEUP) == static_cast<long long>(iosMapperReference::KEY_PAGEUP), "PSC value: KEY_PAGEUP");
static_assert(static_cast<long long>(rage::KEY_PRIOR) == static_cast<long long>(iosMapperReference::KEY_PRIOR), "PSC value: KEY_PRIOR");
static_assert(static_cast<long long>(rage::KEY_PAGEDOWN) == static_cast<long long>(iosMapperReference::KEY_PAGEDOWN), "PSC value: KEY_PAGEDOWN");
static_assert(static_cast<long long>(rage::KEY_NEXT) == static_cast<long long>(iosMapperReference::KEY_NEXT), "PSC value: KEY_NEXT");
static_assert(static_cast<long long>(rage::KEY_END) == static_cast<long long>(iosMapperReference::KEY_END), "PSC value: KEY_END");
static_assert(static_cast<long long>(rage::KEY_HOME) == static_cast<long long>(iosMapperReference::KEY_HOME), "PSC value: KEY_HOME");
static_assert(static_cast<long long>(rage::KEY_LEFT) == static_cast<long long>(iosMapperReference::KEY_LEFT), "PSC value: KEY_LEFT");
static_assert(static_cast<long long>(rage::KEY_UP) == static_cast<long long>(iosMapperReference::KEY_UP), "PSC value: KEY_UP");
static_assert(static_cast<long long>(rage::KEY_RIGHT) == static_cast<long long>(iosMapperReference::KEY_RIGHT), "PSC value: KEY_RIGHT");
static_assert(static_cast<long long>(rage::KEY_DOWN) == static_cast<long long>(iosMapperReference::KEY_DOWN), "PSC value: KEY_DOWN");
static_assert(static_cast<long long>(rage::KEY_SNAPSHOT) == static_cast<long long>(iosMapperReference::KEY_SNAPSHOT), "PSC value: KEY_SNAPSHOT");
static_assert(static_cast<long long>(rage::KEY_SYSRQ) == static_cast<long long>(iosMapperReference::KEY_SYSRQ), "PSC value: KEY_SYSRQ");
static_assert(static_cast<long long>(rage::KEY_INSERT) == static_cast<long long>(iosMapperReference::KEY_INSERT), "PSC value: KEY_INSERT");
static_assert(static_cast<long long>(rage::KEY_DELETE) == static_cast<long long>(iosMapperReference::KEY_DELETE), "PSC value: KEY_DELETE");
static_assert(static_cast<long long>(rage::KEY_0) == static_cast<long long>(iosMapperReference::KEY_0), "PSC value: KEY_0");
static_assert(static_cast<long long>(rage::KEY_1) == static_cast<long long>(iosMapperReference::KEY_1), "PSC value: KEY_1");
static_assert(static_cast<long long>(rage::KEY_2) == static_cast<long long>(iosMapperReference::KEY_2), "PSC value: KEY_2");
static_assert(static_cast<long long>(rage::KEY_3) == static_cast<long long>(iosMapperReference::KEY_3), "PSC value: KEY_3");
static_assert(static_cast<long long>(rage::KEY_4) == static_cast<long long>(iosMapperReference::KEY_4), "PSC value: KEY_4");
static_assert(static_cast<long long>(rage::KEY_5) == static_cast<long long>(iosMapperReference::KEY_5), "PSC value: KEY_5");
static_assert(static_cast<long long>(rage::KEY_6) == static_cast<long long>(iosMapperReference::KEY_6), "PSC value: KEY_6");
static_assert(static_cast<long long>(rage::KEY_7) == static_cast<long long>(iosMapperReference::KEY_7), "PSC value: KEY_7");
static_assert(static_cast<long long>(rage::KEY_8) == static_cast<long long>(iosMapperReference::KEY_8), "PSC value: KEY_8");
static_assert(static_cast<long long>(rage::KEY_9) == static_cast<long long>(iosMapperReference::KEY_9), "PSC value: KEY_9");
static_assert(static_cast<long long>(rage::KEY_A) == static_cast<long long>(iosMapperReference::KEY_A), "PSC value: KEY_A");
static_assert(static_cast<long long>(rage::KEY_B) == static_cast<long long>(iosMapperReference::KEY_B), "PSC value: KEY_B");
static_assert(static_cast<long long>(rage::KEY_C) == static_cast<long long>(iosMapperReference::KEY_C), "PSC value: KEY_C");
static_assert(static_cast<long long>(rage::KEY_D) == static_cast<long long>(iosMapperReference::KEY_D), "PSC value: KEY_D");
static_assert(static_cast<long long>(rage::KEY_E) == static_cast<long long>(iosMapperReference::KEY_E), "PSC value: KEY_E");
static_assert(static_cast<long long>(rage::KEY_F) == static_cast<long long>(iosMapperReference::KEY_F), "PSC value: KEY_F");
static_assert(static_cast<long long>(rage::KEY_G) == static_cast<long long>(iosMapperReference::KEY_G), "PSC value: KEY_G");
static_assert(static_cast<long long>(rage::KEY_H) == static_cast<long long>(iosMapperReference::KEY_H), "PSC value: KEY_H");
static_assert(static_cast<long long>(rage::KEY_I) == static_cast<long long>(iosMapperReference::KEY_I), "PSC value: KEY_I");
static_assert(static_cast<long long>(rage::KEY_J) == static_cast<long long>(iosMapperReference::KEY_J), "PSC value: KEY_J");
static_assert(static_cast<long long>(rage::KEY_K) == static_cast<long long>(iosMapperReference::KEY_K), "PSC value: KEY_K");
static_assert(static_cast<long long>(rage::KEY_L) == static_cast<long long>(iosMapperReference::KEY_L), "PSC value: KEY_L");
static_assert(static_cast<long long>(rage::KEY_M) == static_cast<long long>(iosMapperReference::KEY_M), "PSC value: KEY_M");
static_assert(static_cast<long long>(rage::KEY_N) == static_cast<long long>(iosMapperReference::KEY_N), "PSC value: KEY_N");
static_assert(static_cast<long long>(rage::KEY_O) == static_cast<long long>(iosMapperReference::KEY_O), "PSC value: KEY_O");
static_assert(static_cast<long long>(rage::KEY_P) == static_cast<long long>(iosMapperReference::KEY_P), "PSC value: KEY_P");
static_assert(static_cast<long long>(rage::KEY_Q) == static_cast<long long>(iosMapperReference::KEY_Q), "PSC value: KEY_Q");
static_assert(static_cast<long long>(rage::KEY_R) == static_cast<long long>(iosMapperReference::KEY_R), "PSC value: KEY_R");
static_assert(static_cast<long long>(rage::KEY_S) == static_cast<long long>(iosMapperReference::KEY_S), "PSC value: KEY_S");
static_assert(static_cast<long long>(rage::KEY_T) == static_cast<long long>(iosMapperReference::KEY_T), "PSC value: KEY_T");
static_assert(static_cast<long long>(rage::KEY_U) == static_cast<long long>(iosMapperReference::KEY_U), "PSC value: KEY_U");
static_assert(static_cast<long long>(rage::KEY_V) == static_cast<long long>(iosMapperReference::KEY_V), "PSC value: KEY_V");
static_assert(static_cast<long long>(rage::KEY_W) == static_cast<long long>(iosMapperReference::KEY_W), "PSC value: KEY_W");
static_assert(static_cast<long long>(rage::KEY_X) == static_cast<long long>(iosMapperReference::KEY_X), "PSC value: KEY_X");
static_assert(static_cast<long long>(rage::KEY_Y) == static_cast<long long>(iosMapperReference::KEY_Y), "PSC value: KEY_Y");
static_assert(static_cast<long long>(rage::KEY_Z) == static_cast<long long>(iosMapperReference::KEY_Z), "PSC value: KEY_Z");
static_assert(static_cast<long long>(rage::KEY_LWIN) == static_cast<long long>(iosMapperReference::KEY_LWIN), "PSC value: KEY_LWIN");
static_assert(static_cast<long long>(rage::KEY_RWIN) == static_cast<long long>(iosMapperReference::KEY_RWIN), "PSC value: KEY_RWIN");
static_assert(static_cast<long long>(rage::KEY_APPS) == static_cast<long long>(iosMapperReference::KEY_APPS), "PSC value: KEY_APPS");
static_assert(static_cast<long long>(rage::KEY_NUMPAD0) == static_cast<long long>(iosMapperReference::KEY_NUMPAD0), "PSC value: KEY_NUMPAD0");
static_assert(static_cast<long long>(rage::KEY_NUMPAD1) == static_cast<long long>(iosMapperReference::KEY_NUMPAD1), "PSC value: KEY_NUMPAD1");
static_assert(static_cast<long long>(rage::KEY_NUMPAD2) == static_cast<long long>(iosMapperReference::KEY_NUMPAD2), "PSC value: KEY_NUMPAD2");
static_assert(static_cast<long long>(rage::KEY_NUMPAD3) == static_cast<long long>(iosMapperReference::KEY_NUMPAD3), "PSC value: KEY_NUMPAD3");
static_assert(static_cast<long long>(rage::KEY_NUMPAD4) == static_cast<long long>(iosMapperReference::KEY_NUMPAD4), "PSC value: KEY_NUMPAD4");
static_assert(static_cast<long long>(rage::KEY_NUMPAD5) == static_cast<long long>(iosMapperReference::KEY_NUMPAD5), "PSC value: KEY_NUMPAD5");
static_assert(static_cast<long long>(rage::KEY_NUMPAD6) == static_cast<long long>(iosMapperReference::KEY_NUMPAD6), "PSC value: KEY_NUMPAD6");
static_assert(static_cast<long long>(rage::KEY_NUMPAD7) == static_cast<long long>(iosMapperReference::KEY_NUMPAD7), "PSC value: KEY_NUMPAD7");
static_assert(static_cast<long long>(rage::KEY_NUMPAD8) == static_cast<long long>(iosMapperReference::KEY_NUMPAD8), "PSC value: KEY_NUMPAD8");
static_assert(static_cast<long long>(rage::KEY_NUMPAD9) == static_cast<long long>(iosMapperReference::KEY_NUMPAD9), "PSC value: KEY_NUMPAD9");
static_assert(static_cast<long long>(rage::KEY_MULTIPLY) == static_cast<long long>(iosMapperReference::KEY_MULTIPLY), "PSC value: KEY_MULTIPLY");
static_assert(static_cast<long long>(rage::KEY_ADD) == static_cast<long long>(iosMapperReference::KEY_ADD), "PSC value: KEY_ADD");
static_assert(static_cast<long long>(rage::KEY_SUBTRACT) == static_cast<long long>(iosMapperReference::KEY_SUBTRACT), "PSC value: KEY_SUBTRACT");
static_assert(static_cast<long long>(rage::KEY_DECIMAL) == static_cast<long long>(iosMapperReference::KEY_DECIMAL), "PSC value: KEY_DECIMAL");
static_assert(static_cast<long long>(rage::KEY_DIVIDE) == static_cast<long long>(iosMapperReference::KEY_DIVIDE), "PSC value: KEY_DIVIDE");
static_assert(static_cast<long long>(rage::KEY_F1) == static_cast<long long>(iosMapperReference::KEY_F1), "PSC value: KEY_F1");
static_assert(static_cast<long long>(rage::KEY_F2) == static_cast<long long>(iosMapperReference::KEY_F2), "PSC value: KEY_F2");
static_assert(static_cast<long long>(rage::KEY_F3) == static_cast<long long>(iosMapperReference::KEY_F3), "PSC value: KEY_F3");
static_assert(static_cast<long long>(rage::KEY_F4) == static_cast<long long>(iosMapperReference::KEY_F4), "PSC value: KEY_F4");
static_assert(static_cast<long long>(rage::KEY_F5) == static_cast<long long>(iosMapperReference::KEY_F5), "PSC value: KEY_F5");
static_assert(static_cast<long long>(rage::KEY_F6) == static_cast<long long>(iosMapperReference::KEY_F6), "PSC value: KEY_F6");
static_assert(static_cast<long long>(rage::KEY_F7) == static_cast<long long>(iosMapperReference::KEY_F7), "PSC value: KEY_F7");
static_assert(static_cast<long long>(rage::KEY_F8) == static_cast<long long>(iosMapperReference::KEY_F8), "PSC value: KEY_F8");
static_assert(static_cast<long long>(rage::KEY_F9) == static_cast<long long>(iosMapperReference::KEY_F9), "PSC value: KEY_F9");
static_assert(static_cast<long long>(rage::KEY_F10) == static_cast<long long>(iosMapperReference::KEY_F10), "PSC value: KEY_F10");
static_assert(static_cast<long long>(rage::KEY_F11) == static_cast<long long>(iosMapperReference::KEY_F11), "PSC value: KEY_F11");
static_assert(static_cast<long long>(rage::KEY_F12) == static_cast<long long>(iosMapperReference::KEY_F12), "PSC value: KEY_F12");
static_assert(static_cast<long long>(rage::KEY_F13) == static_cast<long long>(iosMapperReference::KEY_F13), "PSC value: KEY_F13");
static_assert(static_cast<long long>(rage::KEY_F14) == static_cast<long long>(iosMapperReference::KEY_F14), "PSC value: KEY_F14");
static_assert(static_cast<long long>(rage::KEY_F15) == static_cast<long long>(iosMapperReference::KEY_F15), "PSC value: KEY_F15");
static_assert(static_cast<long long>(rage::KEY_F16) == static_cast<long long>(iosMapperReference::KEY_F16), "PSC value: KEY_F16");
static_assert(static_cast<long long>(rage::KEY_F17) == static_cast<long long>(iosMapperReference::KEY_F17), "PSC value: KEY_F17");
static_assert(static_cast<long long>(rage::KEY_F18) == static_cast<long long>(iosMapperReference::KEY_F18), "PSC value: KEY_F18");
static_assert(static_cast<long long>(rage::KEY_F19) == static_cast<long long>(iosMapperReference::KEY_F19), "PSC value: KEY_F19");
static_assert(static_cast<long long>(rage::KEY_F20) == static_cast<long long>(iosMapperReference::KEY_F20), "PSC value: KEY_F20");
static_assert(static_cast<long long>(rage::KEY_F21) == static_cast<long long>(iosMapperReference::KEY_F21), "PSC value: KEY_F21");
static_assert(static_cast<long long>(rage::KEY_F22) == static_cast<long long>(iosMapperReference::KEY_F22), "PSC value: KEY_F22");
static_assert(static_cast<long long>(rage::KEY_F23) == static_cast<long long>(iosMapperReference::KEY_F23), "PSC value: KEY_F23");
static_assert(static_cast<long long>(rage::KEY_F24) == static_cast<long long>(iosMapperReference::KEY_F24), "PSC value: KEY_F24");
static_assert(static_cast<long long>(rage::KEY_NUMLOCK) == static_cast<long long>(iosMapperReference::KEY_NUMLOCK), "PSC value: KEY_NUMLOCK");
static_assert(static_cast<long long>(rage::KEY_SCROLL) == static_cast<long long>(iosMapperReference::KEY_SCROLL), "PSC value: KEY_SCROLL");
static_assert(static_cast<long long>(rage::KEY_NUMPADEQUALS) == static_cast<long long>(iosMapperReference::KEY_NUMPADEQUALS), "PSC value: KEY_NUMPADEQUALS");
static_assert(static_cast<long long>(rage::KEY_LSHIFT) == static_cast<long long>(iosMapperReference::KEY_LSHIFT), "PSC value: KEY_LSHIFT");
static_assert(static_cast<long long>(rage::KEY_RSHIFT) == static_cast<long long>(iosMapperReference::KEY_RSHIFT), "PSC value: KEY_RSHIFT");
static_assert(static_cast<long long>(rage::KEY_LCONTROL) == static_cast<long long>(iosMapperReference::KEY_LCONTROL), "PSC value: KEY_LCONTROL");
static_assert(static_cast<long long>(rage::KEY_RCONTROL) == static_cast<long long>(iosMapperReference::KEY_RCONTROL), "PSC value: KEY_RCONTROL");
static_assert(static_cast<long long>(rage::KEY_LMENU) == static_cast<long long>(iosMapperReference::KEY_LMENU), "PSC value: KEY_LMENU");
static_assert(static_cast<long long>(rage::KEY_RMENU) == static_cast<long long>(iosMapperReference::KEY_RMENU), "PSC value: KEY_RMENU");
static_assert(static_cast<long long>(rage::KEY_SEMICOLON) == static_cast<long long>(iosMapperReference::KEY_SEMICOLON), "PSC value: KEY_SEMICOLON");
static_assert(static_cast<long long>(rage::KEY_OEM_1) == static_cast<long long>(iosMapperReference::KEY_OEM_1), "PSC value: KEY_OEM_1");
static_assert(static_cast<long long>(rage::KEY_PLUS) == static_cast<long long>(iosMapperReference::KEY_PLUS), "PSC value: KEY_PLUS");
static_assert(static_cast<long long>(rage::KEY_EQUALS) == static_cast<long long>(iosMapperReference::KEY_EQUALS), "PSC value: KEY_EQUALS");
static_assert(static_cast<long long>(rage::KEY_COMMA) == static_cast<long long>(iosMapperReference::KEY_COMMA), "PSC value: KEY_COMMA");
static_assert(static_cast<long long>(rage::KEY_MINUS) == static_cast<long long>(iosMapperReference::KEY_MINUS), "PSC value: KEY_MINUS");
static_assert(static_cast<long long>(rage::KEY_PERIOD) == static_cast<long long>(iosMapperReference::KEY_PERIOD), "PSC value: KEY_PERIOD");
static_assert(static_cast<long long>(rage::KEY_SLASH) == static_cast<long long>(iosMapperReference::KEY_SLASH), "PSC value: KEY_SLASH");
static_assert(static_cast<long long>(rage::KEY_OEM_2) == static_cast<long long>(iosMapperReference::KEY_OEM_2), "PSC value: KEY_OEM_2");
static_assert(static_cast<long long>(rage::KEY_GRAVE) == static_cast<long long>(iosMapperReference::KEY_GRAVE), "PSC value: KEY_GRAVE");
static_assert(static_cast<long long>(rage::KEY_OEM_3) == static_cast<long long>(iosMapperReference::KEY_OEM_3), "PSC value: KEY_OEM_3");
static_assert(static_cast<long long>(rage::KEY_LBRACKET) == static_cast<long long>(iosMapperReference::KEY_LBRACKET), "PSC value: KEY_LBRACKET");
static_assert(static_cast<long long>(rage::KEY_OEM_4) == static_cast<long long>(iosMapperReference::KEY_OEM_4), "PSC value: KEY_OEM_4");
static_assert(static_cast<long long>(rage::KEY_BACKSLASH) == static_cast<long long>(iosMapperReference::KEY_BACKSLASH), "PSC value: KEY_BACKSLASH");
static_assert(static_cast<long long>(rage::KEY_OEM_5) == static_cast<long long>(iosMapperReference::KEY_OEM_5), "PSC value: KEY_OEM_5");
static_assert(static_cast<long long>(rage::KEY_RBRACKET) == static_cast<long long>(iosMapperReference::KEY_RBRACKET), "PSC value: KEY_RBRACKET");
static_assert(static_cast<long long>(rage::KEY_OEM_6) == static_cast<long long>(iosMapperReference::KEY_OEM_6), "PSC value: KEY_OEM_6");
static_assert(static_cast<long long>(rage::KEY_APOSTROPHE) == static_cast<long long>(iosMapperReference::KEY_APOSTROPHE), "PSC value: KEY_APOSTROPHE");
static_assert(static_cast<long long>(rage::KEY_OEM_7) == static_cast<long long>(iosMapperReference::KEY_OEM_7), "PSC value: KEY_OEM_7");
static_assert(static_cast<long long>(rage::KEY_OEM_102) == static_cast<long long>(iosMapperReference::KEY_OEM_102), "PSC value: KEY_OEM_102");
static_assert(static_cast<long long>(rage::KEY_RAGE_EXTRA1) == static_cast<long long>(iosMapperReference::KEY_RAGE_EXTRA1), "PSC value: KEY_RAGE_EXTRA1");
static_assert(static_cast<long long>(rage::KEY_RAGE_EXTRA2) == static_cast<long long>(iosMapperReference::KEY_RAGE_EXTRA2), "PSC value: KEY_RAGE_EXTRA2");
static_assert(static_cast<long long>(rage::KEY_RAGE_EXTRA3) == static_cast<long long>(iosMapperReference::KEY_RAGE_EXTRA3), "PSC value: KEY_RAGE_EXTRA3");
static_assert(static_cast<long long>(rage::KEY_RAGE_EXTRA4) == static_cast<long long>(iosMapperReference::KEY_RAGE_EXTRA4), "PSC value: KEY_RAGE_EXTRA4");
static_assert(static_cast<long long>(rage::KEY_NUMPADENTER) == static_cast<long long>(iosMapperReference::KEY_NUMPADENTER), "PSC value: KEY_NUMPADENTER");
static_assert(static_cast<long long>(rage::KEY_CHATPAD_GREEN_SHIFT) == static_cast<long long>(iosMapperReference::KEY_CHATPAD_GREEN_SHIFT), "PSC value: KEY_CHATPAD_GREEN_SHIFT");
static_assert(static_cast<long long>(rage::KEY_CHATPAD_ORANGE_SHIFT) == static_cast<long long>(iosMapperReference::KEY_CHATPAD_ORANGE_SHIFT), "PSC value: KEY_CHATPAD_ORANGE_SHIFT");
static_assert(static_cast<long long>(rage::IOM_AXIS_UNDEFINED) == static_cast<long long>(iosMapperReference::IOM_AXIS_UNDEFINED), "PSC value: IOM_AXIS_UNDEFINED");
static_assert(static_cast<long long>(rage::IOM_UNDEFINED) == static_cast<long long>(iosMapperReference::IOM_UNDEFINED), "PSC value: IOM_UNDEFINED");
static_assert(static_cast<long long>(rage::IOM_WHEEL_UNDEFINED) == static_cast<long long>(iosMapperReference::IOM_WHEEL_UNDEFINED), "PSC value: IOM_WHEEL_UNDEFINED");
static_assert(static_cast<long long>(rage::IOM_POV_UNDEFINED) == static_cast<long long>(iosMapperReference::IOM_POV_UNDEFINED), "PSC value: IOM_POV_UNDEFINED");
static_assert(static_cast<long long>(rage::IOM_ANY_BUTTON) == static_cast<long long>(iosMapperReference::IOM_ANY_BUTTON), "PSC value: IOM_ANY_BUTTON");
static_assert(static_cast<long long>(rage::IOM_AXIS_X) == static_cast<long long>(iosMapperReference::IOM_AXIS_X), "PSC value: IOM_AXIS_X");
static_assert(static_cast<long long>(rage::IOM_AXIS_Y) == static_cast<long long>(iosMapperReference::IOM_AXIS_Y), "PSC value: IOM_AXIS_Y");
static_assert(static_cast<long long>(rage::IOM_IAXIS_X) == static_cast<long long>(iosMapperReference::IOM_IAXIS_X), "PSC value: IOM_IAXIS_X");
static_assert(static_cast<long long>(rage::IOM_IAXIS_Y) == static_cast<long long>(iosMapperReference::IOM_IAXIS_Y), "PSC value: IOM_IAXIS_Y");
static_assert(static_cast<long long>(rage::BASIC_MOUSE_AXIS_MAX) == static_cast<long long>(iosMapperReference::BASIC_MOUSE_AXIS_MAX), "PSC value: BASIC_MOUSE_AXIS_MAX");
static_assert(static_cast<long long>(rage::IOM_AXIS_X_LEFT) == static_cast<long long>(iosMapperReference::IOM_AXIS_X_LEFT), "PSC value: IOM_AXIS_X_LEFT");
static_assert(static_cast<long long>(rage::IOM_AXIS_X_RIGHT) == static_cast<long long>(iosMapperReference::IOM_AXIS_X_RIGHT), "PSC value: IOM_AXIS_X_RIGHT");
static_assert(static_cast<long long>(rage::IOM_AXIS_Y_UP) == static_cast<long long>(iosMapperReference::IOM_AXIS_Y_UP), "PSC value: IOM_AXIS_Y_UP");
static_assert(static_cast<long long>(rage::IOM_AXIS_Y_DOWN) == static_cast<long long>(iosMapperReference::IOM_AXIS_Y_DOWN), "PSC value: IOM_AXIS_Y_DOWN");
static_assert(static_cast<long long>(rage::MOUSE_AXIS_MAX) == static_cast<long long>(iosMapperReference::MOUSE_AXIS_MAX), "PSC value: MOUSE_AXIS_MAX");
static_assert(static_cast<long long>(rage::IOM_WHEEL_UP) == static_cast<long long>(iosMapperReference::IOM_WHEEL_UP), "PSC value: IOM_WHEEL_UP");
static_assert(static_cast<long long>(rage::IOM_WHEEL_DOWN) == static_cast<long long>(iosMapperReference::IOM_WHEEL_DOWN), "PSC value: IOM_WHEEL_DOWN");
static_assert(static_cast<long long>(rage::IOM_AXIS_WHEEL_DELTA) == static_cast<long long>(iosMapperReference::IOM_AXIS_WHEEL_DELTA), "PSC value: IOM_AXIS_WHEEL_DELTA");
static_assert(static_cast<long long>(rage::IOM_IAXIS_WHEEL_DELTA) == static_cast<long long>(iosMapperReference::IOM_IAXIS_WHEEL_DELTA), "PSC value: IOM_IAXIS_WHEEL_DELTA");
static_assert(static_cast<long long>(rage::IOM_AXIS_WHEEL) == static_cast<long long>(iosMapperReference::IOM_AXIS_WHEEL), "PSC value: IOM_AXIS_WHEEL");
static_assert(static_cast<long long>(rage::IOM_IAXIS_WHEEL) == static_cast<long long>(iosMapperReference::IOM_IAXIS_WHEEL), "PSC value: IOM_IAXIS_WHEEL");
static_assert(static_cast<long long>(rage::IOM_AXIS_WHEEL_RELATIVE) == static_cast<long long>(iosMapperReference::IOM_AXIS_WHEEL_RELATIVE), "PSC value: IOM_AXIS_WHEEL_RELATIVE");
static_assert(static_cast<long long>(rage::IOM_IAXIS_WHEEL_RELATIVE) == static_cast<long long>(iosMapperReference::IOM_IAXIS_WHEEL_RELATIVE), "PSC value: IOM_IAXIS_WHEEL_RELATIVE");
static_assert(static_cast<long long>(rage::MOUSE_LEFT) == static_cast<long long>(iosMapperReference::MOUSE_LEFT), "PSC value: MOUSE_LEFT");
static_assert(static_cast<long long>(rage::MOUSE_RIGHT) == static_cast<long long>(iosMapperReference::MOUSE_RIGHT), "PSC value: MOUSE_RIGHT");
static_assert(static_cast<long long>(rage::MOUSE_MIDDLE) == static_cast<long long>(iosMapperReference::MOUSE_MIDDLE), "PSC value: MOUSE_MIDDLE");
static_assert(static_cast<long long>(rage::MOUSE_EXTRABTN1) == static_cast<long long>(iosMapperReference::MOUSE_EXTRABTN1), "PSC value: MOUSE_EXTRABTN1");
static_assert(static_cast<long long>(rage::MOUSE_EXTRABTN2) == static_cast<long long>(iosMapperReference::MOUSE_EXTRABTN2), "PSC value: MOUSE_EXTRABTN2");
static_assert(static_cast<long long>(rage::MOUSE_EXTRABTN3) == static_cast<long long>(iosMapperReference::MOUSE_EXTRABTN3), "PSC value: MOUSE_EXTRABTN3");
static_assert(static_cast<long long>(rage::MOUSE_EXTRABTN4) == static_cast<long long>(iosMapperReference::MOUSE_EXTRABTN4), "PSC value: MOUSE_EXTRABTN4");
static_assert(static_cast<long long>(rage::MOUSE_EXTRABTN5) == static_cast<long long>(iosMapperReference::MOUSE_EXTRABTN5), "PSC value: MOUSE_EXTRABTN5");
static_assert(static_cast<long long>(rage::L2) == static_cast<long long>(iosMapperReference::L2), "PSC value: L2");
static_assert(static_cast<long long>(rage::R2) == static_cast<long long>(iosMapperReference::R2), "PSC value: R2");
static_assert(static_cast<long long>(rage::L1) == static_cast<long long>(iosMapperReference::L1), "PSC value: L1");
static_assert(static_cast<long long>(rage::R1) == static_cast<long long>(iosMapperReference::R1), "PSC value: R1");
static_assert(static_cast<long long>(rage::RUP) == static_cast<long long>(iosMapperReference::RUP), "PSC value: RUP");
static_assert(static_cast<long long>(rage::RRIGHT) == static_cast<long long>(iosMapperReference::RRIGHT), "PSC value: RRIGHT");
static_assert(static_cast<long long>(rage::RDOWN) == static_cast<long long>(iosMapperReference::RDOWN), "PSC value: RDOWN");
static_assert(static_cast<long long>(rage::RLEFT) == static_cast<long long>(iosMapperReference::RLEFT), "PSC value: RLEFT");
static_assert(static_cast<long long>(rage::SELECT) == static_cast<long long>(iosMapperReference::SELECT), "PSC value: SELECT");
static_assert(static_cast<long long>(rage::L3) == static_cast<long long>(iosMapperReference::L3), "PSC value: L3");
static_assert(static_cast<long long>(rage::R3) == static_cast<long long>(iosMapperReference::R3), "PSC value: R3");
static_assert(static_cast<long long>(rage::START) == static_cast<long long>(iosMapperReference::START), "PSC value: START");
static_assert(static_cast<long long>(rage::LUP) == static_cast<long long>(iosMapperReference::LUP), "PSC value: LUP");
static_assert(static_cast<long long>(rage::LRIGHT) == static_cast<long long>(iosMapperReference::LRIGHT), "PSC value: LRIGHT");
static_assert(static_cast<long long>(rage::LDOWN) == static_cast<long long>(iosMapperReference::LDOWN), "PSC value: LDOWN");
static_assert(static_cast<long long>(rage::LLEFT) == static_cast<long long>(iosMapperReference::LLEFT), "PSC value: LLEFT");
static_assert(static_cast<long long>(rage::TOUCH) == static_cast<long long>(iosMapperReference::TOUCH), "PSC value: TOUCH");
static_assert(static_cast<long long>(rage::L2_INDEX) == static_cast<long long>(iosMapperReference::L2_INDEX), "PSC value: L2_INDEX");
static_assert(static_cast<long long>(rage::R2_INDEX) == static_cast<long long>(iosMapperReference::R2_INDEX), "PSC value: R2_INDEX");
static_assert(static_cast<long long>(rage::L1_INDEX) == static_cast<long long>(iosMapperReference::L1_INDEX), "PSC value: L1_INDEX");
static_assert(static_cast<long long>(rage::R1_INDEX) == static_cast<long long>(iosMapperReference::R1_INDEX), "PSC value: R1_INDEX");
static_assert(static_cast<long long>(rage::RUP_INDEX) == static_cast<long long>(iosMapperReference::RUP_INDEX), "PSC value: RUP_INDEX");
static_assert(static_cast<long long>(rage::RRIGHT_INDEX) == static_cast<long long>(iosMapperReference::RRIGHT_INDEX), "PSC value: RRIGHT_INDEX");
static_assert(static_cast<long long>(rage::RDOWN_INDEX) == static_cast<long long>(iosMapperReference::RDOWN_INDEX), "PSC value: RDOWN_INDEX");
static_assert(static_cast<long long>(rage::RLEFT_INDEX) == static_cast<long long>(iosMapperReference::RLEFT_INDEX), "PSC value: RLEFT_INDEX");
static_assert(static_cast<long long>(rage::SELECT_INDEX) == static_cast<long long>(iosMapperReference::SELECT_INDEX), "PSC value: SELECT_INDEX");
static_assert(static_cast<long long>(rage::L3_INDEX) == static_cast<long long>(iosMapperReference::L3_INDEX), "PSC value: L3_INDEX");
static_assert(static_cast<long long>(rage::R3_INDEX) == static_cast<long long>(iosMapperReference::R3_INDEX), "PSC value: R3_INDEX");
static_assert(static_cast<long long>(rage::START_INDEX) == static_cast<long long>(iosMapperReference::START_INDEX), "PSC value: START_INDEX");
static_assert(static_cast<long long>(rage::LUP_INDEX) == static_cast<long long>(iosMapperReference::LUP_INDEX), "PSC value: LUP_INDEX");
static_assert(static_cast<long long>(rage::LRIGHT_INDEX) == static_cast<long long>(iosMapperReference::LRIGHT_INDEX), "PSC value: LRIGHT_INDEX");
static_assert(static_cast<long long>(rage::LDOWN_INDEX) == static_cast<long long>(iosMapperReference::LDOWN_INDEX), "PSC value: LDOWN_INDEX");
static_assert(static_cast<long long>(rage::LLEFT_INDEX) == static_cast<long long>(iosMapperReference::LLEFT_INDEX), "PSC value: LLEFT_INDEX");
static_assert(static_cast<long long>(rage::TOUCH_INDEX) == static_cast<long long>(iosMapperReference::TOUCH_INDEX), "PSC value: TOUCH_INDEX");
static_assert(static_cast<long long>(rage::NUMBUTTONS) == static_cast<long long>(iosMapperReference::NUMBUTTONS), "PSC value: NUMBUTTONS");
static_assert(static_cast<long long>(rage::IOM_AXIS_LX) == static_cast<long long>(iosMapperReference::IOM_AXIS_LX), "PSC value: IOM_AXIS_LX");
static_assert(static_cast<long long>(rage::IOM_AXIS_LY) == static_cast<long long>(iosMapperReference::IOM_AXIS_LY), "PSC value: IOM_AXIS_LY");
static_assert(static_cast<long long>(rage::IOM_AXIS_RX) == static_cast<long long>(iosMapperReference::IOM_AXIS_RX), "PSC value: IOM_AXIS_RX");
static_assert(static_cast<long long>(rage::IOM_AXIS_RY) == static_cast<long long>(iosMapperReference::IOM_AXIS_RY), "PSC value: IOM_AXIS_RY");
static_assert(static_cast<long long>(rage::IOM_AXIS_LUP) == static_cast<long long>(iosMapperReference::IOM_AXIS_LUP), "PSC value: IOM_AXIS_LUP");
static_assert(static_cast<long long>(rage::IOM_AXIS_LDOWN) == static_cast<long long>(iosMapperReference::IOM_AXIS_LDOWN), "PSC value: IOM_AXIS_LDOWN");
static_assert(static_cast<long long>(rage::IOM_AXIS_LLEFT) == static_cast<long long>(iosMapperReference::IOM_AXIS_LLEFT), "PSC value: IOM_AXIS_LLEFT");
static_assert(static_cast<long long>(rage::IOM_AXIS_LRIGHT) == static_cast<long long>(iosMapperReference::IOM_AXIS_LRIGHT), "PSC value: IOM_AXIS_LRIGHT");
static_assert(static_cast<long long>(rage::IOM_AXIS_LUR) == static_cast<long long>(iosMapperReference::IOM_AXIS_LUR), "PSC value: IOM_AXIS_LUR");
static_assert(static_cast<long long>(rage::IOM_AXIS_LUL) == static_cast<long long>(iosMapperReference::IOM_AXIS_LUL), "PSC value: IOM_AXIS_LUL");
static_assert(static_cast<long long>(rage::IOM_AXIS_LDR) == static_cast<long long>(iosMapperReference::IOM_AXIS_LDR), "PSC value: IOM_AXIS_LDR");
static_assert(static_cast<long long>(rage::IOM_AXIS_LDL) == static_cast<long long>(iosMapperReference::IOM_AXIS_LDL), "PSC value: IOM_AXIS_LDL");
static_assert(static_cast<long long>(rage::IOM_AXIS_RUP) == static_cast<long long>(iosMapperReference::IOM_AXIS_RUP), "PSC value: IOM_AXIS_RUP");
static_assert(static_cast<long long>(rage::IOM_AXIS_RDOWN) == static_cast<long long>(iosMapperReference::IOM_AXIS_RDOWN), "PSC value: IOM_AXIS_RDOWN");
static_assert(static_cast<long long>(rage::IOM_AXIS_RLEFT) == static_cast<long long>(iosMapperReference::IOM_AXIS_RLEFT), "PSC value: IOM_AXIS_RLEFT");
static_assert(static_cast<long long>(rage::IOM_AXIS_RRIGHT) == static_cast<long long>(iosMapperReference::IOM_AXIS_RRIGHT), "PSC value: IOM_AXIS_RRIGHT");
static_assert(static_cast<long long>(rage::IOM_AXIS_RUR) == static_cast<long long>(iosMapperReference::IOM_AXIS_RUR), "PSC value: IOM_AXIS_RUR");
static_assert(static_cast<long long>(rage::IOM_AXIS_RUL) == static_cast<long long>(iosMapperReference::IOM_AXIS_RUL), "PSC value: IOM_AXIS_RUL");
static_assert(static_cast<long long>(rage::IOM_AXIS_RDR) == static_cast<long long>(iosMapperReference::IOM_AXIS_RDR), "PSC value: IOM_AXIS_RDR");
static_assert(static_cast<long long>(rage::IOM_AXIS_RDL) == static_cast<long long>(iosMapperReference::IOM_AXIS_RDL), "PSC value: IOM_AXIS_RDL");
static_assert(static_cast<long long>(rage::IOM_AXIS_DPADX) == static_cast<long long>(iosMapperReference::IOM_AXIS_DPADX), "PSC value: IOM_AXIS_DPADX");
static_assert(static_cast<long long>(rage::IOM_AXIS_DPADY) == static_cast<long long>(iosMapperReference::IOM_AXIS_DPADY), "PSC value: IOM_AXIS_DPADY");
static_assert(static_cast<long long>(rage::IOM_AXIS_LY_UP) == static_cast<long long>(iosMapperReference::IOM_AXIS_LY_UP), "PSC value: IOM_AXIS_LY_UP");
static_assert(static_cast<long long>(rage::IOM_AXIS_LY_DOWN) == static_cast<long long>(iosMapperReference::IOM_AXIS_LY_DOWN), "PSC value: IOM_AXIS_LY_DOWN");
static_assert(static_cast<long long>(rage::IOM_AXIS_LX_LEFT) == static_cast<long long>(iosMapperReference::IOM_AXIS_LX_LEFT), "PSC value: IOM_AXIS_LX_LEFT");
static_assert(static_cast<long long>(rage::IOM_AXIS_LX_RIGHT) == static_cast<long long>(iosMapperReference::IOM_AXIS_LX_RIGHT), "PSC value: IOM_AXIS_LX_RIGHT");
static_assert(static_cast<long long>(rage::IOM_AXIS_RY_UP) == static_cast<long long>(iosMapperReference::IOM_AXIS_RY_UP), "PSC value: IOM_AXIS_RY_UP");
static_assert(static_cast<long long>(rage::IOM_AXIS_RY_DOWN) == static_cast<long long>(iosMapperReference::IOM_AXIS_RY_DOWN), "PSC value: IOM_AXIS_RY_DOWN");
static_assert(static_cast<long long>(rage::IOM_AXIS_RX_LEFT) == static_cast<long long>(iosMapperReference::IOM_AXIS_RX_LEFT), "PSC value: IOM_AXIS_RX_LEFT");
static_assert(static_cast<long long>(rage::IOM_AXIS_RX_RIGHT) == static_cast<long long>(iosMapperReference::IOM_AXIS_RX_RIGHT), "PSC value: IOM_AXIS_RX_RIGHT");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON1) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON1), "PSC value: IOM_JOYSTICK_BUTTON1");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON2) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON2), "PSC value: IOM_JOYSTICK_BUTTON2");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON3) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON3), "PSC value: IOM_JOYSTICK_BUTTON3");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON4) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON4), "PSC value: IOM_JOYSTICK_BUTTON4");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON5) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON5), "PSC value: IOM_JOYSTICK_BUTTON5");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON6) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON6), "PSC value: IOM_JOYSTICK_BUTTON6");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON7) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON7), "PSC value: IOM_JOYSTICK_BUTTON7");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON8) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON8), "PSC value: IOM_JOYSTICK_BUTTON8");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON9) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON9), "PSC value: IOM_JOYSTICK_BUTTON9");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON10) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON10), "PSC value: IOM_JOYSTICK_BUTTON10");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON11) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON11), "PSC value: IOM_JOYSTICK_BUTTON11");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON12) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON12), "PSC value: IOM_JOYSTICK_BUTTON12");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON13) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON13), "PSC value: IOM_JOYSTICK_BUTTON13");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON14) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON14), "PSC value: IOM_JOYSTICK_BUTTON14");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON15) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON15), "PSC value: IOM_JOYSTICK_BUTTON15");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON16) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON16), "PSC value: IOM_JOYSTICK_BUTTON16");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON17) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON17), "PSC value: IOM_JOYSTICK_BUTTON17");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON18) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON18), "PSC value: IOM_JOYSTICK_BUTTON18");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON19) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON19), "PSC value: IOM_JOYSTICK_BUTTON19");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON20) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON20), "PSC value: IOM_JOYSTICK_BUTTON20");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON21) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON21), "PSC value: IOM_JOYSTICK_BUTTON21");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON22) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON22), "PSC value: IOM_JOYSTICK_BUTTON22");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON23) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON23), "PSC value: IOM_JOYSTICK_BUTTON23");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON24) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON24), "PSC value: IOM_JOYSTICK_BUTTON24");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON25) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON25), "PSC value: IOM_JOYSTICK_BUTTON25");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON26) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON26), "PSC value: IOM_JOYSTICK_BUTTON26");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON27) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON27), "PSC value: IOM_JOYSTICK_BUTTON27");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON28) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON28), "PSC value: IOM_JOYSTICK_BUTTON28");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON29) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON29), "PSC value: IOM_JOYSTICK_BUTTON29");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON30) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON30), "PSC value: IOM_JOYSTICK_BUTTON30");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON31) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON31), "PSC value: IOM_JOYSTICK_BUTTON31");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_BUTTON32) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_BUTTON32), "PSC value: IOM_JOYSTICK_BUTTON32");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS1) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS1), "PSC value: IOM_JOYSTICK_AXIS1");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS2) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS2), "PSC value: IOM_JOYSTICK_AXIS2");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS3) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS3), "PSC value: IOM_JOYSTICK_AXIS3");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS4) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS4), "PSC value: IOM_JOYSTICK_AXIS4");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS5) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS5), "PSC value: IOM_JOYSTICK_AXIS5");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS6) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS6), "PSC value: IOM_JOYSTICK_AXIS6");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS7) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS7), "PSC value: IOM_JOYSTICK_AXIS7");
static_assert(static_cast<long long>(rage::IOM_JOYSTICK_AXIS8) == static_cast<long long>(iosMapperReference::IOM_JOYSTICK_AXIS8), "PSC value: IOM_JOYSTICK_AXIS8");
static_assert(static_cast<long long>(rage::IOM_POV1_UP) == static_cast<long long>(iosMapperReference::IOM_POV1_UP), "PSC value: IOM_POV1_UP");
static_assert(static_cast<long long>(rage::IOM_POV1_RIGHT) == static_cast<long long>(iosMapperReference::IOM_POV1_RIGHT), "PSC value: IOM_POV1_RIGHT");
static_assert(static_cast<long long>(rage::IOM_POV1_DOWN) == static_cast<long long>(iosMapperReference::IOM_POV1_DOWN), "PSC value: IOM_POV1_DOWN");
static_assert(static_cast<long long>(rage::IOM_POV1_LEFT) == static_cast<long long>(iosMapperReference::IOM_POV1_LEFT), "PSC value: IOM_POV1_LEFT");
static_assert(static_cast<long long>(rage::IOM_POV2_UP) == static_cast<long long>(iosMapperReference::IOM_POV2_UP), "PSC value: IOM_POV2_UP");
static_assert(static_cast<long long>(rage::IOM_POV2_RIGHT) == static_cast<long long>(iosMapperReference::IOM_POV2_RIGHT), "PSC value: IOM_POV2_RIGHT");
static_assert(static_cast<long long>(rage::IOM_POV2_DOWN) == static_cast<long long>(iosMapperReference::IOM_POV2_DOWN), "PSC value: IOM_POV2_DOWN");
static_assert(static_cast<long long>(rage::IOM_POV2_LEFT) == static_cast<long long>(iosMapperReference::IOM_POV2_LEFT), "PSC value: IOM_POV2_LEFT");
static_assert(static_cast<long long>(rage::IOM_POV3_UP) == static_cast<long long>(iosMapperReference::IOM_POV3_UP), "PSC value: IOM_POV3_UP");
static_assert(static_cast<long long>(rage::IOM_POV3_RIGHT) == static_cast<long long>(iosMapperReference::IOM_POV3_RIGHT), "PSC value: IOM_POV3_RIGHT");
static_assert(static_cast<long long>(rage::IOM_POV3_DOWN) == static_cast<long long>(iosMapperReference::IOM_POV3_DOWN), "PSC value: IOM_POV3_DOWN");
static_assert(static_cast<long long>(rage::IOM_POV3_LEFT) == static_cast<long long>(iosMapperReference::IOM_POV3_LEFT), "PSC value: IOM_POV3_LEFT");
static_assert(static_cast<long long>(rage::IOM_POV4_UP) == static_cast<long long>(iosMapperReference::IOM_POV4_UP), "PSC value: IOM_POV4_UP");
static_assert(static_cast<long long>(rage::IOM_POV4_RIGHT) == static_cast<long long>(iosMapperReference::IOM_POV4_RIGHT), "PSC value: IOM_POV4_RIGHT");
static_assert(static_cast<long long>(rage::IOM_POV4_DOWN) == static_cast<long long>(iosMapperReference::IOM_POV4_DOWN), "PSC value: IOM_POV4_DOWN");
static_assert(static_cast<long long>(rage::IOM_POV4_LEFT) == static_cast<long long>(iosMapperReference::IOM_POV4_LEFT), "PSC value: IOM_POV4_LEFT");
