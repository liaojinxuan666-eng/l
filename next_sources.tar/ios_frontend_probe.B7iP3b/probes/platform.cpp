#include <TargetConditionals.h>
#if !defined(__APPLE__) || !(defined(__aarch64__) || defined(__arm64__))
#error "This probe requires the real Apple ARM64 target."
#endif
#if !TARGET_OS_IPHONE || TARGET_OS_SIMULATOR
#error "This probe targets an iOS device, not macOS or the simulator."
#endif
#if !RSG_IOS || !RSG_CPU_ARM64 || RSG_CPU_INTEL || RSG_PC || RSG_ORBIS || RSG_DURANGO
#error "Unexpected RAGE platform selection. Do not spoof another platform."
#endif
static_assert(sizeof(void*) == 8, "64-bit ABI required");
static_assert(__cplusplus >= 201402L, "C++14 required");
