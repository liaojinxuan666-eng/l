Original startup/frontend probe revision 1. Native iOS SOURCE PORT, not emulation.

Findings from prior source archive Git blob a71d3532ebc7e55db39bbb55921b19a9310cf391:
- game/Core/main.cpp:362 creates CApp g_myApp; Main():380 is not the actual entry.
- rage/base/src/system/main.cpp:187-189 and :234-246 use project lifecycle callbacks.
  The registration/implementation needs the actual CApp/framework source.
- CGame::PreLoadingScreensInit in game/Core/game.cpp:940 invokes loading screens,
  shader initialization, streaming/data-file setup, startup/default configuration,
  Scaleform core initialization and text loading. It is not an isolated UI demo.
- scaleform/scaleform.cpp:1917 creates GFxSystem/GFxLoader and an sfRenderer.
  LoadMovie:2249 can load a texture dictionary; :2300 calls GFxLoader::CreateMovie.
- scaleform/renderer.cpp:525 needs Short2 and packed-color vertex layouts;
  :663-694 loads scaleform_shaders and effect variables/techniques. It also uses
  indexed drawing, blend state, stencil and texture objects not supplied by the cube.
- Scaleform wrapper headers refer to ../../../scaleform/Include, i.e. rage/scaleform.
  Framework references are to rage/framework/src, not dev_ng/framework/src.
- GEN9_LANDING_PAGE_ENABLED guards exist. Do not enable them or PC/console macros
  simply to expose another platform's menu. Inspect the original build guards.

Current package purpose: exact CApp, boot/landing page, game Scaleform manager,
framework and file/device dependencies, plus real PHONE syntax diagnostics.
No engine files modified. No project scripts executed. No app installed/launched.
No credentials, game assets or external Apple SDK copied. Selected bundled
Scaleform source/headers are included when locally present; binary libraries are
names only. No downloads, network uploads or entitlement/configuration changes.
Review before sharing. Missing optional files or caps yield a partial collection.
Copies use dev_ng-relative paths; checksums identify copied bytes.
include_path_audit.tsv checks literal includes using the exploratory include roots.
Columns: status, source path, line, literal include, matched indexed path.
CASE_ONLY/BACKSLASH entries are path-portability hints, not automatic patches.
NOT_IN_SOURCE_INDEX can mean a system header, excluded path or different include
root; it is NOT proof that a dependency is missing. Macro includes are not audited.
This text audit does not preprocess guards; inactive branches are included too.
Source caps: 110 files, 4 MiB per file, 16 MiB total; inventory cap 8 MiB.
Syntax PASS is not object/link/runtime/Scaleform/movie/main-menu success.
Compiler probes use live -I paths, not collected copies or fake declarations.
Only listed source files are checked for concurrent changes; this is not a
transactional snapshot of every transitive header in the full engine tree.
The working textured-cube backend stays untouched and is a regression baseline.
This script intentionally DOES NOT generate an IPA or a replacement menu.
