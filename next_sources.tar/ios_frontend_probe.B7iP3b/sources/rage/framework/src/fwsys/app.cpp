//
// fwsys/app.cpp
//
// Copyright (C) 1999-2010 Rockstar Games.  All Rights Reserved.
//

#include "app.h"

namespace rage
{

} // namespace rage