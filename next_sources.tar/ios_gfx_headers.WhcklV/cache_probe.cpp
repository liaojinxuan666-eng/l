#include "grcore/effect.h"
#include <type_traits>
namespace rage {
	typedef std::map< u32, grcCBuffer*, std::less<u32>, CacheAllocator<std::pair<const u32, grcCBuffer*>> > CBufCacheMap;
	typedef std::map< u32, grcShader*, std::less<u32>, CacheAllocator<std::pair<const u32, grcShader*>> > CacheMap;
	typedef std::map< u32, char*, std::less<u32>, CacheAllocator<std::pair<const u32, char*>> > CacheNameMap;
static_assert(std::is_same<CacheMap::allocator_type::value_type, CacheMap::value_type>::value, "shader cache allocator");
static_assert(std::is_same<CBufCacheMap::allocator_type::value_type, CBufCacheMap::value_type>::value, "buffer cache allocator");
static_assert(std::is_same<CacheNameMap::allocator_type::value_type, CacheNameMap::value_type>::value, "name cache allocator");
int iosGfxCacheInstantiation() {
    CacheMap shader; CBufCacheMap buffer; CacheNameMap names;
    shader[1] = nullptr; buffer[2] = nullptr; names[3] = nullptr;
    return shader.find(1)==shader.end() || buffer.find(2)==buffer.end() || names.find(3)==names.end();
}
}
