#include <cstdint>
#include <cstddef>
#include <type_traits>
#include "grcore/config.h"
#include "grcore/wrapper_gcm.h"
#if !RSG_IOS || !RSG_CPU_ARM64 || !__METAL || __GCM || __PPU || __SPU || __WIN32 || RSG_ORBIS
#error "Expected iOS Metal selection without GCM APIs"
#endif
#ifdef GCM_STATE
#error "GCM command macros must remain unavailable on iOS"
#endif
static_assert(sizeof(CellGcmTexture)==24 && alignof(CellGcmTexture)==4, "legacy record layout");
static_assert(std::is_standard_layout<CellGcmTexture>::value, "legacy standard layout");
static_assert(std::is_trivially_copyable<CellGcmTexture>::value, "legacy copy layout");
static_assert(offsetof(CellGcmTexture,format)==0, "format offset");
static_assert(offsetof(CellGcmTexture,mipmap)==1, "mipmap offset");
static_assert(offsetof(CellGcmTexture,dimension)==2, "dimension offset");
static_assert(offsetof(CellGcmTexture,cubemap)==3, "cubemap offset");
static_assert(offsetof(CellGcmTexture,remap)==4, "remap offset");
static_assert(offsetof(CellGcmTexture,width)==8, "width offset");
static_assert(offsetof(CellGcmTexture,height)==10, "height offset");
static_assert(offsetof(CellGcmTexture,depth)==12, "depth offset");
static_assert(offsetof(CellGcmTexture,location)==14, "location offset");
static_assert(offsetof(CellGcmTexture,_padding)==15, "_padding offset");
static_assert(offsetof(CellGcmTexture,pitch)==16, "pitch offset");
static_assert(offsetof(CellGcmTexture,offset)==20, "offset offset");
namespace rage {
struct grcCellGcmTextureWrapper : CellGcmTexture
{
	inline void	SetWidth( uint16_t in) { width = in; }
	inline uint16_t GetWidth() const { return width; }; 
	inline void	SetHeight( uint16_t in) { height = in; }
	inline uint16_t GetHeight() const { return height; }; 
	inline void	SetDepth( uint16_t in) { depth = in; }
	inline uint16_t GetDepth() const { return depth; }; 

	inline void	SetFormat( uint8_t in) { format = in; }
	inline uint8_t GetFormat() const { return format; }; 
	inline void	SetDimension( uint8_t in) { dimension = in; }
	inline uint8_t GetDimension() const { return dimension; }; 
	inline void	SetMipMap( uint8_t in) { mipmap = in; }
	inline uint8_t GetMipMap() const { return mipmap; }; 
	inline void	SetBindFlag( uint8_t in) { _padding = in; }
	inline uint8_t GetBindFlag() const { return _padding; }; 
	inline void	SetTileMode( uint8_t in) { location = in; }
	inline uint8_t GetTileMode() const { return location; }; 
	inline void	SetImageType( uint8_t in) { cubemap = in; }
	inline uint8_t GetImageType() const { return cubemap; }; 

	inline void	SetOwnsMem( uint32_t in) { remap = in; }
	inline uint32_t GetOwnsMem() const { return remap; }; 
	inline void	SetUsesPreAllocatedMem( uint32_t in) { pitch = in; }
	inline uint32_t GetUsesPreAllocatedMem() const { return pitch; }; 
};


}
static_assert(sizeof(rage::grcCellGcmTextureWrapper)==24, "wrapper layout");
int iosGfxTextureMetadataCheck() {
    rage::grcCellGcmTextureWrapper t{};
    t.SetWidth(65535); t.SetHeight(1024); t.SetDepth(16);
    t.SetFormat(255); t.SetDimension(3); t.SetMipMap(12);
    t.SetBindFlag(0x5a); t.SetTileMode(2); t.SetImageType(1);
    t.SetOwnsMem(0x12345678u); t.SetUsesPreAllocatedMem(0x87654321u);
    t.offset=0x13572468u;
    return !(t.GetWidth()==65535 && t.GetHeight()==1024 && t.GetDepth()==16 &&
        t.GetFormat()==255 && t.GetDimension()==3 && t.GetMipMap()==12 &&
        t.GetBindFlag()==0x5a && t.GetTileMode()==2 && t.GetImageType()==1 &&
        t.GetOwnsMem()==0x12345678u && t.GetUsesPreAllocatedMem()==0x87654321u &&
        t.offset==0x13572468u);
}
