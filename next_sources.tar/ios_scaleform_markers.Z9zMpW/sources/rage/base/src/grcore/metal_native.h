#ifndef GRCORE_METAL_NATIVE_H
#define GRCORE_METAL_NATIVE_H

#include <stddef.h>
#include <stdint.h>

struct grcMetalContext;
#ifdef __OBJC__
@class CAMetalLayer;
#endif

namespace rage {

// Bring-up scope: one device, main thread, full-target clears, synchronous GPU
// completion. metal_draw.h adds a restricted explicit native drawing path.
// metal_texture.h adds native RGBA8 upload/sampling; no legacy resource loader.
// No sub-viewports or MSAA.
// Call Configure*, then grcDevice::InitClass. No silent offscreen fallback.
bool grcMetalConfigureOffscreen(unsigned width, unsigned height);
#ifdef __OBJC__
// Host owns the UIView/window. This backend retains the attached layer until
// Shutdown, configures BGRA8Unorm, and uses drawableSize in physical pixels.
// All host changes to this layer must be serialized on the main thread.
bool grcMetalConfigureLayer(CAMetalLayer *layer, unsigned width, unsigned height);
#endif
bool grcMetalInitialize();
bool grcMetalShutdown();
bool grcMetalBeginFrame();
bool grcMetalClear(bool color, float r, float g, float b, float a,
                   bool depth, float z, bool stencil, uint32_t s);
bool grcMetalEndFrame();

// Readback is diagnostic, offscreen-only, after a successful EndFrame. BGRA8.
// rowBytes >= width*4; capacity >= (height-1)*rowBytes + width*4.
bool grcMetalReadback(void *bytes, size_t capacity, size_t rowBytes);
grcMetalContext *grcMetalGetContext();
unsigned grcMetalWidth();
unsigned grcMetalHeight();
uint64_t grcMetalCompletedFrames();
const char *grcMetalDeviceName();
const char *grcMetalLastError();

} // namespace rage
#endif
