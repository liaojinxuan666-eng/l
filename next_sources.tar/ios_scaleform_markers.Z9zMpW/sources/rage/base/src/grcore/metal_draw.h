#ifndef GRCORE_METAL_DRAW_H
#define GRCORE_METAL_DRAW_H
#include <stdint.h>
#include <stddef.h>
struct grcMetalVertexShader;
struct grcMetalPixelShader;
namespace rage {
// Stream 0. Original RAGE FVF semantic slots: POSITION0=0, COLOR0=4, UV0=6.
// Float2/3/4 position, Float4 color, optional Float2 UV. No packed attributes.
enum grcMetalVertexFormat { metalFloat2=2, metalFloat3=3, metalFloat4=4 };
struct grcMetalVertexLayout {
    struct Attribute { uint32_t slot, format, offset; } attributes[3];
    uint32_t count, stride;
};
inline bool grcMetalValidateLayout(const grcMetalVertexLayout& l) {
    if ((l.count!=2 && l.count!=3) || !l.stride || l.stride>256 || l.stride%4) return false;
    unsigned mask=0;
    for (unsigned i=0; i<l.count; ++i) {
        const auto& a=l.attributes[i];
        if ((a.slot!=0 && a.slot!=4 && a.slot!=6) || a.format<2 || a.format>4 ||
            (a.slot==4 && a.format!=4) || (a.slot==6 && a.format!=2) || a.offset%4 ||
            a.offset>l.stride || a.format*4>l.stride-a.offset || (mask&(1u<<a.slot))) return false;
        mask|=1u<<a.slot;
        for (unsigned j=0; j<i; ++j) {
            const auto& b=l.attributes[j];
            if (!(a.offset+a.format*4<=b.offset || b.offset+b.format*4<=a.offset)) return false;
        }
    }
    return mask==(l.count==2 ? 17u : 81u);
}
// Register address/count are float4 units, matching grcDevice::SetVertexShaderConstant.
// Each draw snapshots all 64 registers to Metal vertex buffer slot 1; vertices use 0.
struct grcMetalVertexConstants {
    float values[64][4] = {};
    uint64_t written = 0;
};
inline bool grcMetalWriteConstants(grcMetalVertexConstants& c, int first, const float *data, int count) {
    if (first<0 || first>64 || count<0 || count>64-first || (count && !data)) return false;
    for (int i=0; i<count; ++i) {
        for (unsigned j=0; j<4; ++j) c.values[first+i][j]=data[i*4+j];
        c.written|=uint64_t(1)<<(first+i);
    }
    return true;
}
bool grcMetalSetVertexConstants(int first, const float *data, int count);
// Main thread only, after InitClass and outside a frame. MSL SOURCE, not DXBC.
bool grcMetalCreateShaders(const char *msl, const char *vertexEntry, const char *fragmentEntry,
                          ::grcMetalVertexShader **vs, ::grcMetalPixelShader **ps);
void grcMetalDestroyShaders(::grcMetalVertexShader *vs, ::grcMetalPixelShader *ps);
bool grcMetalBindVertexShader(::grcMetalVertexShader *vs);
bool grcMetalBindPixelShader(::grcMetalPixelShader *ps);
bool grcMetalBindLayout(const grcMetalVertexLayout *layout);
bool grcMetalPrepareDraw();
// Triangle lists only; 4 MiB maximum per batch. Buffers are not reused in flight.
void *grcMetalBeginVertices(uint32_t count, uint32_t stride);
bool grcMetalSealVertices(uint32_t count);
bool grcMetalDrawVertices(uint32_t count);
bool grcMetalReleaseVertices(uint32_t count);
bool grcMetalEndPointerCount(const void *end, uint32_t *count);
uint64_t grcMetalEncodedDraws();
} // namespace rage
#endif
