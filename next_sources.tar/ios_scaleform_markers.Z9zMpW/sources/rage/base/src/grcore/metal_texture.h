#ifndef GRCORE_METAL_TEXTURE_H
#define GRCORE_METAL_TEXTURE_H
#include <stddef.h>
#include <stdint.h>
struct grcMetalTexture;
struct grcMetalVertexShader;
struct grcMetalPixelShader;
namespace rage {
// Explicit native upload API. This is NOT grcTextureFactory or an RSC/YTD loader.
// RGBA8Unorm, top row first, one 2D image, one mip, 1..4096 each dimension.
// Uploads copy caller bytes and are permitted only between completed frames.
inline bool grcMetalValidRGBA8(unsigned w,unsigned h,size_t rowBytes,size_t capacity) {
    if (!w || !h || w>4096 || h>4096) return false;
    const size_t row=(size_t)w*4;
    if (rowBytes<row || rowBytes%4 || rowBytes>SIZE_MAX/(size_t)h) return false;
    return capacity>=(size_t)(h-1)*rowBytes+row;
}
bool grcMetalCreateRGBA8(unsigned w,unsigned h,const void *bytes,size_t rowBytes,size_t capacity,
                         ::grcMetalTexture **output);
bool grcMetalUpdateRGBA8(::grcMetalTexture *texture,const void *bytes,size_t rowBytes,size_t capacity);
// A bound Metal texture is retained separately, as are encoded draw resources.
// Caller handles become invalid after Destroy; surviving handles cannot cross Init sessions.
void grcMetalDestroyTexture(::grcMetalTexture *texture);
bool grcMetalBindTexture(unsigned stage,const ::grcMetalTexture *texture);
// Stage 0 only. Point/linear min+mag, clamp-to-edge/repeat UV, normalized coords.
bool grcMetalSetSampler(bool linear,bool repeat);
// Explicit textured shader contract: position/color/UV0 input, float4 registers
// at vertex buffer(1), first four initialized; fragment texture(0), sampler(0).
// MSL source only. Legacy game shader resources are not accepted here.
bool grcMetalCreateTexturedShaders(const char *msl,const char *ve,const char *fe,
                                  ::grcMetalVertexShader **vs,::grcMetalPixelShader **ps);
}
#endif
