#include "grcore/device.h"
#ifndef GRCDBG_IMPLEMENTED
#error "Expected RAGE debug-marker configuration"
#elif GRCDBG_IMPLEMENTED
#error "This patch has not validated an enabled iOS fault-context backend"
#endif
#ifndef GRCDBG_PUSH
#error "Existing RAGE portable marker interface required"
#endif
#ifndef GRCDBG_POP
#error "Existing RAGE portable marker interface required"
#endif
void iosScaleformMarkerContract() {
    GRCDBG_PUSH("Scaleform Rendering");
    GRCDBG_POP();
}
