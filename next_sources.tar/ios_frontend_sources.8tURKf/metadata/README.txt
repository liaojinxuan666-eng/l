Original GTA5 startup/frontend discovery, collector revision 1.
Objective: inspect the original game startup -> frontend -> resource loading
dependencies before choosing the next native iOS source-port implementation.
This is not a replica menu, a GTA5 build, or proof of frontend availability.

Only copies of selected C/C++ source and build descriptions are collected.
Nothing from the source tree is executed. No engine files are modified.
No IPA, game assets, saved games, credentials, SDKs or binaries are collected.
No automatic network transfer. Review the archive before manually sharing it.
The existing textured-cube app and backend are not changed.

Paths in sources/ are relative to the dev_ng directory, not rage/base/src.
source_paths.txt: filtered filename inventory for game, framework/src, base.
candidates.tsv: heuristic category, priority, relative path (not dependencies).
selected.tsv: category, byte size, copied relative path.
Categories: 0 platform checkpoint, 1 startup, 2 frontend, 3 UI, 4 resources,
5 build descriptions. entry_hints.txt is limited to 60 matches per file.
Build descriptions are read as text only; their commands are never run.

Caps: 2 MiB per file; 100 source files; 12 MiB total source bytes;
category limits keep early matches from consuming the whole packet.
Source roots must not be symlinks. Hidden, backup, unity, build, vendor and
SDK paths are excluded. Symlinks are not followed during copying.
Missing roots, excluded symlinks and cap omissions are reported in notes.txt.
PARTIAL_COLLECTION is usable for discovery; it is not a compiler failure.
Even a complete selected collection is NOT the full dependency closure.
External libraries/headers/assets and runtime initialization may still be absent.
Checksums identify these source bytes, not compiled or runtime correctness.
