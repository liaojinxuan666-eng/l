RAGE iOS native Metal device slice, revision 1

This adds source, not API translation. No existing engine headers are edited.
New source files: grcore/metal_native.h, metal_native.mm, device_metal.cpp.

Implemented engine methods: InitClass, ShutdownClass, BeginFrame, Clear,
EndFrame, and SetWindow restricted to the default full viewport.
The source links a native MTLDevice, MTLCommandQueue, BGRA8 target and
Depth32Float_Stencil8 target. EndFrame commits and waits for GPU completion.
This deliberately synchronous implementation is for bring-up, not performance.
All entrypoints require the iOS main thread. Additional render workers are not
supported. EndFrame with any non-null resolve flags is rejected. Other device
methods remain UNDEFINED; this does not make the whole engine link.

Validation:
  sh ios_metal_device.sh          build/link/install then try GPU readback
  sh ios_metal_device.sh build    build/link/install only
Run in rage/base/src with the earlier iOS graphics header fixes installed.
A missing SDK/linker/signing/runtime permission is reported as a failure, not
silently replaced with a mocked GPU. ldid, if present, ad-hoc signs only this
new executable, with no entitlements. Do not run the test as root to hide errors.

The probe calls the actual grcDevice methods, checks all BGRA pixels after
four offscreen frames, verifies color preservation under depth/stencil-only
clears, checks bad readback bounds, and checks shutdown/reinitialization.
It does NOT verify depth/stencil sample values, onscreen presentation, shaders,
meshes, native texture loading, grcSetup startup, or the full game.
The script's successful compile/link results refer to original engine headers;
only NEW source files are staged. Installation compares exact source bytes.
No .cpp is compiled with invented replacement engine headers on the phone.

For future app-host integration (not provided or tested here):
  In Objective-C++ on the main thread, attach a real UIView-backed CAMetalLayer
  with rage::grcMetalConfigureLayer(layer, pixelWidth, pixelHeight), then call
  grcDevice::InitClass(false,false). The layer is retained by the backend.
  Set the UIView bounds and layer contentsScale in your host, and update its
  drawableSize on layout. Zero-size/no drawable makes BeginFrame return false;
  skip Clear/EndFrame when it returns false. Pause rendering in the background.
  A successful frame uses presentDrawable before commit. Every drawable must
  be cleared because a new drawable's previous contents are unspecified.
  Shutdown releases backend references and clears layer.device if still owned.
  UIKit view/window, lifecycle integration, app packaging and signing remain
  separate work. Do not call this a finished renderer or game port.

Build integration: compile device_metal.cpp with -include forceinclude/ios_master.h
and metal_native.mm separately with -fobjc-arc -fblocks WITHOUT that forceinclude.
Both use C++14. Link Metal, Foundation, QuartzCore. Add these files exactly once
to a future iOS target; do not add other platforms' device implementations.

Apple references used for lifecycle design:
https://developer.apple.com/library/archive/documentation/3DDrawing/Conceptual/MTLBestPracticesGuide/Drawables.html
https://developer.apple.com/documentation/metal/mtlcommandbuffer
https://developer.apple.com/documentation/metal/mtlstoragemode/shared

Host verification is limited to shell orchestration, C++ adapter contracts and
negative tests using explicitly labeled fixtures. This workspace has no Apple
SDK/clang, so the Objective-C++ source must be compiled and run on the phone.
