// This executable links the real device_metal.cpp and metal_native.mm.
// It is a backend integration test, not grcSetup, GTA5, UIKit or onscreen output.
#include "grcore/device.h"
#include "grcore/metal_native.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

using namespace rage;

static void check(bool ok, const char *name) {
    if (!ok) {
        fprintf(stderr, "PROBE_FAIL: %s: %s\n", name, grcMetalLastError());
        exit(1);
    }
}
static void pixels(unsigned char r, unsigned char g, unsigned char b, unsigned char a) {
    unsigned char bytes[8 * 8 * 4];
    memset(bytes, 0xA5, sizeof(bytes));
    check(grcMetalReadback(bytes, sizeof(bytes), 8 * 4), "readback");
    const unsigned char expected[4] = {b, g, r, a};
    for (size_t i = 0; i < sizeof(bytes); ++i) {
        const int delta = (int)bytes[i] - (int)expected[i % 4];
        if (delta < -1 || delta > 1) {
            fprintf(stderr, "PIXEL_MISMATCH: byte=%zu actual=%u expected=%u\n",
                    i, (unsigned)bytes[i], (unsigned)expected[i % 4]);
            exit(1);
        }
    }
}

int main() {
    puts("SCOPE: actual grcDevice Metal clear backend; offscreen, NOT GTA5/onscreen.");
    check(!grcMetalInitialize(), "unconfigured initialization must fail");
    check(!grcMetalConfigureOffscreen(0, 8), "zero target must fail");
    check(grcMetalConfigureOffscreen(8, 8), "configure");
    grcDevice::InitClass(false, false);
    check(g_grcCurrentContext != NULL, "engine TLS context");
    printf("DEVICE: %s\n", grcMetalDeviceName());
    unsigned char tiny[4];
    check(!grcMetalReadback(tiny, sizeof(tiny), 4), "read before frame must fail");
    grcWindow window;
    grcDevice::SetWindow(window);
    check(grcDevice::BeginFrame(), "first BeginFrame");
    grcDevice::Clear(true, Color32(17, 85, 204, 255), true, 1.f, true, 7);
    grcDevice::EndFrame();
    pixels(17, 85, 204, 255);
    check(!grcMetalReadback(tiny, sizeof(tiny), 32), "short buffer must fail");
    check(grcDevice::BeginFrame(), "second BeginFrame");
    grcDevice::Clear(false, Color32(255, 0, 0, 0), true, 0.25f, false, 0);
    grcDevice::Clear(false, Color32(0, 0, 0, 0), false, 0.f, true, 3);
    grcDevice::EndFrame();
    pixels(17, 85, 204, 255); // depth/stencil-only passes must preserve color
    check(grcDevice::BeginFrame(), "third BeginFrame");
    grcDevice::Clear(true, Color32(230, 51, 9, 128), false, 0.f, false, 0);
    grcDevice::EndFrame();
    pixels(230, 51, 9, 128);
    check(grcMetalCompletedFrames() == 3, "three completed GPU submissions");
    grcDevice::ShutdownClass();
    check(!g_grcCurrentContext, "TLS context released");
    check(!grcDevice::BeginFrame(), "begin after shutdown must fail");
    check(grcMetalConfigureOffscreen(8, 8), "configure after shutdown");
    grcDevice::InitClass(false, false);
    check(grcDevice::BeginFrame(), "reinitialized BeginFrame");
    grcDevice::Clear(true, Color32(0, 255, 0, 255), true, 1.f, true, 0);
    grcDevice::EndFrame();
    pixels(0, 255, 0, 255);
    grcDevice::ShutdownClass();
    puts("METAL_GPU_PASS: engine entrypoints, 4 completed frames, all BGRA pixels checked.");
    puts("LIMIT: no UIKit presentation, shaders, meshes, texture loader or full-engine link tested.");
    return 0;
}
