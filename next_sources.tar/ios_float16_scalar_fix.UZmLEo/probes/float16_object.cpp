#include "math/float16.h"
static_assert(sizeof(rage::Float16) == 2, "legacy Float16 storage width");
// This is a real engine-header object check; remaining color intrinsics may fail.
rage::ScalarV_Out iosFloat16Read(const rage::Float16& value) {
    return value.GetFloat32_FromFloat16_ScalarV();
}
