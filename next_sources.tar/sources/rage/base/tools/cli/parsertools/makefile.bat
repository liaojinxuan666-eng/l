set LIBS=%RAGE_CORE_LIBS% %RAGE_GFX_LIBS%
set TESTERS=parsertool
set XPROJ=%RAGE_DIR%\base\src
set FILES=psoprinter


