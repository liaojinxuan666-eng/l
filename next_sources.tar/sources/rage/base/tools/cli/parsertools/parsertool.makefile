Project parsertool
ConfigurationType exe
RootDirectory .

Files {
	parsertool.cpp
	psoprinter.cpp
	psoprinter.h
}

Include %RAGE_DIR%\base\src\vcproj\ragecore\RageCore.libdefs
