#!/bin/sh
set -eu
export LC_ALL=C
fp_out=$(cd "$(dirname "$0")" && pwd -P)
fp_root=$(cat "$fp_out/metadata/dev_ng_path.txt")
cd "$fp_root"
. "$fp_out/restore_functions.sh"
fp_temp=''
fp_lock="$fp_root/rage/base/src/ios_frontend_paths.lock"
mkdir "$fp_lock" 2>/dev/null || { echo 'STOP: existing patch/rollback lock.'; exit 1; }
trap '[ -z "$fp_temp" ] || rm -f "$fp_temp"; rmdir "$fp_lock" 2>/dev/null || :' 0
trap 'exit 130' INT
trap 'exit 143' HUP TERM
fp_restore_all
echo 'ROLLBACK_DONE: restored only the headers changed by this run.'
