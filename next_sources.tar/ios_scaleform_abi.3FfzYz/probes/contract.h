#if !defined(GFC_OS_IPHONE) || !defined(GFC_CPU_ARM64) || !defined(GFC_64BIT_POINTERS)
#error "Scaleform iOS ARM64/64-bit-pointer selection missing"
#endif
#if defined(GFC_CPU_ARM) || defined(GFC_CPU_X86) || defined(GFC_CPU_X86_64) || defined(GFC_CPU_OTHER)
#error "ARM64 must not select old ARMv7, Intel, or unknown CPU"
#endif
#if GFC_BYTE_ORDER != GFC_LITTLE_ENDIAN
#error "Expected little-endian iOS ARM64"
#endif
static_assert(sizeof(SInt8)==1 && sizeof(UInt8)==1, "8-bit widths");
static_assert(sizeof(SInt16)==2 && sizeof(UInt16)==2, "16-bit widths");
static_assert(sizeof(SInt32)==4 && sizeof(UInt32)==4, "32-bit widths");
static_assert(sizeof(SInt64)==8 && sizeof(UInt64)==8, "64-bit widths");
static_assert(SInt8(-1)<0 && UInt8(-1)>0 && SInt16(-1)<0 && UInt16(-1)>0, "8/16 signedness");
static_assert(SInt32(-1)<0 && UInt32(-1)>0 && SInt64(-1)<0 && UInt64(-1)>0, "32/64 signedness");
static_assert(sizeof(UPInt)==sizeof(void*) && sizeof(SPInt)==sizeof(void*), "pointer integer widths");
static_assert(SPInt(-1)<0 && UPInt(-1)>0 && UPInt(GFC_MAX_UPINT)==UPInt(-1), "pointer range");
template<class A, class B> struct SF_ABI_Same { static const bool value=false; };
template<class A> struct SF_ABI_Same<A,A> { static const bool value=true; };
static_assert(SF_ABI_Same<SInt32,int>::value && SF_ABI_Same<UInt32,unsigned int>::value, "Apple 32-bit identity");
static_assert(SF_ABI_Same<SInt64,long long>::value && SF_ABI_Same<UInt64,unsigned long long>::value, "Apple 64-bit identity");
inline int sf_abi_overload(UInt32) { return 32; }
inline int sf_abi_overload(UInt64) { return 64; }
inline int sf_abi_signed_overload(SInt32) { return 32; }
inline int sf_abi_signed_overload(SInt64) { return 64; }
