#include "platform.h"
#include "selected_types.h"
#include "contract.h"
