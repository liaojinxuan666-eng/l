#!/bin/sh
set -eu
export LC_ALL=C
rb_dir=$(cd "$(dirname "$0")" && pwd -P)
rb_root=$(cat "$rb_dir/metadata/dev_ng_path.txt")
cd "$rb_root"
rb_file=rage/scaleform/Include/GTypes.h
rb_parent=$rb_file
while :; do
    [ ! -L "$rb_parent" ] || { echo 'STOP: symlink in source path.'; exit 1; }
    case "$rb_parent" in */*) rb_parent=${rb_parent%/*} ;; *) break ;; esac
done
cmp -s "$rb_file" "$rb_dir/before/GTypes.h" && { echo 'Already at pre-run version.'; exit 0; }
cmp -s "$rb_file" "$rb_dir/candidate/GTypes.h" || { echo 'STOP: source changed after patch; not overwritten.'; exit 1; }
rb_lock="$rb_root/rage/base/src/ios_scaleform_abi.lock"
mkdir "$rb_lock" 2>/dev/null || { echo 'STOP: patch/rollback lock exists.'; exit 1; }
rb_tmp=''
trap '[ -z "$rb_tmp" ] || rm -f "$rb_tmp"; rmdir "$rb_lock" 2>/dev/null || :' 0
trap 'exit 130' INT
trap 'exit 143' HUP TERM
rb_tmp=$(mktemp "${rb_file}.restore.XXXXXX")
cp -p "$rb_dir/before/GTypes.h" "$rb_tmp"
cmp -s "$rb_file" "$rb_dir/candidate/GTypes.h" || { echo 'STOP: concurrent source edit.'; exit 1; }
mv "$rb_tmp" "$rb_file"
rb_tmp=''
echo 'RESTORED: pre-run GTypes.h only.'
