//
// fwtl/nameregistrar.h
//
// Copyright (C) 1999-2011 Rockstar Games.  All Rights Reserved.
//

#include "nameregistrar.h"

#include "atl/map.h"

namespace rage {



} // namespace rage