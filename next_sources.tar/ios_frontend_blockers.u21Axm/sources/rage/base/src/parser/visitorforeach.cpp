// 
// parser/visitorforeach.cpp 
// 
// Copyright (C) 1999-2007 Rockstar Games.  All Rights Reserved. 
// 

#include "visitorforeach.h"

namespace rage {

} // namespace rage
