// 
// parser/ifffile.cpp
// 
// Copyright (C) 1999-2011 Rockstar Games.  All Rights Reserved. 
// 

#include "ifffile.h"

#include "optimisations.h"

PARSER_OPTIMISATIONS();

