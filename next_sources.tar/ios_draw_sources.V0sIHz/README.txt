Native RAGE iOS drawing source checkpoint, collector revision 1.
The last foreground UIKit/Metal clear test has been reported successful:
Apple A12 GPU, 1242x2688, 120 completed submissions; user confirmed blue/green.
The console-process nil-device cause is still undiagnosed.

This archive contains COPIES of the current source and a definition index.
It makes no changes to engine files and does not compile, install or draw.
No game data, signing credentials, binaries or SDK headers are collected.
Missing optional filenames and size-limited files are listed in notes.txt.
The search covers grcore source files and one platform-subdirectory level.

Needed for the next source-port step:
- Actual vertex element format/stride/declaration ownership conventions.
- BeginVertices / EndCreateVertices / DrawVertices / ReleaseVertices semantics.
- Vertex/pixel shader creation and binding interfaces and platform guards.
Reference implementations are read for those contracts, not executed/emulated.
Current iOS vertex declarations must not silently use a PSP fallback layout.

Upload next_sources.tar to the existing transfer repository when requested.
The script does not perform any automatic network upload.
