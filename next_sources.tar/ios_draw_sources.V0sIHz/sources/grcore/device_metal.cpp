// Native iOS grcDevice slice. Intentionally leaves unsupported graphics
// methods undefined. Do not add empty implementations to make the game link.
#include "grcore/config.h"
#if RSG_IOS && __METAL
#include "grcore/device.h"
#include "metal_native.h"
#include <stdio.h>
#include <stdlib.h>
#include <type_traits>

#if !RSG_CPU_ARM64 || RSG_CPU_INTEL || __RESOURCECOMPILER || __TOOL
#error Expected the actual iOS ARM64 runtime configuration.
#endif

namespace rage {
static_assert(std::is_same<grcContextHandle, ::grcMetalContext>::value,
              "Expected the typed iOS context from the graphics header patch.");
__THREAD grcContextHandle *g_grcCurrentContext = NULL;
grcDisplayWindow grcDevice::sm_CurrentWindows[NUMBER_OF_RENDER_THREADS];
grcDisplayWindow grcDevice::sm_GlobalWindow;

namespace {
void requireMetal(bool ok, const char *operation) {
    if (!ok) {
        // Do not depend on ASSERT/FINAL switches for safety during bring-up.
        fprintf(stderr, "METAL_FATAL: %s: %s\n", operation, grcMetalLastError());
        abort();
    }
}
void unsupported(const char *operation) {
    fprintf(stderr, "METAL_UNSUPPORTED: %s\n", operation);
    abort();
}
} // namespace

void grcDevice::InitClass(bool inWindow, bool topMost) {
    // UIKit host owns window placement and fullscreen behavior on iOS.
    (void)inWindow;
    if (topMost) unsupported("top-most window request");
    if (sm_CurrentWindows[0].uWidth &&
        (sm_CurrentWindows[0].uWidth != grcMetalWidth() ||
         sm_CurrentWindows[0].uHeight != grcMetalHeight()))
        unsupported("SetSize and configured target dimensions differ");
    requireMetal(grcMetalInitialize(), "InitClass");
    g_grcCurrentContext = grcMetalGetContext();
    for (int i = 0; i < NUMBER_OF_RENDER_THREADS; ++i)
        sm_CurrentWindows[i].Init(grcMetalWidth(), grcMetalHeight(), 0, false, 0);
    sm_GlobalWindow = sm_CurrentWindows[0];
}

void grcDevice::ShutdownClass() {
    requireMetal(grcMetalShutdown(), "ShutdownClass");
    g_grcCurrentContext = NULL;
    for (int i = 0; i < NUMBER_OF_RENDER_THREADS; ++i)
        sm_CurrentWindows[i].Init(0, 0, 0, false, 0);
    sm_GlobalWindow = sm_CurrentWindows[0];
}

bool grcDevice::BeginFrame() {
    if (!grcMetalBeginFrame()) return false; // includes missing drawable
    sm_CurrentWindows[0].uWidth = grcMetalWidth();
    sm_CurrentWindows[0].uHeight = grcMetalHeight();
    sm_GlobalWindow = sm_CurrentWindows[0];
    return true;
}

void grcDevice::Clear(bool color, Color32 value, bool depth, float z,
                       bool stencil, u32 s) {
    requireMetal(grcMetalClear(color, value.GetRedf(), value.GetGreenf(),
        value.GetBluef(), value.GetAlphaf(), depth, z, stencil, s), "Clear");
}

void grcDevice::EndFrame(const grcResolveFlags *flags) {
    if (flags) unsupported("clear-during-resolve flags (use EndFrame(NULL))");
    requireMetal(grcMetalEndFrame(), "EndFrame");
}

void grcDevice::SetWindow(const grcWindow& window) {
    // Load-action clears cover the full attachment; scissor rectangles do not
    // restrict them. Reject partial viewport requests instead of over-clearing.
    if (window.GetNormX() != 0 || window.GetNormY() != 0 ||
        window.GetNormWidth() != 1 || window.GetNormHeight() != 1 ||
        window.GetMinZ() != 0 || window.GetMaxZ() != 1)
        unsupported("partial viewport or non-default depth range");
}
} // namespace rage
#endif
