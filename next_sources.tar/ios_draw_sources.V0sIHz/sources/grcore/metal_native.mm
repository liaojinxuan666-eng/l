// Native Metal implementation. Compile separately with ARC, without RAGE's
// forceinclude header; engine types stay on the C++ side of metal_native.h.
#include "metal_native.h"
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#include <TargetConditionals.h>
#include <pthread.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

#if !TARGET_OS_IPHONE || TARGET_OS_SIMULATOR || !defined(__aarch64__)
#error This backend must be built for a physical iOS ARM64 device.
#endif
#if !__has_feature(objc_arc)
#error Compile metal_native.mm with -fobjc-arc.
#endif

struct grcMetalContext {
    enum Target { Unconfigured, Offscreen, Layer } target = Unconfigured;
    id<MTLDevice> device = nil;
    id<MTLCommandQueue> queue = nil;
    id<MTLCommandBuffer> command = nil;
    id<MTLTexture> color = nil;
    id<MTLTexture> depthStencil = nil;
    CAMetalLayer *layer = nil;
    id<CAMetalDrawable> drawable = nil;
    unsigned width = 0, height = 0;
    bool active = false, failed = false, submitted = false;
    bool colorValid = false, depthValid = false, stencilValid = false;
    uint64_t frames = 0;
};

namespace rage {
namespace {
grcMetalContext s_ctx;
thread_local char s_error[512] = "";
char s_deviceName[256] = "";

bool fail(const char *message) {
    snprintf(s_error, sizeof(s_error), "%s", message);
    return false;
}
bool mainThread() {
    return pthread_main_np() != 0 || fail("Metal bring-up requires the main thread.");
}
bool dimensions(unsigned w, unsigned h) {
    return (w > 0 && h > 0 && w <= 4096 && h <= 4096) ||
        fail("Target dimensions must be 1..4096 physical pixels.");
}
bool frameFailure(const char *message) {
    s_ctx.failed = true;
    return fail(message);
}
bool makeDepth(unsigned width, unsigned height) {
    MTLTextureDescriptor *d = [MTLTextureDescriptor
        texture2DDescriptorWithPixelFormat:MTLPixelFormatDepth32Float_Stencil8
        width:width height:height mipmapped:NO];
    d.storageMode = MTLStorageModePrivate;
    d.usage = MTLTextureUsageRenderTarget;
    id<MTLTexture> texture = [s_ctx.device newTextureWithDescriptor:d];
    if (!texture) return fail("Metal depth/stencil texture allocation failed.");
    texture.label = @"RAGE iOS depth/stencil";
    s_ctx.depthStencil = texture;
    s_ctx.depthValid = s_ctx.stencilValid = false;
    return true;
}
void releaseFrame() {
    s_ctx.command = nil;
    s_ctx.drawable = nil;
    if (s_ctx.target == grcMetalContext::Layer) s_ctx.color = nil;
    s_ctx.active = false;
}
bool complete(id<MTLCommandBuffer> command) {
    [command commit];
    [command waitUntilCompleted]; // deliberate single-frame bring-up policy
    if (command.status != MTLCommandBufferStatusCompleted) {
        const char *detail = command.error.localizedDescription.UTF8String;
        s_ctx.failed = true;
        return fail(detail ? detail : "Metal command buffer did not complete.");
    }
    return true;
}
} // namespace

bool grcMetalConfigureOffscreen(unsigned width, unsigned height) {
    if (!mainThread()) return false;
    if (s_ctx.device) return fail("Shutdown before changing the target.");
    if (!dimensions(width, height)) return false;
    s_ctx.layer = nil;
    s_ctx.target = grcMetalContext::Offscreen;
    s_ctx.width = width;
    s_ctx.height = height;
    s_error[0] = 0;
    return true;
}

bool grcMetalConfigureLayer(CAMetalLayer *layer, unsigned width, unsigned height) {
    if (!mainThread()) return false;
    if (s_ctx.device) return fail("Shutdown before changing the target.");
    if (!layer) return fail("A real CAMetalLayer from the app host is required.");
    if (!dimensions(width, height)) return false;
    s_ctx.layer = layer;
    s_ctx.target = grcMetalContext::Layer;
    s_ctx.width = width;
    s_ctx.height = height;
    s_error[0] = 0;
    return true;
}

bool grcMetalInitialize() {
    if (!mainThread()) return false;
    if (s_ctx.device) return fail("Metal device is already initialized.");
    if (s_ctx.target == grcMetalContext::Unconfigured)
        return fail("Configure an explicit layer or offscreen target before InitClass.");
    @autoreleasepool {
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        if (!device) return fail("MTLCreateSystemDefaultDevice returned nil.");
        id<MTLCommandQueue> queue = [device newCommandQueue];
        if (!queue) return fail("Metal command queue allocation failed.");
        s_ctx.device = device;
        s_ctx.queue = queue;
        s_ctx.failed = s_ctx.active = s_ctx.submitted = false;
        s_ctx.colorValid = s_ctx.depthValid = s_ctx.stencilValid = false;
        s_ctx.frames = 0;
        if (!makeDepth(s_ctx.width, s_ctx.height)) {
            s_ctx.queue = nil;
            s_ctx.device = nil;
            return false;
        }
        if (s_ctx.target == grcMetalContext::Offscreen) {
            MTLTextureDescriptor *d = [MTLTextureDescriptor
                texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
                width:s_ctx.width height:s_ctx.height mipmapped:NO];
            d.storageMode = MTLStorageModeShared;
            d.usage = MTLTextureUsageRenderTarget;
            s_ctx.color = [device newTextureWithDescriptor:d];
            if (!s_ctx.color) {
                s_ctx.depthStencil = nil;
                s_ctx.queue = nil;
                s_ctx.device = nil;
                return fail("Metal offscreen color texture allocation failed.");
            }
            s_ctx.color.label = @"RAGE iOS readback target";
        } else {
            s_ctx.layer.device = device;
            s_ctx.layer.pixelFormat = MTLPixelFormatBGRA8Unorm;
            s_ctx.layer.framebufferOnly = YES;
            s_ctx.layer.drawableSize = CGSizeMake(s_ctx.width, s_ctx.height);
        }
        const char *name = device.name.UTF8String;
        snprintf(s_deviceName, sizeof(s_deviceName), "%s", name ? name : "unnamed");
        s_error[0] = 0;
        return true;
    }
}

bool grcMetalBeginFrame() {
    if (!mainThread()) return false;
    if (!s_ctx.device) return fail("InitClass has not created a Metal device.");
    if (s_ctx.failed) return fail("Frame failure requires Shutdown and reinitialization.");
    if (s_ctx.active) return frameFailure("BeginFrame called twice without EndFrame.");
    @autoreleasepool {
        s_ctx.submitted = false;
        if (s_ctx.target == grcMetalContext::Layer) {
            const CGSize size = s_ctx.layer.drawableSize;
            if (!isfinite(size.width) || !isfinite(size.height) ||
                size.width < 1 || size.height < 1 || size.width > 4096 || size.height > 4096)
                return fail("Layer is zero-sized or outside supported dimensions; skip frame.");
            s_ctx.drawable = [s_ctx.layer nextDrawable];
            if (!s_ctx.drawable) return fail("No drawable available; skip frame.");
            s_ctx.color = s_ctx.drawable.texture;
            const unsigned w = (unsigned)s_ctx.color.width;
            const unsigned h = (unsigned)s_ctx.color.height;
            if (!dimensions(w, h) || s_ctx.color.pixelFormat != MTLPixelFormatBGRA8Unorm) {
                releaseFrame();
                return frameFailure("Unexpected drawable size or format.");
            }
            if (w != s_ctx.width || h != s_ctx.height) {
                if (!makeDepth(w, h)) {
                    releaseFrame();
                    s_ctx.failed = true;
                    return false;
                }
                s_ctx.width = w;
                s_ctx.height = h;
            }
            s_ctx.colorValid = false; // drawable contents are not previous frame contents
        }
        s_ctx.command = [s_ctx.queue commandBuffer];
        if (!s_ctx.command) {
            releaseFrame();
            return frameFailure("Metal command buffer allocation failed.");
        }
        s_ctx.command.label = @"RAGE iOS frame";
        s_ctx.active = true;
        s_error[0] = 0;
        return true;
    }
}

bool grcMetalClear(bool color, float r, float g, float b, float a,
                   bool depth, float z, bool stencil, uint32_t s) {
    if (!mainThread()) return false;
    if (!s_ctx.active || s_ctx.failed) return fail("Clear requires a valid active frame.");
    if (color && (!isfinite(r) || !isfinite(g) || !isfinite(b) || !isfinite(a)))
        return frameFailure("Non-finite clear color.");
    if (depth && (!isfinite(z) || z < 0.f || z > 1.f))
        return frameFailure("Clear depth must be finite and in [0,1].");
    if (stencil && s > 255) return frameFailure("Stencil value must fit 8 bits.");
    if (!color && !depth && !stencil) return true;
    @autoreleasepool {
        MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
        pass.colorAttachments[0].texture = s_ctx.color;
        pass.colorAttachments[0].loadAction = color ? MTLLoadActionClear :
            (s_ctx.colorValid ? MTLLoadActionLoad : MTLLoadActionDontCare);
        pass.colorAttachments[0].storeAction = MTLStoreActionStore;
        pass.colorAttachments[0].clearColor = MTLClearColorMake(r, g, b, a);
        pass.depthAttachment.texture = s_ctx.depthStencil;
        pass.depthAttachment.loadAction = depth ? MTLLoadActionClear :
            (s_ctx.depthValid ? MTLLoadActionLoad : MTLLoadActionDontCare);
        pass.depthAttachment.storeAction = MTLStoreActionStore;
        pass.depthAttachment.clearDepth = depth ? z : 1.0;
        pass.stencilAttachment.texture = s_ctx.depthStencil;
        pass.stencilAttachment.loadAction = stencil ? MTLLoadActionClear :
            (s_ctx.stencilValid ? MTLLoadActionLoad : MTLLoadActionDontCare);
        pass.stencilAttachment.storeAction = MTLStoreActionStore;
        pass.stencilAttachment.clearStencil = stencil ? s : 0;
        id<MTLRenderCommandEncoder> encoder = [s_ctx.command renderCommandEncoderWithDescriptor:pass];
        if (!encoder) return frameFailure("Metal render encoder allocation failed.");
        [encoder endEncoding];
        s_ctx.colorValid |= color;
        s_ctx.depthValid |= depth;
        s_ctx.stencilValid |= stencil;
        return true;
    }
}

bool grcMetalEndFrame() {
    if (!mainThread()) return false;
    if (!s_ctx.active) return fail("EndFrame without BeginFrame.");
    if (s_ctx.failed || !s_ctx.colorValid) {
        releaseFrame();
        return frameFailure("Cannot submit a failed frame or uninitialized color target.");
    }
    @autoreleasepool {
        if (s_ctx.drawable) [s_ctx.command presentDrawable:s_ctx.drawable];
        const bool success = complete(s_ctx.command);
        releaseFrame();
        if (!success) return false;
        s_ctx.submitted = true;
        ++s_ctx.frames;
        return true;
    }
}

bool grcMetalReadback(void *bytes, size_t capacity, size_t rowBytes) {
    if (!mainThread()) return false;
    if (!s_ctx.device || s_ctx.active || s_ctx.failed || !s_ctx.submitted ||
        s_ctx.target != grcMetalContext::Offscreen)
        return fail("Readback requires a completed offscreen frame.");
    const size_t rowMin = (size_t)s_ctx.width * 4;
    if (!bytes || rowBytes < rowMin || rowBytes % 4 != 0 ||
        (s_ctx.height > 1 && rowBytes > (SIZE_MAX - rowMin) / (s_ctx.height - 1)) ||
        capacity < (s_ctx.height - 1) * rowBytes + rowMin)
        return fail("Readback destination is too small or has invalid stride.");
    [s_ctx.color getBytes:bytes bytesPerRow:rowBytes
        fromRegion:MTLRegionMake2D(0, 0, s_ctx.width, s_ctx.height) mipmapLevel:0];
    return true;
}

bool grcMetalShutdown() {
    if (!mainThread()) return false;
    // EndFrame completes synchronously, so no committed command remains in flight.
    // Discard any uncommitted active frame. The host still owns its UIView/layer.
    releaseFrame();
    s_ctx.color = nil;
    s_ctx.depthStencil = nil;
    s_ctx.queue = nil;
    if (s_ctx.layer && s_ctx.layer.device == s_ctx.device) s_ctx.layer.device = nil;
    s_ctx.device = nil;
    s_ctx.layer = nil;
    s_ctx.target = grcMetalContext::Unconfigured;
    s_ctx.width = s_ctx.height = 0;
    s_ctx.active = s_ctx.failed = s_ctx.submitted = false;
    s_ctx.colorValid = s_ctx.depthValid = s_ctx.stencilValid = false;
    s_ctx.frames = 0;
    s_deviceName[0] = 0;
    return true;
}

grcMetalContext *grcMetalGetContext() { return mainThread() && s_ctx.device ? &s_ctx : NULL; }
unsigned grcMetalWidth() { return mainThread() ? s_ctx.width : 0; }
unsigned grcMetalHeight() { return mainThread() ? s_ctx.height : 0; }
uint64_t grcMetalCompletedFrames() { return mainThread() ? s_ctx.frames : 0; }
const char *grcMetalDeviceName() { return mainThread() ? s_deviceName : ""; }
const char *grcMetalLastError() { return s_error; }
} // namespace rage
