// Native iOS grcDevice slice. Intentionally leaves unsupported graphics
// methods undefined. Do not add empty implementations to make the game link.
#include "grcore/config.h"
#if RSG_IOS && __METAL
#include "grcore/device.h"
#include "metal_native.h"
#include "grcore/vertexdecl.h"
#include "metal_draw.h"
#include <new>
#include <stdio.h>
#include <stdlib.h>
#include <type_traits>

#if !RSG_CPU_ARM64 || RSG_CPU_INTEL || __RESOURCECOMPILER || __TOOL
#error Expected the actual iOS ARM64 runtime configuration.
#endif

namespace rage {
static_assert(std::is_same<grcContextHandle, ::grcMetalContext>::value,
              "Expected the typed iOS context from the graphics header patch.");
__THREAD grcContextHandle *g_grcCurrentContext = NULL;
grcDisplayWindow grcDevice::sm_CurrentWindows[NUMBER_OF_RENDER_THREADS];
grcDisplayWindow grcDevice::sm_GlobalWindow;

namespace {
void releaseMetalDeclaration();
void requireMetal(bool ok, const char *operation) {
    if (!ok) {
        // Do not depend on ASSERT/FINAL switches for safety during bring-up.
        fprintf(stderr, "METAL_FATAL: %s: %s\n", operation, grcMetalLastError());
        abort();
    }
}
void unsupported(const char *operation) {
    fprintf(stderr, "METAL_UNSUPPORTED: %s\n", operation);
    abort();
}
} // namespace

void grcDevice::InitClass(bool inWindow, bool topMost) {
    // UIKit host owns window placement and fullscreen behavior on iOS.
    (void)inWindow;
    if (topMost) unsupported("top-most window request");
    if (sm_CurrentWindows[0].uWidth &&
        (sm_CurrentWindows[0].uWidth != grcMetalWidth() ||
         sm_CurrentWindows[0].uHeight != grcMetalHeight()))
        unsupported("SetSize and configured target dimensions differ");
    requireMetal(grcMetalInitialize(), "InitClass");
    g_grcCurrentContext = grcMetalGetContext();
    for (int i = 0; i < NUMBER_OF_RENDER_THREADS; ++i)
        sm_CurrentWindows[i].Init(grcMetalWidth(), grcMetalHeight(), 0, false, 0);
    sm_GlobalWindow = sm_CurrentWindows[0];
}

void grcDevice::ShutdownClass() {
    requireMetal(grcMetalShutdown(), "ShutdownClass");
    releaseMetalDeclaration();
    g_grcCurrentContext = NULL;
    for (int i = 0; i < NUMBER_OF_RENDER_THREADS; ++i)
        sm_CurrentWindows[i].Init(0, 0, 0, false, 0);
    sm_GlobalWindow = sm_CurrentWindows[0];
}

bool grcDevice::BeginFrame() {
    if (!grcMetalBeginFrame()) return false; // includes missing drawable
    sm_CurrentWindows[0].uWidth = grcMetalWidth();
    sm_CurrentWindows[0].uHeight = grcMetalHeight();
    sm_GlobalWindow = sm_CurrentWindows[0];
    return true;
}

void grcDevice::Clear(bool color, Color32 value, bool depth, float z,
                       bool stencil, u32 s) {
    requireMetal(grcMetalClear(color, value.GetRedf(), value.GetGreenf(),
        value.GetBluef(), value.GetAlphaf(), depth, z, stencil, s), "Clear");
}

void grcDevice::EndFrame(const grcResolveFlags *flags) {
    if (flags) unsupported("clear-during-resolve flags (use EndFrame(NULL))");
    requireMetal(grcMetalEndFrame(), "EndFrame");
}

void grcDevice::SetWindow(const grcWindow& window) {
    // Load-action clears cover the full attachment; scissor rectangles do not
    // restrict them. Reject partial viewport requests instead of over-clearing.
    if (window.GetNormX() != 0 || window.GetNormY() != 0 ||
        window.GetNormWidth() != 1 || window.GetNormHeight() != 1 ||
        window.GetMinZ() != 0 || window.GetMaxZ() != 1)
        unsupported("partial viewport or non-default depth range");
}
namespace {
const grcVertexDeclaration *s_metalDeclaration = NULL;
void releaseMetalDeclaration() {
    if (s_metalDeclaration) s_metalDeclaration->Release();
    s_metalDeclaration = NULL;
}
u32 endCount(const void *end) {
    u32 count = 0;
    requireMetal(grcMetalEndPointerCount(end, &count), "vertex batch pointer");
    return count;
}
}

grcVertexDeclaration *grcDevice::CreateVertexDeclaration(const grcVertexElement *elements,
                                                        int count, int strideOverride) {
    // First native slice: POSITION0 and COLOR0 only, stream 0, per-vertex.
    // Semantics use the existing RAGE FVF channel numbers (0 and 4).
    if (!elements || count != 2 || strideOverride < 0) return NULL;
    grcMetalVertexLayout layout = {};
    unsigned offset = 0;
    for (int i=0; i<count; ++i) {
        const auto& e = elements[i];
        if (e.stream != 0 || e.channel != 0 || e.streamFrequencyMode != grcFvf::grcsfmDivide ||
            e.streamFrequencyDivider > 1) return NULL;
        unsigned slot = 0;
        if (e.type == grcVertexElement::grcvetPosition) slot = grcFvf::grcfcPosition;
        else if (e.type == grcVertexElement::grcvetColor) slot = grcFvf::grcfcDiffuse;
        else return NULL; // PositionT/normal/texture/skinning are not silently reinterpreted.
        unsigned components = 0;
        switch (e.format) {
            case grcFvf::grcdsFloat2: components=2; break;
            case grcFvf::grcdsFloat3: components=3; break;
            case grcFvf::grcdsFloat4: components=4; break;
            default: return NULL;
        }
        if (e.size != components*4 || (slot==grcFvf::grcfcDiffuse && components!=4)) return NULL;
        layout.attributes[i] = {slot, components, offset};
        offset += e.size;
    }
    layout.count = 2;
    layout.stride = strideOverride ? (unsigned)strideOverride : offset;
    if (!grcMetalValidateLayout(layout)) return NULL;
    auto *declaration = new (std::nothrow) grcVertexDeclaration;
    if (!declaration) return NULL;
    declaration->Layout = layout;
    declaration->Stream0Size = layout.stride;
    declaration->RefCount = 1;
    return declaration;
}
void grcDevice::DestroyVertexDeclaration(grcVertexDeclaration *declaration) {
    if (!declaration) return;
    if (s_metalDeclaration == declaration)
        requireMetal(SetVertexDeclaration(NULL)==0, "DestroyVertexDeclaration");
    declaration->Release();
}
grcDevice::Result grcDevice::SetVertexDeclaration(const grcVertexDeclaration *declaration) {
    if (!grcMetalBindLayout(declaration ? &declaration->Layout : NULL)) return (Result)0x80004005u;
    if (declaration) declaration->AddRef();
    releaseMetalDeclaration();
    s_metalDeclaration = declaration;
    return 0;
}
void grcDevice::SetVertexShader(grcVertexShader *shader, const grcProgram *program) {
    if (program) unsupported("legacy grcProgram resources are not yet bound on Metal");
    requireMetal(grcMetalBindVertexShader(shader), "SetVertexShader");
}
void grcDevice::SetPixelShader(grcPixelShader *shader, const grcProgram *program) {
    if (program) unsupported("legacy grcProgram resources are not yet bound on Metal");
    requireMetal(grcMetalBindPixelShader(shader), "SetPixelShader");
}
void *grcDevice::BeginVertices(grcDrawMode mode, u32 count, u32 stride) {
    if (mode != drawTris) unsupported("only non-indexed triangle lists are implemented");
    return grcMetalBeginVertices(count, stride);
}
void grcDevice::EndCreateVertices(const void *end) {
    requireMetal(grcMetalSealVertices(endCount(end)), "EndCreateVertices");
}
void grcDevice::EndCreateVertices(u32 count) {
    requireMetal(grcMetalSealVertices(count), "EndCreateVertices(count)");
}
void grcDevice::DrawVertices(const void *end) {
    requireMetal(grcMetalDrawVertices(endCount(end)), "DrawVertices");
}
void grcDevice::DrawVertices(u32 count) {
    requireMetal(grcMetalDrawVertices(count), "DrawVertices(count)");
}
void grcDevice::ReleaseVertices(const void *end) {
    requireMetal(grcMetalReleaseVertices(endCount(end)), "ReleaseVertices");
}
void grcDevice::ReleaseVertices(u32 count) {
    requireMetal(grcMetalReleaseVertices(count), "ReleaseVertices(count)");
}

} // namespace rage
#endif
