#ifndef GRCORE_METAL_DRAW_H
#define GRCORE_METAL_DRAW_H
#include <stdint.h>
#include <stddef.h>
struct grcMetalVertexShader;
struct grcMetalPixelShader;
namespace rage {
// Native source-port contract: one stream, position attribute 0, diffuse 4.
// Float2/3/4 positions and Float4 diffuse only. Unsupported formats fail closed.
enum grcMetalVertexFormat { metalFloat2=2, metalFloat3=3, metalFloat4=4 };
struct grcMetalVertexLayout {
    struct Attribute { uint32_t slot, format, offset; } attributes[2];
    uint32_t count, stride;
};
inline bool grcMetalValidateLayout(const grcMetalVertexLayout& l) {
    if (l.count!=2 || !l.stride || l.stride>256 || l.stride%4) return false;
    unsigned mask=0;
    for (unsigned i=0; i<2; ++i) {
        const auto& a=l.attributes[i];
        if ((a.slot!=0 && a.slot!=4) || a.format<2 || a.format>4 ||
            (a.slot==4 && a.format!=4) || a.offset%4 ||
            a.offset>l.stride || a.format*4>l.stride-a.offset || (mask&(1u<<a.slot))) return false;
        mask|=1u<<a.slot;
    }
    const auto& a=l.attributes[0]; const auto& b=l.attributes[1];
    return mask==17 && (a.offset+a.format*4<=b.offset || b.offset+b.format*4<=a.offset);
}
// Main thread only, after InitClass and outside a frame. MSL SOURCE, not DXBC.
bool grcMetalCreateShaders(const char *msl, const char *vertexEntry, const char *fragmentEntry,
                          ::grcMetalVertexShader **vs, ::grcMetalPixelShader **ps);
void grcMetalDestroyShaders(::grcMetalVertexShader *vs, ::grcMetalPixelShader *ps);
bool grcMetalBindVertexShader(::grcMetalVertexShader *vs);
bool grcMetalBindPixelShader(::grcMetalPixelShader *ps);
bool grcMetalBindLayout(const grcMetalVertexLayout *layout);
bool grcMetalPrepareDraw();
// Triangle lists only; 4 MiB maximum per batch. Buffers are not reused in flight.
void *grcMetalBeginVertices(uint32_t count, uint32_t stride);
bool grcMetalSealVertices(uint32_t count);
bool grcMetalDrawVertices(uint32_t count);
bool grcMetalReleaseVertices(uint32_t count);
bool grcMetalEndPointerCount(const void *end, uint32_t *count);
uint64_t grcMetalEncodedDraws();
} // namespace rage
#endif
