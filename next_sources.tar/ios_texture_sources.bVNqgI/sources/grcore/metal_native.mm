// Native Metal implementation. Compile separately with ARC, without RAGE's
// forceinclude header; engine types stay on the C++ side of metal_native.h.
#include "metal_native.h"
#include "metal_draw.h"
#include <new>
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#include <TargetConditionals.h>
#include <pthread.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

#if !TARGET_OS_IPHONE || TARGET_OS_SIMULATOR || !defined(__aarch64__)
#error This backend must be built for a physical iOS ARM64 device.
#endif
#if !__has_feature(objc_arc)
#error Compile metal_native.mm with -fobjc-arc.
#endif

struct grcMetalVertexShader { id<MTLDevice> device = nil; id<MTLFunction> function = nil; };
struct grcMetalPixelShader { id<MTLDevice> device = nil; id<MTLFunction> function = nil; };

struct grcMetalContext {
    enum Target { Unconfigured, Offscreen, Layer } target = Unconfigured;
    id<MTLDevice> device = nil;
    id<MTLCommandQueue> queue = nil;
    id<MTLCommandBuffer> command = nil;
    id<MTLTexture> color = nil;
    id<MTLTexture> depthStencil = nil;
    CAMetalLayer *layer = nil;
    id<CAMetalDrawable> drawable = nil;
    unsigned width = 0, height = 0;
    bool active = false, failed = false, submitted = false;
    bool colorValid = false, depthValid = false, stencilValid = false;
    uint64_t frames = 0;
};

namespace rage {
namespace {
grcMetalContext s_ctx;
thread_local char s_error[512] = "";
char s_deviceName[256] = "";
struct DrawState {
    id<MTLFunction> vertex = nil, fragment = nil;
    id<MTLRenderPipelineState> pipeline = nil;
    id<MTLDepthStencilState> depth = nil;
    id<MTLBuffer> buffer = nil;
    grcMetalVertexLayout layout = {};
    uint32_t capacity = 0, count = 0, stride = 0;
    bool hasLayout = false, sealed = false;
    uint64_t draws = 0;
};
DrawState s_draw;
bool drawError(const char *operation, NSError *error) {
    snprintf(s_error, sizeof(s_error), "%s: %s", operation,
        error ? error.localizedDescription.UTF8String : "unknown Metal error");
    return false;
}


bool fail(const char *message) {
    snprintf(s_error, sizeof(s_error), "%s", message);
    return false;
}
bool mainThread() {
    return pthread_main_np() != 0 || fail("Metal bring-up requires the main thread.");
}
bool dimensions(unsigned w, unsigned h) {
    return (w > 0 && h > 0 && w <= 4096 && h <= 4096) ||
        fail("Target dimensions must be 1..4096 physical pixels.");
}
bool frameFailure(const char *message) {
    s_ctx.failed = true;
    return fail(message);
}
bool makeDepth(unsigned width, unsigned height) {
    MTLTextureDescriptor *d = [MTLTextureDescriptor
        texture2DDescriptorWithPixelFormat:MTLPixelFormatDepth32Float_Stencil8
        width:width height:height mipmapped:NO];
    d.storageMode = MTLStorageModePrivate;
    d.usage = MTLTextureUsageRenderTarget;
    id<MTLTexture> texture = [s_ctx.device newTextureWithDescriptor:d];
    if (!texture) return fail("Metal depth/stencil texture allocation failed.");
    texture.label = @"RAGE iOS depth/stencil";
    s_ctx.depthStencil = texture;
    s_ctx.depthValid = s_ctx.stencilValid = false;
    return true;
}
void releaseFrame() {
    s_ctx.command = nil;
    s_ctx.drawable = nil;
    if (s_ctx.target == grcMetalContext::Layer) s_ctx.color = nil;
    s_ctx.active = false;
}
bool complete(id<MTLCommandBuffer> command) {
    [command commit];
    [command waitUntilCompleted]; // deliberate single-frame bring-up policy
    if (command.status != MTLCommandBufferStatusCompleted) {
        const char *detail = command.error.localizedDescription.UTF8String;
        s_ctx.failed = true;
        return fail(detail ? detail : "Metal command buffer did not complete.");
    }
    return true;
}
} // namespace

bool grcMetalConfigureOffscreen(unsigned width, unsigned height) {
    if (!mainThread()) return false;
    if (s_ctx.device) return fail("Shutdown before changing the target.");
    if (!dimensions(width, height)) return false;
    s_ctx.layer = nil;
    s_ctx.target = grcMetalContext::Offscreen;
    s_ctx.width = width;
    s_ctx.height = height;
    s_error[0] = 0;
    return true;
}

bool grcMetalConfigureLayer(CAMetalLayer *layer, unsigned width, unsigned height) {
    if (!mainThread()) return false;
    if (s_ctx.device) return fail("Shutdown before changing the target.");
    if (!layer) return fail("A real CAMetalLayer from the app host is required.");
    if (!dimensions(width, height)) return false;
    s_ctx.layer = layer;
    s_ctx.target = grcMetalContext::Layer;
    s_ctx.width = width;
    s_ctx.height = height;
    s_error[0] = 0;
    return true;
}

bool grcMetalInitialize() {
    if (!mainThread()) return false;
    if (s_ctx.device) return fail("Metal device is already initialized.");
    if (s_ctx.target == grcMetalContext::Unconfigured)
        return fail("Configure an explicit layer or offscreen target before InitClass.");
    @autoreleasepool {
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        if (!device) return fail("MTLCreateSystemDefaultDevice returned nil.");
        id<MTLCommandQueue> queue = [device newCommandQueue];
        if (!queue) return fail("Metal command queue allocation failed.");
        s_ctx.device = device;
        s_ctx.queue = queue;
        s_ctx.failed = s_ctx.active = s_ctx.submitted = false;
        s_ctx.colorValid = s_ctx.depthValid = s_ctx.stencilValid = false;
        s_ctx.frames = 0;
        if (!makeDepth(s_ctx.width, s_ctx.height)) {
            s_ctx.queue = nil;
            s_ctx.device = nil;
            return false;
        }
        if (s_ctx.target == grcMetalContext::Offscreen) {
            MTLTextureDescriptor *d = [MTLTextureDescriptor
                texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
                width:s_ctx.width height:s_ctx.height mipmapped:NO];
            d.storageMode = MTLStorageModeShared;
            d.usage = MTLTextureUsageRenderTarget;
            s_ctx.color = [device newTextureWithDescriptor:d];
            if (!s_ctx.color) {
                s_ctx.depthStencil = nil;
                s_ctx.queue = nil;
                s_ctx.device = nil;
                return fail("Metal offscreen color texture allocation failed.");
            }
            s_ctx.color.label = @"RAGE iOS readback target";
        } else {
            s_ctx.layer.device = device;
            s_ctx.layer.pixelFormat = MTLPixelFormatBGRA8Unorm;
            s_ctx.layer.framebufferOnly = YES;
            s_ctx.layer.drawableSize = CGSizeMake(s_ctx.width, s_ctx.height);
        }
        const char *name = device.name.UTF8String;
        snprintf(s_deviceName, sizeof(s_deviceName), "%s", name ? name : "unnamed");
        s_error[0] = 0;
        return true;
    }
}

bool grcMetalBeginFrame() {
    if (!mainThread()) return false;
    if (!s_ctx.device) return fail("InitClass has not created a Metal device.");
    if (s_ctx.failed) return fail("Frame failure requires Shutdown and reinitialization.");
    if (s_ctx.active) return frameFailure("BeginFrame called twice without EndFrame.");
    @autoreleasepool {
        s_ctx.submitted = false;
        if (s_ctx.target == grcMetalContext::Layer) {
            const CGSize size = s_ctx.layer.drawableSize;
            if (!isfinite(size.width) || !isfinite(size.height) ||
                size.width < 1 || size.height < 1 || size.width > 4096 || size.height > 4096)
                return fail("Layer is zero-sized or outside supported dimensions; skip frame.");
            s_ctx.drawable = [s_ctx.layer nextDrawable];
            if (!s_ctx.drawable) return fail("No drawable available; skip frame.");
            s_ctx.color = s_ctx.drawable.texture;
            const unsigned w = (unsigned)s_ctx.color.width;
            const unsigned h = (unsigned)s_ctx.color.height;
            if (!dimensions(w, h) || s_ctx.color.pixelFormat != MTLPixelFormatBGRA8Unorm) {
                releaseFrame();
                return frameFailure("Unexpected drawable size or format.");
            }
            if (w != s_ctx.width || h != s_ctx.height) {
                if (!makeDepth(w, h)) {
                    releaseFrame();
                    s_ctx.failed = true;
                    return false;
                }
                s_ctx.width = w;
                s_ctx.height = h;
            }
            s_ctx.colorValid = false; // drawable contents are not previous frame contents
        }
        s_ctx.command = [s_ctx.queue commandBuffer];
        if (!s_ctx.command) {
            releaseFrame();
            return frameFailure("Metal command buffer allocation failed.");
        }
        s_ctx.command.label = @"RAGE iOS frame";
        s_ctx.active = true;
        s_error[0] = 0;
        return true;
    }
}

bool grcMetalClear(bool color, float r, float g, float b, float a,
                   bool depth, float z, bool stencil, uint32_t s) {
    if (!mainThread()) return false;
    if (!s_ctx.active || s_ctx.failed) return fail("Clear requires a valid active frame.");
    if (color && (!isfinite(r) || !isfinite(g) || !isfinite(b) || !isfinite(a)))
        return frameFailure("Non-finite clear color.");
    if (depth && (!isfinite(z) || z < 0.f || z > 1.f))
        return frameFailure("Clear depth must be finite and in [0,1].");
    if (stencil && s > 255) return frameFailure("Stencil value must fit 8 bits.");
    if (!color && !depth && !stencil) return true;
    @autoreleasepool {
        MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
        pass.colorAttachments[0].texture = s_ctx.color;
        pass.colorAttachments[0].loadAction = color ? MTLLoadActionClear :
            (s_ctx.colorValid ? MTLLoadActionLoad : MTLLoadActionDontCare);
        pass.colorAttachments[0].storeAction = MTLStoreActionStore;
        pass.colorAttachments[0].clearColor = MTLClearColorMake(r, g, b, a);
        pass.depthAttachment.texture = s_ctx.depthStencil;
        pass.depthAttachment.loadAction = depth ? MTLLoadActionClear :
            (s_ctx.depthValid ? MTLLoadActionLoad : MTLLoadActionDontCare);
        pass.depthAttachment.storeAction = MTLStoreActionStore;
        pass.depthAttachment.clearDepth = depth ? z : 1.0;
        pass.stencilAttachment.texture = s_ctx.depthStencil;
        pass.stencilAttachment.loadAction = stencil ? MTLLoadActionClear :
            (s_ctx.stencilValid ? MTLLoadActionLoad : MTLLoadActionDontCare);
        pass.stencilAttachment.storeAction = MTLStoreActionStore;
        pass.stencilAttachment.clearStencil = stencil ? s : 0;
        id<MTLRenderCommandEncoder> encoder = [s_ctx.command renderCommandEncoderWithDescriptor:pass];
        if (!encoder) return frameFailure("Metal render encoder allocation failed.");
        [encoder endEncoding];
        s_ctx.colorValid |= color;
        s_ctx.depthValid |= depth;
        s_ctx.stencilValid |= stencil;
        return true;
    }
}

bool grcMetalEndFrame() {
    if (!mainThread()) return false;
    if (!s_ctx.active) return fail("EndFrame without BeginFrame.");
    if (s_ctx.failed || !s_ctx.colorValid || s_draw.buffer) {
        releaseFrame();
        return frameFailure("Cannot submit a failed frame, uninitialized color target or unreleased vertex batch.");
    }
    @autoreleasepool {
        if (s_ctx.drawable) [s_ctx.command presentDrawable:s_ctx.drawable];
        const bool success = complete(s_ctx.command);
        releaseFrame();
        if (!success) return false;
        s_ctx.submitted = true;
        ++s_ctx.frames;
        return true;
    }
}

bool grcMetalReadback(void *bytes, size_t capacity, size_t rowBytes) {
    if (!mainThread()) return false;
    if (!s_ctx.device || s_ctx.active || s_ctx.failed || !s_ctx.submitted ||
        s_ctx.target != grcMetalContext::Offscreen)
        return fail("Readback requires a completed offscreen frame.");
    const size_t rowMin = (size_t)s_ctx.width * 4;
    if (!bytes || rowBytes < rowMin || rowBytes % 4 != 0 ||
        (s_ctx.height > 1 && rowBytes > (SIZE_MAX - rowMin) / (s_ctx.height - 1)) ||
        capacity < (s_ctx.height - 1) * rowBytes + rowMin)
        return fail("Readback destination is too small or has invalid stride.");
    [s_ctx.color getBytes:bytes bytesPerRow:rowBytes
        fromRegion:MTLRegionMake2D(0, 0, s_ctx.width, s_ctx.height) mipmapLevel:0];
    return true;
}

bool grcMetalShutdown() {
    if (!mainThread()) return false;
    // EndFrame completes synchronously, so no committed command remains in flight.
    // Discard any uncommitted active frame. The host still owns its UIView/layer.
    releaseFrame();
    s_draw = DrawState{};
    s_ctx.color = nil;
    s_ctx.depthStencil = nil;
    s_ctx.queue = nil;
    if (s_ctx.layer && s_ctx.layer.device == s_ctx.device) s_ctx.layer.device = nil;
    s_ctx.device = nil;
    s_ctx.layer = nil;
    s_ctx.target = grcMetalContext::Unconfigured;
    s_ctx.width = s_ctx.height = 0;
    s_ctx.active = s_ctx.failed = s_ctx.submitted = false;
    s_ctx.colorValid = s_ctx.depthValid = s_ctx.stencilValid = false;
    s_ctx.frames = 0;
    s_deviceName[0] = 0;
    return true;
}

grcMetalContext *grcMetalGetContext() { return mainThread() && s_ctx.device ? &s_ctx : NULL; }
unsigned grcMetalWidth() { return mainThread() ? s_ctx.width : 0; }
unsigned grcMetalHeight() { return mainThread() ? s_ctx.height : 0; }
uint64_t grcMetalCompletedFrames() { return mainThread() ? s_ctx.frames : 0; }
const char *grcMetalDeviceName() { return mainThread() ? s_deviceName : ""; }
const char *grcMetalLastError() { return s_error; }
// Native immediate drawing path. No UIKit or engine calls live in this layer.
bool grcMetalCreateShaders(const char *source, const char *ve, const char *fe,
                           ::grcMetalVertexShader **vs, ::grcMetalPixelShader **ps) {
    if (!mainThread()) return false;
    if (!s_ctx.device || s_ctx.active || !source || !ve || !fe || !vs || !ps || *vs || *ps)
        return fail("CreateShaders requires an initialized idle device and empty output handles.");
    @autoreleasepool {
        NSString *text = [NSString stringWithUTF8String:source];
        NSString *vertexName = [NSString stringWithUTF8String:ve];
        NSString *fragmentName = [NSString stringWithUTF8String:fe];
        if (!text || !vertexName || !fragmentName || !text.length)
            return fail("Invalid UTF-8 MSL source or entry name.");
        MTLCompileOptions *options = [[MTLCompileOptions alloc] init];
        options.fastMathEnabled = NO;
        NSError *error = nil;
        id<MTLLibrary> library = [s_ctx.device newLibraryWithSource:text options:options error:&error];
        if (!library) return drawError("MSL compile", error);
        id<MTLFunction> vertex = [library newFunctionWithName:vertexName];
        id<MTLFunction> fragment = [library newFunctionWithName:fragmentName];
        if (!vertex || !fragment || vertex.functionType != MTLFunctionTypeVertex ||
            fragment.functionType != MTLFunctionTypeFragment) return fail("MSL entry missing or wrong shader stage.");
        auto *v = new (std::nothrow) ::grcMetalVertexShader;
        auto *p = new (std::nothrow) ::grcMetalPixelShader;
        if (!v || !p) { delete v; delete p; return fail("Shader handle allocation failed."); }
        v->device = s_ctx.device; v->function = vertex;
        p->device = s_ctx.device; p->function = fragment;
        *vs = v; *ps = p;
        return true;
    }
}
void grcMetalDestroyShaders(::grcMetalVertexShader *vs, ::grcMetalPixelShader *ps) {
    if (!mainThread()) return;
    // Bound functions are retained independently; this releases the caller handles.
    delete vs; delete ps;
}
bool grcMetalBindVertexShader(::grcMetalVertexShader *vs) {
    if (!mainThread()) return false;
    if (s_draw.buffer || (vs && (!s_ctx.device || vs->device != s_ctx.device)))
        return fail("Cannot bind vertex shader during a vertex batch or from another device.");
    s_draw.vertex = vs ? vs->function : nil; s_draw.pipeline = nil;
    return true;
}
bool grcMetalBindPixelShader(::grcMetalPixelShader *ps) {
    if (!mainThread()) return false;
    if (s_draw.buffer || (ps && (!s_ctx.device || ps->device != s_ctx.device)))
        return fail("Cannot bind fragment shader during a vertex batch or from another device.");
    s_draw.fragment = ps ? ps->function : nil; s_draw.pipeline = nil;
    return true;
}
bool grcMetalBindLayout(const grcMetalVertexLayout *layout) {
    if (!mainThread()) return false;
    if (s_draw.buffer) return fail("Cannot change layout during a vertex batch.");
    if (layout && !grcMetalValidateLayout(*layout)) return fail("Unsupported native vertex layout.");
    s_draw.layout = layout ? *layout : grcMetalVertexLayout{};
    s_draw.hasLayout = layout != nullptr;
    s_draw.pipeline = nil;
    return true;
}
bool grcMetalPrepareDraw() {
    if (!mainThread()) return false;
    if (!s_ctx.device || !s_draw.vertex || !s_draw.fragment || !s_draw.hasLayout)
        return fail("Drawing needs explicit native vertex/fragment shaders and vertex declaration.");
    if (s_draw.pipeline && s_draw.depth) return true;
    @autoreleasepool {
        MTLVertexDescriptor *layout = [[MTLVertexDescriptor alloc] init];
        for (uint32_t i=0; i<s_draw.layout.count; ++i) {
            const auto& a = s_draw.layout.attributes[i];
            layout.attributes[a.slot].format = a.format==metalFloat2 ? MTLVertexFormatFloat2 :
                a.format==metalFloat3 ? MTLVertexFormatFloat3 : MTLVertexFormatFloat4;
            layout.attributes[a.slot].offset = a.offset;
            layout.attributes[a.slot].bufferIndex = 0;
        }
        layout.layouts[0].stride = s_draw.layout.stride;
        layout.layouts[0].stepFunction = MTLVertexStepFunctionPerVertex;
        layout.layouts[0].stepRate = 1;
        MTLRenderPipelineDescriptor *desc = [[MTLRenderPipelineDescriptor alloc] init];
        desc.label = @"RAGE native immediate pipeline";
        desc.vertexFunction = s_draw.vertex;
        desc.fragmentFunction = s_draw.fragment;
        desc.vertexDescriptor = layout;
        desc.colorAttachments[0].pixelFormat = MTLPixelFormatBGRA8Unorm;
        desc.colorAttachments[0].blendingEnabled = NO;
        desc.depthAttachmentPixelFormat = MTLPixelFormatDepth32Float_Stencil8;
        desc.stencilAttachmentPixelFormat = MTLPixelFormatDepth32Float_Stencil8;
        desc.sampleCount = 1;
        NSError *error = nil;
        id<MTLRenderPipelineState> pipeline = [s_ctx.device newRenderPipelineStateWithDescriptor:desc error:&error];
        if (!pipeline) return drawError("Render pipeline", error);
        MTLDepthStencilDescriptor *depth = [[MTLDepthStencilDescriptor alloc] init];
        depth.depthCompareFunction = MTLCompareFunctionLessEqual;
        depth.depthWriteEnabled = YES;
        id<MTLDepthStencilState> state = [s_ctx.device newDepthStencilStateWithDescriptor:depth];
        if (!state) return fail("Depth state allocation failed.");
        s_draw.pipeline = pipeline; s_draw.depth = state;
        return true;
    }
}
void *grcMetalBeginVertices(uint32_t count, uint32_t stride) {
    if (!mainThread()) return nullptr;
    if (!s_ctx.active || s_ctx.failed || s_draw.buffer || !s_draw.hasLayout ||
        !count || !stride || stride != s_draw.layout.stride || count > (4u*1024*1024)/stride) {
        fail("Invalid BeginVertices state/count/stride, or batch exceeds 4 MiB."); return nullptr;
    }
    id<MTLBuffer> buffer = [s_ctx.device newBufferWithLength:(NSUInteger)count*stride options:MTLResourceStorageModeShared];
    if (!buffer || !buffer.contents) { fail("Vertex buffer allocation failed."); return nullptr; }
    buffer.label = @"RAGE immediate vertices";
    s_draw.buffer = buffer;
    s_draw.capacity = s_draw.count = count;
    s_draw.stride = stride;
    s_draw.sealed = false;
    return buffer.contents;
}
bool grcMetalEndPointerCount(const void *end, uint32_t *count) {
    if (!mainThread()) return false;
    if (!s_draw.buffer || !count) return fail("No vertex batch is active.");
    const uintptr_t begin = (uintptr_t)s_draw.buffer.contents;
    const uintptr_t expected = begin + (size_t)s_draw.capacity*s_draw.stride;
    if (end && (uintptr_t)end != expected) return fail("bufferEnd must be NULL or the allocated batch end.");
    *count = s_draw.sealed ? s_draw.count : s_draw.capacity;
    return true;
}
bool grcMetalSealVertices(uint32_t count) {
    if (!mainThread()) return false;
    if (!s_ctx.active || !s_draw.buffer || s_draw.sealed || count > s_draw.capacity || count%3)
        return fail("Invalid EndCreateVertices state/count; only complete triangle lists are supported.");
    s_draw.count = count; s_draw.sealed = true;
    return true;
}
bool grcMetalDrawVertices(uint32_t count) {
    if (!mainThread()) return false;
    if (!s_ctx.active || s_ctx.failed || !s_draw.buffer || !s_draw.sealed || count != s_draw.count)
        return fail("DrawVertices must follow EndCreateVertices with the same count.");
    if (!count) return true;
    if (!s_ctx.colorValid || !s_ctx.depthValid || !s_ctx.stencilValid)
        return frameFailure("Initialize color/depth/stencil with Clear before native drawing.");
    if (!grcMetalPrepareDraw()) return false;
    @autoreleasepool {
        MTLRenderPassDescriptor *pass = [MTLRenderPassDescriptor renderPassDescriptor];
        pass.colorAttachments[0].texture = s_ctx.color;
        pass.colorAttachments[0].loadAction = MTLLoadActionLoad;
        pass.colorAttachments[0].storeAction = MTLStoreActionStore;
        pass.depthAttachment.texture = s_ctx.depthStencil;
        pass.depthAttachment.loadAction = MTLLoadActionLoad;
        pass.depthAttachment.storeAction = MTLStoreActionStore;
        pass.stencilAttachment.texture = s_ctx.depthStencil;
        pass.stencilAttachment.loadAction = MTLLoadActionLoad;
        pass.stencilAttachment.storeAction = MTLStoreActionStore;
        id<MTLRenderCommandEncoder> encoder = [s_ctx.command renderCommandEncoderWithDescriptor:pass];
        if (!encoder) return frameFailure("Draw encoder allocation failed.");
        [encoder setRenderPipelineState:s_draw.pipeline];
        [encoder setDepthStencilState:s_draw.depth];
        [encoder setCullMode:MTLCullModeNone];
        [encoder setViewport:(MTLViewport){0, 0, (double)s_ctx.width, (double)s_ctx.height, 0, 1}];
        [encoder setVertexBuffer:s_draw.buffer offset:0 atIndex:0];
        [encoder drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:count];
        [encoder endEncoding];
        ++s_draw.draws; // Encoding count, not GPU completion or visible-display proof.
        return true;
    }
}
bool grcMetalReleaseVertices(uint32_t count) {
    if (!mainThread()) return false;
    if (!s_draw.buffer || !s_draw.sealed || count != s_draw.count)
        return fail("ReleaseVertices must match the sealed batch.");
    // Default retained-reference command buffers keep the actual MTLBuffer alive
    // until execution completes. Each subsequent Begin gets a NEW buffer.
    s_draw.buffer = nil; s_draw.capacity = s_draw.count = s_draw.stride = 0;
    s_draw.sealed = false;
    return true;
}
uint64_t grcMetalEncodedDraws() { return mainThread() ? s_draw.draws : 0; }

} // namespace rage
