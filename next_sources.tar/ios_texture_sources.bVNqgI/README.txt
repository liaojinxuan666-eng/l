Native RAGE iOS texture/transform source checkpoint, collector revision 1.
User screenshot confirms the previous RGB triangle is visible in the app;
HUD reports 120 completed frames. This collector does NOT verify GPU work.

Next objective: source-port texture upload/binding, UV vertex attributes and
transform constants into the existing RAGE/Metal path, with depth tests.
A textured rotating cube is the validation scene, not a GTA5 scene or asset.

This archive contains copies of selected CURRENT source and a definition index.
It does not modify engine source, compile, sign, install, or run the app.
No game assets, credentials, binaries, SDK headers, or device logs are collected.
No automatic upload is performed. Upload next_sources.tar when requested.

Search is limited to grcore and one platform-subdirectory level.
Missing optional files and skipped files are listed in notes.txt.
A complete collection means only the selected scope, not all dependencies.
Texture ownership, resource layout, sampler rules, shader constant register
units and matrix conventions must be inspected before patching.
Existing platform code is reference source; it is not executed or emulated.
