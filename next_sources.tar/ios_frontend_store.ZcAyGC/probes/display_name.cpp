#include "rline/rl.h"
#if !RSG_IOS || !RSG_CPU_ARM64 || RSG_PC || RSG_ORBIS || RSG_DURANGO
#error "display-name probe requires the real iOS ARM64 selection"
#endif
static_assert(rage::RL_MAX_NAME_BUF_SIZE == 16, "existing generic name capacity changed");
static_assert(rage::RL_MAX_DISPLAY_NAME_BUF_SIZE == rage::RL_MAX_NAME_BUF_SIZE, "display name must use existing name bound");
static_assert(sizeof(rage::rlDisplayName) == sizeof(rage::rlGamertag), "display/tag storage mismatch");
static_assert(sizeof(rage::rlDisplayName) == 16, "NUL-inclusive display capacity");
