#include "frontend/PauseMenuData.h"
#include <type_traits>
namespace iosPauseReference {
enum eMenuOption {
MENU_OPTION_SLIDER,
MENU_OPTION_DISPLAY_ON_OFF,
MENU_OPTION_DISPLAY_INVERT_LOOK,
MENU_OPTION_DISPLAY_TARGET_CONFIG,
MENU_OPTION_DISPLAY_CONTROL_CONFIG,
MENU_OPTION_CONTROLLER_SENSITIVITY,
MENU_OPTION_DISPLAY_GPS_SPEECH,
MENU_OPTION_DISPLAY_SPEAKER_OUTPUT,
MENU_OPTION_DISPLAY_SWHEADSET,
MENU_OPTION_DISPLAY_RADIO_STATIONS,
MENU_OPTION_DISPLAY_VOICE_OUTPUT,
MENU_OPTION_DISPLAY_UR_PLAYMODE,
MENU_OPTION_DISPLAY_AUDIO_MUTE_ON_FOCUS_LOSS,
MENU_OPTION_DISPLAY_MINIMAP_MODE,
MENU_OPTION_DISPLAY_RETICLE_MODE,
MENU_OPTION_DISPLAY_LANGUAGE,
MENU_OPTION_CAMERA_HEIGHT,
MENU_OPTION_DISPLAY_SS_FRONTREAR,
MENU_OPTION_CAMERA_ZOOM,
MENU_OPTION_CAMERA_ZOOM_NO_FP,
MENU_OPTION_GAME_FLOW,
MENU_OPTION_GFX_QUALITY,
MENU_OPTION_GFX_SHADERQ,
MENU_OPTION_GFX_SHADOWS,
MENU_OPTION_GFX_SOFTNESS,
MENU_OPTION_GFX_WATER,
MENU_OPTION_VID_VSYNC,
MENU_OPTION_VID_ASPECT,
MENU_OPTION_GFX_MSAA,
MENU_OPTION_GFX_ANISOT,
MENU_OPTION_GFX_AMBIENTOCC,
MENU_OPTION_GFX_DXVERSION,
MENU_OPTION_GFX_NIGHTLIGHTS,
MENU_OPTION_ROLL_YAW_PITCH,
MENU_OPTION_MEMORY_GRAPH,
MENU_OPTION_SCREEN_TYPE,
MENU_OPTION_DISPLAY_VOICE_TYPE,
MENU_OPTION_VOICE_FEEDBACK,
MENU_OPTION_MOUSE_TYPE,
MENU_OPTION_REPLAY_MODE,
MENU_OPTION_REPLAY_MEM_LIMIT,
MENU_OPTION_REPLAY_AUTO_RESUME_RECORDING,
MENU_OPTION_REPLAY_AUTO_SAVE_RECORDING,
MENU_OPTION_VIDEO_UPLOAD_PRIVACY,
MENU_OPTION_CONTROLS_CONTEXT,
MENU_OPTION_DISPLAY_CONTROL_DRIVEBY,
MENU_OPTION_FEED_DELAY,
MENU_OPTION_GFX_REFLECTION,
MENU_OPTION_CAM_VEH_OFF,
MENU_OPTION_DISPLAY_MEASUREMENT,
MENU_OPTION_FPS_DEFAULT_AIM_TYPE,
};
enum eDepth {
MENU_DEPTH_HEADER,
MENU_DEPTH_1ST,
MENU_DEPTH_2ND,
MENU_DEPTH_3RD,
MENU_DEPTH_4TH,
};
enum eMenuAction {
MENU_OPTION_ACTION_NONE,
MENU_OPTION_ACTION_LINK,
MENU_OPTION_ACTION_PREF_CHANGE,
MENU_OPTION_ACTION_TRIGGER,
MENU_OPTION_ACTION_FILL_CONTENT,
MENU_OPTION_ACTION_FILL_CONTENT_FROM_SCRIPT,
MENU_OPTION_ACTION_INCEPT,
MENU_OPTION_ACTION_REFERENCE,
MENU_OPTION_ACTION_SEPARATOR,
};
enum eMenuItemBits {
InitiallyDisabled,
};
enum eMenuScreenBits {
NotDimmable,
Input_NoAdvance,
Input_NoBack,
Input_NoBackIfNavigating,
Input_NoTabChange,
Sound_NoAccept,
AlwaysUseButtons,
SF_NoClearRootColumns,
SF_NoChangeLayout,
SF_NoMenuAdvance,
SF_CallImmediately,
NeverGenerateMenuData,
LayoutChangedOnBack,
HandlesDisplayDataSlot,
EnterMenuOnMouseClick,
};
enum eMenuScrollBits {
Width_1,
Width_2,
Width_3,
InitiallyVisible,
InitiallyInvisible,
ManualUpdate,
ShowIfNotFull,
ShowAsPages,
Arrows_LeftRight,
Arrows_UpDown,
Align_Left,
Align_Right,
Offset_2Left,
Offset_1Left,
Offset_1Right,
Offset_2Right,
};
enum eMenuVersionBits {
kRenderMenusInitially,
kNoBackground,
kFadesIn,
kGeneratesMenuData,
kNoPlayerInfo,
kNoHeaderText,
kMenuSectionJump,
kNoSwitchDelay,
kNoTabChangeWhileLocked,
kNoTabChange,
kAllowBackingOut,
kAllowStartButton,
kNotDimmable,
kAllHighlighted,
kHideHeaders,
kTabsAreColumns,
kForceButtonRender,
kForceProcessInput,
kAutoShiftDepth,
kNoTimeWarp,
kCanHide,
kUseAlternateContentPos,
kNoPeds,
kAllowBackingOutInMenu,
kDelayAudioUntilUnsuppressed,
};
enum eMenuScreen {
MENU_UNIQUE_ID_INVALID = -1,
MENU_UNIQUE_ID_MAP = 0,
MENU_UNIQUE_ID_START = 0,
MENU_UNIQUE_ID_INFO,
MENU_UNIQUE_ID_FRIENDS,
MENU_UNIQUE_ID_GALLERY,
MENU_UNIQUE_ID_SOCIALCLUB,
MENU_UNIQUE_ID_GAME,
MENU_UNIQUE_ID_SETTINGS,
MENU_UNIQUE_ID_PLAYERS,
MENU_UNIQUE_ID_WEAPONS,
MENU_UNIQUE_ID_MEDALS,
MENU_UNIQUE_ID_STATS,
MENU_UNIQUE_ID_AVAILABLE,
MENU_UNIQUE_ID_VAGOS,
MENU_UNIQUE_ID_COPS,
MENU_UNIQUE_ID_LOST,
MENU_UNIQUE_ID_HOME_MISSION,
MENU_UNIQUE_ID_CORONA_SETTINGS,
MENU_UNIQUE_ID_CORONA_INVITE,
MENU_UNIQUE_ID_STORE,
MENU_UNIQUE_ID_HOME_HELP,
MENU_UNIQUE_ID_HOME_BRIEF,
MENU_UNIQUE_ID_HOME_FEED,
MENU_UNIQUE_ID_SETTINGS_AUDIO,
MENU_UNIQUE_ID_SETTINGS_DISPLAY,
MENU_UNIQUE_ID_SETTINGS_CONTROLS,
MENU_UNIQUE_ID_NEW_GAME,
MENU_UNIQUE_ID_LOAD_GAME,
MENU_UNIQUE_ID_SAVE_GAME,
MENU_UNIQUE_ID_HEADER,
MENU_UNIQUE_ID_HEADER_SAVE_GAME,
MENU_UNIQUE_ID_HOME,
MENU_UNIQUE_ID_CREWS,
MENU_UNIQUE_ID_SETTINGS_SAVEGAME,
MENU_UNIQUE_ID_GALLERY_ITEM,
MENU_UNIQUE_ID_FREEMODE,
MENU_UNIQUE_ID_MP_CHAR_1,
MENU_UNIQUE_ID_MP_CHAR_2,
MENU_UNIQUE_ID_MP_CHAR_3,
MENU_UNIQUE_ID_MP_CHAR_4,
MENU_UNIQUE_ID_MP_CHAR_5,
MENU_UNIQUE_ID_HEADER_MULTIPLAYER,
MENU_UNIQUE_ID_HEADER_MY_MP,
MENU_UNIQUE_ID_MISSION_CREATOR,
MENU_UNIQUE_ID_GAME_MP,
MENU_UNIQUE_ID_LEAVE_GAME,
MENU_UNIQUE_ID_HEADER_PRE_LOBBY,
MENU_UNIQUE_ID_HEADER_LOBBY,
MENU_UNIQUE_ID_PARTY,
MENU_UNIQUE_ID_LOBBY,
MENU_UNIQUE_ID_PLACEHOLDER,
MENU_UNIQUE_ID_STATS_CATEGORY,
MENU_UNIQUE_ID_SETTINGS_LIST,
MENU_UNIQUE_ID_SAVE_GAME_LIST,
MENU_UNIQUE_ID_MAP_LEGEND,
MENU_UNIQUE_ID_CREWS_CATEGORY,
MENU_UNIQUE_ID_CREWS_FILTER,
MENU_UNIQUE_ID_CREWS_CARD,
MENU_UNIQUE_ID_SPECTATOR,
MENU_UNIQUE_ID_STATS_LISTITEM,
MENU_UNIQUE_ID_CREW_MINE,
MENU_UNIQUE_ID_CREW_ROCKSTAR,
MENU_UNIQUE_ID_CREW_FRIENDS,
MENU_UNIQUE_ID_CREW_INVITES,
MENU_UNIQUE_ID_CREW_LIST,
MENU_UNIQUE_ID_MISSION_CREATOR_CATEGORY,
MENU_UNIQUE_ID_MISSION_CREATOR_LISTITEM,
MENU_UNIQUE_ID_MISSION_CREATOR_STAT,
MENU_UNIQUE_ID_FRIENDS_LIST,
MENU_UNIQUE_ID_FRIENDS_OPTIONS,
MENU_UNIQUE_ID_HEADER_MP_CHARACTER_SELECT,
MENU_UNIQUE_ID_HEADER_MP_CHARACTER_CREATION,
MENU_UNIQUE_ID_CREATION_HERITAGE,
MENU_UNIQUE_ID_CREATION_LIFESTYLE,
MENU_UNIQUE_ID_CREATION_YOU,
MENU_UNIQUE_ID_PARTY_LIST,
MENU_UNIQUE_ID_REPLAY_MISSION,
MENU_UNIQUE_ID_REPLAY_MISSION_LIST,
MENU_UNIQUE_ID_REPLAY_MISSION_ACTIVITY,
MENU_UNIQUE_ID_CREW,
MENU_UNIQUE_ID_CREATION_HERITAGE_LIST,
MENU_UNIQUE_ID_CREATION_LIFESTYLE_LIST,
MENU_UNIQUE_ID_PLAYERS_LIST,
MENU_UNIQUE_ID_PLAYERS_OPTIONS,
MENU_UNIQUE_ID_PLAYERS_OPTIONS_LIST,
MENU_UNIQUE_ID_PARTY_OPTIONS,
MENU_UNIQUE_ID_PARTY_OPTIONS_LIST,
MENU_UNIQUE_ID_CREW_OPTIONS,
MENU_UNIQUE_ID_CREW_OPTIONS_LIST,
MENU_UNIQUE_ID_FRIENDS_OPTIONS_LIST,
MENU_UNIQUE_ID_FRIENDS_MP,
MENU_UNIQUE_ID_TEAM_SELECT,
MENU_UNIQUE_ID_HOME_DIALOG,
MENU_UNIQUE_ID_HEADER_EMPTY,
MENU_UNIQUE_ID_SETTINGS_FEED,
MENU_UNIQUE_ID_GALLERY_OPTIONS,
MENU_UNIQUE_ID_GALLERY_OPTIONS_LIST,
MENU_UNIQUE_ID_BRIGHTNESS_CALIBRATION,
MENU_UNIQUE_ID_HEADER_TEXT_SELECTION,
MENU_UNIQUE_ID_LOBBY_LIST,
MENU_UNIQUE_ID_LOBBY_LIST_ITEM,
MENU_UNIQUE_ID_HEADER_CORONA,
MENU_UNIQUE_ID_HEADER_CORONA_LOBBY,
MENU_UNIQUE_ID_HEADER_CORONA_JOINED_PLAYERS,
MENU_UNIQUE_ID_HEADER_CORONA_INVITE_PLAYERS,
MENU_UNIQUE_ID_HEADER_CORONA_INVITE_FRIENDS,
MENU_UNIQUE_ID_HEADER_CORONA_INVITE_CREWS,
MENU_UNIQUE_ID_CORONA_JOINED_PLAYERS,
MENU_UNIQUE_ID_CORONA_INVITE_PLAYERS,
MENU_UNIQUE_ID_CORONA_INVITE_FRIENDS,
MENU_UNIQUE_ID_CORONA_INVITE_CREWS,
MENU_UNIQUE_ID_SETTINGS_FACEBOOK,
MENU_UNIQUE_ID_HEADER_JOINING_SCREEN,
MENU_UNIQUE_ID_CORONA_SETTINGS_LIST,
MENU_UNIQUE_ID_CORONA_DETAILS_LIST,
MENU_UNIQUE_ID_CORONA_INVITE_LIST,
MENU_UNIQUE_ID_CORONA_JOINED_LIST,
MENU_UNIQUE_ID_HEADER_CORONA_INVITE_MATCHED_PLAYERS,
MENU_UNIQUE_ID_HEADER_CORONA_INVITE_LAST_JOB_PLAYERS,
MENU_UNIQUE_ID_CORONA_INVITE_MATCHED_PLAYERS,
MENU_UNIQUE_ID_CORONA_INVITE_LAST_JOB_PLAYERS,
MENU_UNIQUE_ID_CREW_LEADERBOARDS,
MENU_UNIQUE_ID_HOME_OPEN_JOBS,
MENU_UNIQUE_ID_CREW_REQUEST,
MENU_UNIQUE_ID_HEADER_RACE,
MENU_UNIQUE_ID_RACE_INFO,
MENU_UNIQUE_ID_RACE_INFOLIST,
MENU_UNIQUE_ID_RACE_LOBBYLIST,
MENU_UNIQUE_ID_HEADER_BETTING,
MENU_UNIQUE_ID_BETTING,
MENU_UNIQUE_ID_BETTING_INFOLIST,
MENU_UNIQUE_ID_BETTING_LOBBYLIST,
MENU_UNIQUE_ID_INCEPT_TRIGGER,
MENU_UNIQUE_ID_SETTINGS_SIXAXIS,
MENU_UNIQUE_ID_REPLAY_RANDOM,
MENU_UNIQUE_ID_CUTSCENE_EMPTY,
MENU_UNIQUE_ID_HOME_NEWSWIRE,
MENU_UNIQUE_ID_SETTINGS_CAMERA,
MENU_UNIQUE_ID_SETTINGS_GRAPHICS,
MENU_UNIQUE_ID_SETTINGS_ADVANCED_GFX,
MENU_UNIQUE_ID_SETTINGS_VOICE_CHAT,
MENU_UNIQUE_ID_SETTINGS_MISC_CONTROLS,
MENU_UNIQUE_ID_HELP,
MENU_UNIQUE_ID_MOVIE_EDITOR,
MENU_UNIQUE_ID_EXIT_TO_WINDOWS,
MENU_UNIQUE_ID_HEADER_LANDING_PAGE,
MENU_UNIQUE_ID_SHOW_ACCOUNT_PICKER,
MENU_UNIQUE_ID_SETTINGS_REPLAY,
MENU_UNIQUE_ID_REPLAY_EDITOR,
MENU_UNIQUE_ID_KEYMAP,
MENU_UNIQUE_ID_KEYMAP_LIST,
MENU_UNIQUE_ID_KEYMAP_LISTITEM,
MENU_UNIQUE_ID_SETTINGS_FIRST_PERSON,
MENU_UNIQUE_ID_HEADER_LANDING_KEYMAPPING,
MENU_UNIQUE_ID_PROCESS_SAVEGAME,
MENU_UNIQUE_ID_PROCESS_SAVEGAME_LIST,
MENU_UNIQUE_ID_IMPORT_SAVEGAME,
MENU_UNIQUE_ID_CREDITS,
MENU_UNIQUE_ID_LEGAL,
MENU_UNIQUE_ID_CREDITS_LEGAL,
};
enum eInstructionButtons {
ARROW_UP,
ARROW_DOWN,
ARROW_LEFT,
ARROW_RIGHT,
DPAD_UP,
DPAD_DOWN,
DPAD_LEFT,
DPAD_RIGHT,
DPAD_NONE,
DPAD_ALL,
DPAD_UPDOWN,
DPAD_LEFTRIGHT,
LSTICK_UP,
LSTICK_DOWN,
LSTICK_LEFT,
LSTICK_RIGHT,
LSTICK_CLICK,
LSTICK_ALL,
LSTICK_UPDOWN,
LSTICK_LEFTRIGHT,
LSTICK_ROTATE,
RSTICK_UP,
RSTICK_DOWN,
RSTICK_LEFT,
RSTICK_RIGHT,
RSTICK_CLICK,
RSTICK_ALL,
RSTICK_UPDOWN,
RSTICK_LEFTRIGHT,
RSTICK_ROTATE,
BUTTON_A,
BUTTON_B,
BUTTON_X,
BUTTON_Y,
BUTTON_L1,
BUTTON_L2,
BUTTON_R1,
BUTTON_R2,
BUTTON_START,
BUTTON_BACK,
SIXAXIS_YAW,
SIXAXIS_PITCH,
SIXAXIS_PITCH_UP,
SIXAXIS_ROLL,
ICON_SPINNER,
ARROW_UPDOWN,
ARROW_LEFTRIGHT,
ARROW_ALL,
BUTTONS_TRIGGERS,
BUTTONS_BUMPERS,
STICK_CLICKS,
NOTHING,
MAX_INSTRUCTIONAL_BUTTONS,
ICON_INVALID = 9999,
};
}
static_assert(eMenuOption_NUM_ENUMS == 51, "PSC enum count");
static_assert((long long)::MENU_OPTION_SLIDER == (long long)iosPauseReference::MENU_OPTION_SLIDER, "PSC value: MENU_OPTION_SLIDER");
static_assert((long long)::MENU_OPTION_DISPLAY_ON_OFF == (long long)iosPauseReference::MENU_OPTION_DISPLAY_ON_OFF, "PSC value: MENU_OPTION_DISPLAY_ON_OFF");
static_assert((long long)::MENU_OPTION_DISPLAY_INVERT_LOOK == (long long)iosPauseReference::MENU_OPTION_DISPLAY_INVERT_LOOK, "PSC value: MENU_OPTION_DISPLAY_INVERT_LOOK");
static_assert((long long)::MENU_OPTION_DISPLAY_TARGET_CONFIG == (long long)iosPauseReference::MENU_OPTION_DISPLAY_TARGET_CONFIG, "PSC value: MENU_OPTION_DISPLAY_TARGET_CONFIG");
static_assert((long long)::MENU_OPTION_DISPLAY_CONTROL_CONFIG == (long long)iosPauseReference::MENU_OPTION_DISPLAY_CONTROL_CONFIG, "PSC value: MENU_OPTION_DISPLAY_CONTROL_CONFIG");
static_assert((long long)::MENU_OPTION_CONTROLLER_SENSITIVITY == (long long)iosPauseReference::MENU_OPTION_CONTROLLER_SENSITIVITY, "PSC value: MENU_OPTION_CONTROLLER_SENSITIVITY");
static_assert((long long)::MENU_OPTION_DISPLAY_GPS_SPEECH == (long long)iosPauseReference::MENU_OPTION_DISPLAY_GPS_SPEECH, "PSC value: MENU_OPTION_DISPLAY_GPS_SPEECH");
static_assert((long long)::MENU_OPTION_DISPLAY_SPEAKER_OUTPUT == (long long)iosPauseReference::MENU_OPTION_DISPLAY_SPEAKER_OUTPUT, "PSC value: MENU_OPTION_DISPLAY_SPEAKER_OUTPUT");
static_assert((long long)::MENU_OPTION_DISPLAY_SWHEADSET == (long long)iosPauseReference::MENU_OPTION_DISPLAY_SWHEADSET, "PSC value: MENU_OPTION_DISPLAY_SWHEADSET");
static_assert((long long)::MENU_OPTION_DISPLAY_RADIO_STATIONS == (long long)iosPauseReference::MENU_OPTION_DISPLAY_RADIO_STATIONS, "PSC value: MENU_OPTION_DISPLAY_RADIO_STATIONS");
static_assert((long long)::MENU_OPTION_DISPLAY_VOICE_OUTPUT == (long long)iosPauseReference::MENU_OPTION_DISPLAY_VOICE_OUTPUT, "PSC value: MENU_OPTION_DISPLAY_VOICE_OUTPUT");
static_assert((long long)::MENU_OPTION_DISPLAY_UR_PLAYMODE == (long long)iosPauseReference::MENU_OPTION_DISPLAY_UR_PLAYMODE, "PSC value: MENU_OPTION_DISPLAY_UR_PLAYMODE");
static_assert((long long)::MENU_OPTION_DISPLAY_AUDIO_MUTE_ON_FOCUS_LOSS == (long long)iosPauseReference::MENU_OPTION_DISPLAY_AUDIO_MUTE_ON_FOCUS_LOSS, "PSC value: MENU_OPTION_DISPLAY_AUDIO_MUTE_ON_FOCUS_LOSS");
static_assert((long long)::MENU_OPTION_DISPLAY_MINIMAP_MODE == (long long)iosPauseReference::MENU_OPTION_DISPLAY_MINIMAP_MODE, "PSC value: MENU_OPTION_DISPLAY_MINIMAP_MODE");
static_assert((long long)::MENU_OPTION_DISPLAY_RETICLE_MODE == (long long)iosPauseReference::MENU_OPTION_DISPLAY_RETICLE_MODE, "PSC value: MENU_OPTION_DISPLAY_RETICLE_MODE");
static_assert((long long)::MENU_OPTION_DISPLAY_LANGUAGE == (long long)iosPauseReference::MENU_OPTION_DISPLAY_LANGUAGE, "PSC value: MENU_OPTION_DISPLAY_LANGUAGE");
static_assert((long long)::MENU_OPTION_CAMERA_HEIGHT == (long long)iosPauseReference::MENU_OPTION_CAMERA_HEIGHT, "PSC value: MENU_OPTION_CAMERA_HEIGHT");
static_assert((long long)::MENU_OPTION_DISPLAY_SS_FRONTREAR == (long long)iosPauseReference::MENU_OPTION_DISPLAY_SS_FRONTREAR, "PSC value: MENU_OPTION_DISPLAY_SS_FRONTREAR");
static_assert((long long)::MENU_OPTION_CAMERA_ZOOM == (long long)iosPauseReference::MENU_OPTION_CAMERA_ZOOM, "PSC value: MENU_OPTION_CAMERA_ZOOM");
static_assert((long long)::MENU_OPTION_CAMERA_ZOOM_NO_FP == (long long)iosPauseReference::MENU_OPTION_CAMERA_ZOOM_NO_FP, "PSC value: MENU_OPTION_CAMERA_ZOOM_NO_FP");
static_assert((long long)::MENU_OPTION_GAME_FLOW == (long long)iosPauseReference::MENU_OPTION_GAME_FLOW, "PSC value: MENU_OPTION_GAME_FLOW");
static_assert((long long)::MENU_OPTION_GFX_QUALITY == (long long)iosPauseReference::MENU_OPTION_GFX_QUALITY, "PSC value: MENU_OPTION_GFX_QUALITY");
static_assert((long long)::MENU_OPTION_GFX_SHADERQ == (long long)iosPauseReference::MENU_OPTION_GFX_SHADERQ, "PSC value: MENU_OPTION_GFX_SHADERQ");
static_assert((long long)::MENU_OPTION_GFX_SHADOWS == (long long)iosPauseReference::MENU_OPTION_GFX_SHADOWS, "PSC value: MENU_OPTION_GFX_SHADOWS");
static_assert((long long)::MENU_OPTION_GFX_SOFTNESS == (long long)iosPauseReference::MENU_OPTION_GFX_SOFTNESS, "PSC value: MENU_OPTION_GFX_SOFTNESS");
static_assert((long long)::MENU_OPTION_GFX_WATER == (long long)iosPauseReference::MENU_OPTION_GFX_WATER, "PSC value: MENU_OPTION_GFX_WATER");
static_assert((long long)::MENU_OPTION_VID_VSYNC == (long long)iosPauseReference::MENU_OPTION_VID_VSYNC, "PSC value: MENU_OPTION_VID_VSYNC");
static_assert((long long)::MENU_OPTION_VID_ASPECT == (long long)iosPauseReference::MENU_OPTION_VID_ASPECT, "PSC value: MENU_OPTION_VID_ASPECT");
static_assert((long long)::MENU_OPTION_GFX_MSAA == (long long)iosPauseReference::MENU_OPTION_GFX_MSAA, "PSC value: MENU_OPTION_GFX_MSAA");
static_assert((long long)::MENU_OPTION_GFX_ANISOT == (long long)iosPauseReference::MENU_OPTION_GFX_ANISOT, "PSC value: MENU_OPTION_GFX_ANISOT");
static_assert((long long)::MENU_OPTION_GFX_AMBIENTOCC == (long long)iosPauseReference::MENU_OPTION_GFX_AMBIENTOCC, "PSC value: MENU_OPTION_GFX_AMBIENTOCC");
static_assert((long long)::MENU_OPTION_GFX_DXVERSION == (long long)iosPauseReference::MENU_OPTION_GFX_DXVERSION, "PSC value: MENU_OPTION_GFX_DXVERSION");
static_assert((long long)::MENU_OPTION_GFX_NIGHTLIGHTS == (long long)iosPauseReference::MENU_OPTION_GFX_NIGHTLIGHTS, "PSC value: MENU_OPTION_GFX_NIGHTLIGHTS");
static_assert((long long)::MENU_OPTION_ROLL_YAW_PITCH == (long long)iosPauseReference::MENU_OPTION_ROLL_YAW_PITCH, "PSC value: MENU_OPTION_ROLL_YAW_PITCH");
static_assert((long long)::MENU_OPTION_MEMORY_GRAPH == (long long)iosPauseReference::MENU_OPTION_MEMORY_GRAPH, "PSC value: MENU_OPTION_MEMORY_GRAPH");
static_assert((long long)::MENU_OPTION_SCREEN_TYPE == (long long)iosPauseReference::MENU_OPTION_SCREEN_TYPE, "PSC value: MENU_OPTION_SCREEN_TYPE");
static_assert((long long)::MENU_OPTION_DISPLAY_VOICE_TYPE == (long long)iosPauseReference::MENU_OPTION_DISPLAY_VOICE_TYPE, "PSC value: MENU_OPTION_DISPLAY_VOICE_TYPE");
static_assert((long long)::MENU_OPTION_VOICE_FEEDBACK == (long long)iosPauseReference::MENU_OPTION_VOICE_FEEDBACK, "PSC value: MENU_OPTION_VOICE_FEEDBACK");
static_assert((long long)::MENU_OPTION_MOUSE_TYPE == (long long)iosPauseReference::MENU_OPTION_MOUSE_TYPE, "PSC value: MENU_OPTION_MOUSE_TYPE");
static_assert((long long)::MENU_OPTION_REPLAY_MODE == (long long)iosPauseReference::MENU_OPTION_REPLAY_MODE, "PSC value: MENU_OPTION_REPLAY_MODE");
static_assert((long long)::MENU_OPTION_REPLAY_MEM_LIMIT == (long long)iosPauseReference::MENU_OPTION_REPLAY_MEM_LIMIT, "PSC value: MENU_OPTION_REPLAY_MEM_LIMIT");
static_assert((long long)::MENU_OPTION_REPLAY_AUTO_RESUME_RECORDING == (long long)iosPauseReference::MENU_OPTION_REPLAY_AUTO_RESUME_RECORDING, "PSC value: MENU_OPTION_REPLAY_AUTO_RESUME_RECORDING");
static_assert((long long)::MENU_OPTION_REPLAY_AUTO_SAVE_RECORDING == (long long)iosPauseReference::MENU_OPTION_REPLAY_AUTO_SAVE_RECORDING, "PSC value: MENU_OPTION_REPLAY_AUTO_SAVE_RECORDING");
static_assert((long long)::MENU_OPTION_VIDEO_UPLOAD_PRIVACY == (long long)iosPauseReference::MENU_OPTION_VIDEO_UPLOAD_PRIVACY, "PSC value: MENU_OPTION_VIDEO_UPLOAD_PRIVACY");
static_assert((long long)::MENU_OPTION_CONTROLS_CONTEXT == (long long)iosPauseReference::MENU_OPTION_CONTROLS_CONTEXT, "PSC value: MENU_OPTION_CONTROLS_CONTEXT");
static_assert((long long)::MENU_OPTION_DISPLAY_CONTROL_DRIVEBY == (long long)iosPauseReference::MENU_OPTION_DISPLAY_CONTROL_DRIVEBY, "PSC value: MENU_OPTION_DISPLAY_CONTROL_DRIVEBY");
static_assert((long long)::MENU_OPTION_FEED_DELAY == (long long)iosPauseReference::MENU_OPTION_FEED_DELAY, "PSC value: MENU_OPTION_FEED_DELAY");
static_assert((long long)::MENU_OPTION_GFX_REFLECTION == (long long)iosPauseReference::MENU_OPTION_GFX_REFLECTION, "PSC value: MENU_OPTION_GFX_REFLECTION");
static_assert((long long)::MENU_OPTION_CAM_VEH_OFF == (long long)iosPauseReference::MENU_OPTION_CAM_VEH_OFF, "PSC value: MENU_OPTION_CAM_VEH_OFF");
static_assert((long long)::MENU_OPTION_DISPLAY_MEASUREMENT == (long long)iosPauseReference::MENU_OPTION_DISPLAY_MEASUREMENT, "PSC value: MENU_OPTION_DISPLAY_MEASUREMENT");
static_assert((long long)::MENU_OPTION_FPS_DEFAULT_AIM_TYPE == (long long)iosPauseReference::MENU_OPTION_FPS_DEFAULT_AIM_TYPE, "PSC value: MENU_OPTION_FPS_DEFAULT_AIM_TYPE");
static_assert(eDepth_NUM_ENUMS == 5, "PSC enum count");
static_assert((long long)::MENU_DEPTH_HEADER == (long long)iosPauseReference::MENU_DEPTH_HEADER, "PSC value: MENU_DEPTH_HEADER");
static_assert((long long)::MENU_DEPTH_1ST == (long long)iosPauseReference::MENU_DEPTH_1ST, "PSC value: MENU_DEPTH_1ST");
static_assert((long long)::MENU_DEPTH_2ND == (long long)iosPauseReference::MENU_DEPTH_2ND, "PSC value: MENU_DEPTH_2ND");
static_assert((long long)::MENU_DEPTH_3RD == (long long)iosPauseReference::MENU_DEPTH_3RD, "PSC value: MENU_DEPTH_3RD");
static_assert((long long)::MENU_DEPTH_4TH == (long long)iosPauseReference::MENU_DEPTH_4TH, "PSC value: MENU_DEPTH_4TH");
static_assert(eMenuAction_NUM_ENUMS == 9, "PSC enum count");
static_assert((long long)::MENU_OPTION_ACTION_NONE == (long long)iosPauseReference::MENU_OPTION_ACTION_NONE, "PSC value: MENU_OPTION_ACTION_NONE");
static_assert((long long)::MENU_OPTION_ACTION_LINK == (long long)iosPauseReference::MENU_OPTION_ACTION_LINK, "PSC value: MENU_OPTION_ACTION_LINK");
static_assert((long long)::MENU_OPTION_ACTION_PREF_CHANGE == (long long)iosPauseReference::MENU_OPTION_ACTION_PREF_CHANGE, "PSC value: MENU_OPTION_ACTION_PREF_CHANGE");
static_assert((long long)::MENU_OPTION_ACTION_TRIGGER == (long long)iosPauseReference::MENU_OPTION_ACTION_TRIGGER, "PSC value: MENU_OPTION_ACTION_TRIGGER");
static_assert((long long)::MENU_OPTION_ACTION_FILL_CONTENT == (long long)iosPauseReference::MENU_OPTION_ACTION_FILL_CONTENT, "PSC value: MENU_OPTION_ACTION_FILL_CONTENT");
static_assert((long long)::MENU_OPTION_ACTION_FILL_CONTENT_FROM_SCRIPT == (long long)iosPauseReference::MENU_OPTION_ACTION_FILL_CONTENT_FROM_SCRIPT, "PSC value: MENU_OPTION_ACTION_FILL_CONTENT_FROM_SCRIPT");
static_assert((long long)::MENU_OPTION_ACTION_INCEPT == (long long)iosPauseReference::MENU_OPTION_ACTION_INCEPT, "PSC value: MENU_OPTION_ACTION_INCEPT");
static_assert((long long)::MENU_OPTION_ACTION_REFERENCE == (long long)iosPauseReference::MENU_OPTION_ACTION_REFERENCE, "PSC value: MENU_OPTION_ACTION_REFERENCE");
static_assert((long long)::MENU_OPTION_ACTION_SEPARATOR == (long long)iosPauseReference::MENU_OPTION_ACTION_SEPARATOR, "PSC value: MENU_OPTION_ACTION_SEPARATOR");
static_assert(eMenuItemBits_NUM_ENUMS == 1, "PSC enum count");
static_assert((long long)::InitiallyDisabled == (long long)iosPauseReference::InitiallyDisabled, "PSC value: InitiallyDisabled");
static_assert(eMenuScreenBits_NUM_ENUMS == 15, "PSC enum count");
static_assert((long long)::NotDimmable == (long long)iosPauseReference::NotDimmable, "PSC value: NotDimmable");
static_assert((long long)::Input_NoAdvance == (long long)iosPauseReference::Input_NoAdvance, "PSC value: Input_NoAdvance");
static_assert((long long)::Input_NoBack == (long long)iosPauseReference::Input_NoBack, "PSC value: Input_NoBack");
static_assert((long long)::Input_NoBackIfNavigating == (long long)iosPauseReference::Input_NoBackIfNavigating, "PSC value: Input_NoBackIfNavigating");
static_assert((long long)::Input_NoTabChange == (long long)iosPauseReference::Input_NoTabChange, "PSC value: Input_NoTabChange");
static_assert((long long)::Sound_NoAccept == (long long)iosPauseReference::Sound_NoAccept, "PSC value: Sound_NoAccept");
static_assert((long long)::AlwaysUseButtons == (long long)iosPauseReference::AlwaysUseButtons, "PSC value: AlwaysUseButtons");
static_assert((long long)::SF_NoClearRootColumns == (long long)iosPauseReference::SF_NoClearRootColumns, "PSC value: SF_NoClearRootColumns");
static_assert((long long)::SF_NoChangeLayout == (long long)iosPauseReference::SF_NoChangeLayout, "PSC value: SF_NoChangeLayout");
static_assert((long long)::SF_NoMenuAdvance == (long long)iosPauseReference::SF_NoMenuAdvance, "PSC value: SF_NoMenuAdvance");
static_assert((long long)::SF_CallImmediately == (long long)iosPauseReference::SF_CallImmediately, "PSC value: SF_CallImmediately");
static_assert((long long)::NeverGenerateMenuData == (long long)iosPauseReference::NeverGenerateMenuData, "PSC value: NeverGenerateMenuData");
static_assert((long long)::LayoutChangedOnBack == (long long)iosPauseReference::LayoutChangedOnBack, "PSC value: LayoutChangedOnBack");
static_assert((long long)::HandlesDisplayDataSlot == (long long)iosPauseReference::HandlesDisplayDataSlot, "PSC value: HandlesDisplayDataSlot");
static_assert((long long)::EnterMenuOnMouseClick == (long long)iosPauseReference::EnterMenuOnMouseClick, "PSC value: EnterMenuOnMouseClick");
static_assert(eMenuScrollBits_NUM_ENUMS == 16, "PSC enum count");
static_assert((long long)::Width_1 == (long long)iosPauseReference::Width_1, "PSC value: Width_1");
static_assert((long long)::Width_2 == (long long)iosPauseReference::Width_2, "PSC value: Width_2");
static_assert((long long)::Width_3 == (long long)iosPauseReference::Width_3, "PSC value: Width_3");
static_assert((long long)::InitiallyVisible == (long long)iosPauseReference::InitiallyVisible, "PSC value: InitiallyVisible");
static_assert((long long)::InitiallyInvisible == (long long)iosPauseReference::InitiallyInvisible, "PSC value: InitiallyInvisible");
static_assert((long long)::ManualUpdate == (long long)iosPauseReference::ManualUpdate, "PSC value: ManualUpdate");
static_assert((long long)::ShowIfNotFull == (long long)iosPauseReference::ShowIfNotFull, "PSC value: ShowIfNotFull");
static_assert((long long)::ShowAsPages == (long long)iosPauseReference::ShowAsPages, "PSC value: ShowAsPages");
static_assert((long long)::Arrows_LeftRight == (long long)iosPauseReference::Arrows_LeftRight, "PSC value: Arrows_LeftRight");
static_assert((long long)::Arrows_UpDown == (long long)iosPauseReference::Arrows_UpDown, "PSC value: Arrows_UpDown");
static_assert((long long)::Align_Left == (long long)iosPauseReference::Align_Left, "PSC value: Align_Left");
static_assert((long long)::Align_Right == (long long)iosPauseReference::Align_Right, "PSC value: Align_Right");
static_assert((long long)::Offset_2Left == (long long)iosPauseReference::Offset_2Left, "PSC value: Offset_2Left");
static_assert((long long)::Offset_1Left == (long long)iosPauseReference::Offset_1Left, "PSC value: Offset_1Left");
static_assert((long long)::Offset_1Right == (long long)iosPauseReference::Offset_1Right, "PSC value: Offset_1Right");
static_assert((long long)::Offset_2Right == (long long)iosPauseReference::Offset_2Right, "PSC value: Offset_2Right");
static_assert(eMenuVersionBits_NUM_ENUMS == 25, "PSC enum count");
static_assert((long long)::kRenderMenusInitially == (long long)iosPauseReference::kRenderMenusInitially, "PSC value: kRenderMenusInitially");
static_assert((long long)::kNoBackground == (long long)iosPauseReference::kNoBackground, "PSC value: kNoBackground");
static_assert((long long)::kFadesIn == (long long)iosPauseReference::kFadesIn, "PSC value: kFadesIn");
static_assert((long long)::kGeneratesMenuData == (long long)iosPauseReference::kGeneratesMenuData, "PSC value: kGeneratesMenuData");
static_assert((long long)::kNoPlayerInfo == (long long)iosPauseReference::kNoPlayerInfo, "PSC value: kNoPlayerInfo");
static_assert((long long)::kNoHeaderText == (long long)iosPauseReference::kNoHeaderText, "PSC value: kNoHeaderText");
static_assert((long long)::kMenuSectionJump == (long long)iosPauseReference::kMenuSectionJump, "PSC value: kMenuSectionJump");
static_assert((long long)::kNoSwitchDelay == (long long)iosPauseReference::kNoSwitchDelay, "PSC value: kNoSwitchDelay");
static_assert((long long)::kNoTabChangeWhileLocked == (long long)iosPauseReference::kNoTabChangeWhileLocked, "PSC value: kNoTabChangeWhileLocked");
static_assert((long long)::kNoTabChange == (long long)iosPauseReference::kNoTabChange, "PSC value: kNoTabChange");
static_assert((long long)::kAllowBackingOut == (long long)iosPauseReference::kAllowBackingOut, "PSC value: kAllowBackingOut");
static_assert((long long)::kAllowStartButton == (long long)iosPauseReference::kAllowStartButton, "PSC value: kAllowStartButton");
static_assert((long long)::kNotDimmable == (long long)iosPauseReference::kNotDimmable, "PSC value: kNotDimmable");
static_assert((long long)::kAllHighlighted == (long long)iosPauseReference::kAllHighlighted, "PSC value: kAllHighlighted");
static_assert((long long)::kHideHeaders == (long long)iosPauseReference::kHideHeaders, "PSC value: kHideHeaders");
static_assert((long long)::kTabsAreColumns == (long long)iosPauseReference::kTabsAreColumns, "PSC value: kTabsAreColumns");
static_assert((long long)::kForceButtonRender == (long long)iosPauseReference::kForceButtonRender, "PSC value: kForceButtonRender");
static_assert((long long)::kForceProcessInput == (long long)iosPauseReference::kForceProcessInput, "PSC value: kForceProcessInput");
static_assert((long long)::kAutoShiftDepth == (long long)iosPauseReference::kAutoShiftDepth, "PSC value: kAutoShiftDepth");
static_assert((long long)::kNoTimeWarp == (long long)iosPauseReference::kNoTimeWarp, "PSC value: kNoTimeWarp");
static_assert((long long)::kCanHide == (long long)iosPauseReference::kCanHide, "PSC value: kCanHide");
static_assert((long long)::kUseAlternateContentPos == (long long)iosPauseReference::kUseAlternateContentPos, "PSC value: kUseAlternateContentPos");
static_assert((long long)::kNoPeds == (long long)iosPauseReference::kNoPeds, "PSC value: kNoPeds");
static_assert((long long)::kAllowBackingOutInMenu == (long long)iosPauseReference::kAllowBackingOutInMenu, "PSC value: kAllowBackingOutInMenu");
static_assert((long long)::kDelayAudioUntilUnsuppressed == (long long)iosPauseReference::kDelayAudioUntilUnsuppressed, "PSC value: kDelayAudioUntilUnsuppressed");
static_assert(eMenuScreen_NUM_ENUMS == 161, "PSC enum count");
static_assert((long long)::MENU_UNIQUE_ID_INVALID == (long long)iosPauseReference::MENU_UNIQUE_ID_INVALID, "PSC value: MENU_UNIQUE_ID_INVALID");
static_assert((long long)::MENU_UNIQUE_ID_MAP == (long long)iosPauseReference::MENU_UNIQUE_ID_MAP, "PSC value: MENU_UNIQUE_ID_MAP");
static_assert((long long)::MENU_UNIQUE_ID_START == (long long)iosPauseReference::MENU_UNIQUE_ID_START, "PSC value: MENU_UNIQUE_ID_START");
static_assert((long long)::MENU_UNIQUE_ID_INFO == (long long)iosPauseReference::MENU_UNIQUE_ID_INFO, "PSC value: MENU_UNIQUE_ID_INFO");
static_assert((long long)::MENU_UNIQUE_ID_FRIENDS == (long long)iosPauseReference::MENU_UNIQUE_ID_FRIENDS, "PSC value: MENU_UNIQUE_ID_FRIENDS");
static_assert((long long)::MENU_UNIQUE_ID_GALLERY == (long long)iosPauseReference::MENU_UNIQUE_ID_GALLERY, "PSC value: MENU_UNIQUE_ID_GALLERY");
static_assert((long long)::MENU_UNIQUE_ID_SOCIALCLUB == (long long)iosPauseReference::MENU_UNIQUE_ID_SOCIALCLUB, "PSC value: MENU_UNIQUE_ID_SOCIALCLUB");
static_assert((long long)::MENU_UNIQUE_ID_GAME == (long long)iosPauseReference::MENU_UNIQUE_ID_GAME, "PSC value: MENU_UNIQUE_ID_GAME");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS, "PSC value: MENU_UNIQUE_ID_SETTINGS");
static_assert((long long)::MENU_UNIQUE_ID_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_PLAYERS, "PSC value: MENU_UNIQUE_ID_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_WEAPONS == (long long)iosPauseReference::MENU_UNIQUE_ID_WEAPONS, "PSC value: MENU_UNIQUE_ID_WEAPONS");
static_assert((long long)::MENU_UNIQUE_ID_MEDALS == (long long)iosPauseReference::MENU_UNIQUE_ID_MEDALS, "PSC value: MENU_UNIQUE_ID_MEDALS");
static_assert((long long)::MENU_UNIQUE_ID_STATS == (long long)iosPauseReference::MENU_UNIQUE_ID_STATS, "PSC value: MENU_UNIQUE_ID_STATS");
static_assert((long long)::MENU_UNIQUE_ID_AVAILABLE == (long long)iosPauseReference::MENU_UNIQUE_ID_AVAILABLE, "PSC value: MENU_UNIQUE_ID_AVAILABLE");
static_assert((long long)::MENU_UNIQUE_ID_VAGOS == (long long)iosPauseReference::MENU_UNIQUE_ID_VAGOS, "PSC value: MENU_UNIQUE_ID_VAGOS");
static_assert((long long)::MENU_UNIQUE_ID_COPS == (long long)iosPauseReference::MENU_UNIQUE_ID_COPS, "PSC value: MENU_UNIQUE_ID_COPS");
static_assert((long long)::MENU_UNIQUE_ID_LOST == (long long)iosPauseReference::MENU_UNIQUE_ID_LOST, "PSC value: MENU_UNIQUE_ID_LOST");
static_assert((long long)::MENU_UNIQUE_ID_HOME_MISSION == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_MISSION, "PSC value: MENU_UNIQUE_ID_HOME_MISSION");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_SETTINGS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_SETTINGS, "PSC value: MENU_UNIQUE_ID_CORONA_SETTINGS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE");
static_assert((long long)::MENU_UNIQUE_ID_STORE == (long long)iosPauseReference::MENU_UNIQUE_ID_STORE, "PSC value: MENU_UNIQUE_ID_STORE");
static_assert((long long)::MENU_UNIQUE_ID_HOME_HELP == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_HELP, "PSC value: MENU_UNIQUE_ID_HOME_HELP");
static_assert((long long)::MENU_UNIQUE_ID_HOME_BRIEF == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_BRIEF, "PSC value: MENU_UNIQUE_ID_HOME_BRIEF");
static_assert((long long)::MENU_UNIQUE_ID_HOME_FEED == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_FEED, "PSC value: MENU_UNIQUE_ID_HOME_FEED");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_AUDIO == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_AUDIO, "PSC value: MENU_UNIQUE_ID_SETTINGS_AUDIO");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_DISPLAY == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_DISPLAY, "PSC value: MENU_UNIQUE_ID_SETTINGS_DISPLAY");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_CONTROLS == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_CONTROLS, "PSC value: MENU_UNIQUE_ID_SETTINGS_CONTROLS");
static_assert((long long)::MENU_UNIQUE_ID_NEW_GAME == (long long)iosPauseReference::MENU_UNIQUE_ID_NEW_GAME, "PSC value: MENU_UNIQUE_ID_NEW_GAME");
static_assert((long long)::MENU_UNIQUE_ID_LOAD_GAME == (long long)iosPauseReference::MENU_UNIQUE_ID_LOAD_GAME, "PSC value: MENU_UNIQUE_ID_LOAD_GAME");
static_assert((long long)::MENU_UNIQUE_ID_SAVE_GAME == (long long)iosPauseReference::MENU_UNIQUE_ID_SAVE_GAME, "PSC value: MENU_UNIQUE_ID_SAVE_GAME");
static_assert((long long)::MENU_UNIQUE_ID_HEADER == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER, "PSC value: MENU_UNIQUE_ID_HEADER");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_SAVE_GAME == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_SAVE_GAME, "PSC value: MENU_UNIQUE_ID_HEADER_SAVE_GAME");
static_assert((long long)::MENU_UNIQUE_ID_HOME == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME, "PSC value: MENU_UNIQUE_ID_HOME");
static_assert((long long)::MENU_UNIQUE_ID_CREWS == (long long)iosPauseReference::MENU_UNIQUE_ID_CREWS, "PSC value: MENU_UNIQUE_ID_CREWS");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_SAVEGAME == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_SAVEGAME, "PSC value: MENU_UNIQUE_ID_SETTINGS_SAVEGAME");
static_assert((long long)::MENU_UNIQUE_ID_GALLERY_ITEM == (long long)iosPauseReference::MENU_UNIQUE_ID_GALLERY_ITEM, "PSC value: MENU_UNIQUE_ID_GALLERY_ITEM");
static_assert((long long)::MENU_UNIQUE_ID_FREEMODE == (long long)iosPauseReference::MENU_UNIQUE_ID_FREEMODE, "PSC value: MENU_UNIQUE_ID_FREEMODE");
static_assert((long long)::MENU_UNIQUE_ID_MP_CHAR_1 == (long long)iosPauseReference::MENU_UNIQUE_ID_MP_CHAR_1, "PSC value: MENU_UNIQUE_ID_MP_CHAR_1");
static_assert((long long)::MENU_UNIQUE_ID_MP_CHAR_2 == (long long)iosPauseReference::MENU_UNIQUE_ID_MP_CHAR_2, "PSC value: MENU_UNIQUE_ID_MP_CHAR_2");
static_assert((long long)::MENU_UNIQUE_ID_MP_CHAR_3 == (long long)iosPauseReference::MENU_UNIQUE_ID_MP_CHAR_3, "PSC value: MENU_UNIQUE_ID_MP_CHAR_3");
static_assert((long long)::MENU_UNIQUE_ID_MP_CHAR_4 == (long long)iosPauseReference::MENU_UNIQUE_ID_MP_CHAR_4, "PSC value: MENU_UNIQUE_ID_MP_CHAR_4");
static_assert((long long)::MENU_UNIQUE_ID_MP_CHAR_5 == (long long)iosPauseReference::MENU_UNIQUE_ID_MP_CHAR_5, "PSC value: MENU_UNIQUE_ID_MP_CHAR_5");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_MULTIPLAYER == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_MULTIPLAYER, "PSC value: MENU_UNIQUE_ID_HEADER_MULTIPLAYER");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_MY_MP == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_MY_MP, "PSC value: MENU_UNIQUE_ID_HEADER_MY_MP");
static_assert((long long)::MENU_UNIQUE_ID_MISSION_CREATOR == (long long)iosPauseReference::MENU_UNIQUE_ID_MISSION_CREATOR, "PSC value: MENU_UNIQUE_ID_MISSION_CREATOR");
static_assert((long long)::MENU_UNIQUE_ID_GAME_MP == (long long)iosPauseReference::MENU_UNIQUE_ID_GAME_MP, "PSC value: MENU_UNIQUE_ID_GAME_MP");
static_assert((long long)::MENU_UNIQUE_ID_LEAVE_GAME == (long long)iosPauseReference::MENU_UNIQUE_ID_LEAVE_GAME, "PSC value: MENU_UNIQUE_ID_LEAVE_GAME");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_PRE_LOBBY == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_PRE_LOBBY, "PSC value: MENU_UNIQUE_ID_HEADER_PRE_LOBBY");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_LOBBY == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_LOBBY, "PSC value: MENU_UNIQUE_ID_HEADER_LOBBY");
static_assert((long long)::MENU_UNIQUE_ID_PARTY == (long long)iosPauseReference::MENU_UNIQUE_ID_PARTY, "PSC value: MENU_UNIQUE_ID_PARTY");
static_assert((long long)::MENU_UNIQUE_ID_LOBBY == (long long)iosPauseReference::MENU_UNIQUE_ID_LOBBY, "PSC value: MENU_UNIQUE_ID_LOBBY");
static_assert((long long)::MENU_UNIQUE_ID_PLACEHOLDER == (long long)iosPauseReference::MENU_UNIQUE_ID_PLACEHOLDER, "PSC value: MENU_UNIQUE_ID_PLACEHOLDER");
static_assert((long long)::MENU_UNIQUE_ID_STATS_CATEGORY == (long long)iosPauseReference::MENU_UNIQUE_ID_STATS_CATEGORY, "PSC value: MENU_UNIQUE_ID_STATS_CATEGORY");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_LIST, "PSC value: MENU_UNIQUE_ID_SETTINGS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_SAVE_GAME_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_SAVE_GAME_LIST, "PSC value: MENU_UNIQUE_ID_SAVE_GAME_LIST");
static_assert((long long)::MENU_UNIQUE_ID_MAP_LEGEND == (long long)iosPauseReference::MENU_UNIQUE_ID_MAP_LEGEND, "PSC value: MENU_UNIQUE_ID_MAP_LEGEND");
static_assert((long long)::MENU_UNIQUE_ID_CREWS_CATEGORY == (long long)iosPauseReference::MENU_UNIQUE_ID_CREWS_CATEGORY, "PSC value: MENU_UNIQUE_ID_CREWS_CATEGORY");
static_assert((long long)::MENU_UNIQUE_ID_CREWS_FILTER == (long long)iosPauseReference::MENU_UNIQUE_ID_CREWS_FILTER, "PSC value: MENU_UNIQUE_ID_CREWS_FILTER");
static_assert((long long)::MENU_UNIQUE_ID_CREWS_CARD == (long long)iosPauseReference::MENU_UNIQUE_ID_CREWS_CARD, "PSC value: MENU_UNIQUE_ID_CREWS_CARD");
static_assert((long long)::MENU_UNIQUE_ID_SPECTATOR == (long long)iosPauseReference::MENU_UNIQUE_ID_SPECTATOR, "PSC value: MENU_UNIQUE_ID_SPECTATOR");
static_assert((long long)::MENU_UNIQUE_ID_STATS_LISTITEM == (long long)iosPauseReference::MENU_UNIQUE_ID_STATS_LISTITEM, "PSC value: MENU_UNIQUE_ID_STATS_LISTITEM");
static_assert((long long)::MENU_UNIQUE_ID_CREW_MINE == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_MINE, "PSC value: MENU_UNIQUE_ID_CREW_MINE");
static_assert((long long)::MENU_UNIQUE_ID_CREW_ROCKSTAR == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_ROCKSTAR, "PSC value: MENU_UNIQUE_ID_CREW_ROCKSTAR");
static_assert((long long)::MENU_UNIQUE_ID_CREW_FRIENDS == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_FRIENDS, "PSC value: MENU_UNIQUE_ID_CREW_FRIENDS");
static_assert((long long)::MENU_UNIQUE_ID_CREW_INVITES == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_INVITES, "PSC value: MENU_UNIQUE_ID_CREW_INVITES");
static_assert((long long)::MENU_UNIQUE_ID_CREW_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_LIST, "PSC value: MENU_UNIQUE_ID_CREW_LIST");
static_assert((long long)::MENU_UNIQUE_ID_MISSION_CREATOR_CATEGORY == (long long)iosPauseReference::MENU_UNIQUE_ID_MISSION_CREATOR_CATEGORY, "PSC value: MENU_UNIQUE_ID_MISSION_CREATOR_CATEGORY");
static_assert((long long)::MENU_UNIQUE_ID_MISSION_CREATOR_LISTITEM == (long long)iosPauseReference::MENU_UNIQUE_ID_MISSION_CREATOR_LISTITEM, "PSC value: MENU_UNIQUE_ID_MISSION_CREATOR_LISTITEM");
static_assert((long long)::MENU_UNIQUE_ID_MISSION_CREATOR_STAT == (long long)iosPauseReference::MENU_UNIQUE_ID_MISSION_CREATOR_STAT, "PSC value: MENU_UNIQUE_ID_MISSION_CREATOR_STAT");
static_assert((long long)::MENU_UNIQUE_ID_FRIENDS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_FRIENDS_LIST, "PSC value: MENU_UNIQUE_ID_FRIENDS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_FRIENDS_OPTIONS == (long long)iosPauseReference::MENU_UNIQUE_ID_FRIENDS_OPTIONS, "PSC value: MENU_UNIQUE_ID_FRIENDS_OPTIONS");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_MP_CHARACTER_SELECT == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_MP_CHARACTER_SELECT, "PSC value: MENU_UNIQUE_ID_HEADER_MP_CHARACTER_SELECT");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_MP_CHARACTER_CREATION == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_MP_CHARACTER_CREATION, "PSC value: MENU_UNIQUE_ID_HEADER_MP_CHARACTER_CREATION");
static_assert((long long)::MENU_UNIQUE_ID_CREATION_HERITAGE == (long long)iosPauseReference::MENU_UNIQUE_ID_CREATION_HERITAGE, "PSC value: MENU_UNIQUE_ID_CREATION_HERITAGE");
static_assert((long long)::MENU_UNIQUE_ID_CREATION_LIFESTYLE == (long long)iosPauseReference::MENU_UNIQUE_ID_CREATION_LIFESTYLE, "PSC value: MENU_UNIQUE_ID_CREATION_LIFESTYLE");
static_assert((long long)::MENU_UNIQUE_ID_CREATION_YOU == (long long)iosPauseReference::MENU_UNIQUE_ID_CREATION_YOU, "PSC value: MENU_UNIQUE_ID_CREATION_YOU");
static_assert((long long)::MENU_UNIQUE_ID_PARTY_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_PARTY_LIST, "PSC value: MENU_UNIQUE_ID_PARTY_LIST");
static_assert((long long)::MENU_UNIQUE_ID_REPLAY_MISSION == (long long)iosPauseReference::MENU_UNIQUE_ID_REPLAY_MISSION, "PSC value: MENU_UNIQUE_ID_REPLAY_MISSION");
static_assert((long long)::MENU_UNIQUE_ID_REPLAY_MISSION_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_REPLAY_MISSION_LIST, "PSC value: MENU_UNIQUE_ID_REPLAY_MISSION_LIST");
static_assert((long long)::MENU_UNIQUE_ID_REPLAY_MISSION_ACTIVITY == (long long)iosPauseReference::MENU_UNIQUE_ID_REPLAY_MISSION_ACTIVITY, "PSC value: MENU_UNIQUE_ID_REPLAY_MISSION_ACTIVITY");
static_assert((long long)::MENU_UNIQUE_ID_CREW == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW, "PSC value: MENU_UNIQUE_ID_CREW");
static_assert((long long)::MENU_UNIQUE_ID_CREATION_HERITAGE_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CREATION_HERITAGE_LIST, "PSC value: MENU_UNIQUE_ID_CREATION_HERITAGE_LIST");
static_assert((long long)::MENU_UNIQUE_ID_CREATION_LIFESTYLE_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CREATION_LIFESTYLE_LIST, "PSC value: MENU_UNIQUE_ID_CREATION_LIFESTYLE_LIST");
static_assert((long long)::MENU_UNIQUE_ID_PLAYERS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_PLAYERS_LIST, "PSC value: MENU_UNIQUE_ID_PLAYERS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_PLAYERS_OPTIONS == (long long)iosPauseReference::MENU_UNIQUE_ID_PLAYERS_OPTIONS, "PSC value: MENU_UNIQUE_ID_PLAYERS_OPTIONS");
static_assert((long long)::MENU_UNIQUE_ID_PLAYERS_OPTIONS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_PLAYERS_OPTIONS_LIST, "PSC value: MENU_UNIQUE_ID_PLAYERS_OPTIONS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_PARTY_OPTIONS == (long long)iosPauseReference::MENU_UNIQUE_ID_PARTY_OPTIONS, "PSC value: MENU_UNIQUE_ID_PARTY_OPTIONS");
static_assert((long long)::MENU_UNIQUE_ID_PARTY_OPTIONS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_PARTY_OPTIONS_LIST, "PSC value: MENU_UNIQUE_ID_PARTY_OPTIONS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_CREW_OPTIONS == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_OPTIONS, "PSC value: MENU_UNIQUE_ID_CREW_OPTIONS");
static_assert((long long)::MENU_UNIQUE_ID_CREW_OPTIONS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_OPTIONS_LIST, "PSC value: MENU_UNIQUE_ID_CREW_OPTIONS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_FRIENDS_OPTIONS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_FRIENDS_OPTIONS_LIST, "PSC value: MENU_UNIQUE_ID_FRIENDS_OPTIONS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_FRIENDS_MP == (long long)iosPauseReference::MENU_UNIQUE_ID_FRIENDS_MP, "PSC value: MENU_UNIQUE_ID_FRIENDS_MP");
static_assert((long long)::MENU_UNIQUE_ID_TEAM_SELECT == (long long)iosPauseReference::MENU_UNIQUE_ID_TEAM_SELECT, "PSC value: MENU_UNIQUE_ID_TEAM_SELECT");
static_assert((long long)::MENU_UNIQUE_ID_HOME_DIALOG == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_DIALOG, "PSC value: MENU_UNIQUE_ID_HOME_DIALOG");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_EMPTY == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_EMPTY, "PSC value: MENU_UNIQUE_ID_HEADER_EMPTY");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_FEED == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_FEED, "PSC value: MENU_UNIQUE_ID_SETTINGS_FEED");
static_assert((long long)::MENU_UNIQUE_ID_GALLERY_OPTIONS == (long long)iosPauseReference::MENU_UNIQUE_ID_GALLERY_OPTIONS, "PSC value: MENU_UNIQUE_ID_GALLERY_OPTIONS");
static_assert((long long)::MENU_UNIQUE_ID_GALLERY_OPTIONS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_GALLERY_OPTIONS_LIST, "PSC value: MENU_UNIQUE_ID_GALLERY_OPTIONS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_BRIGHTNESS_CALIBRATION == (long long)iosPauseReference::MENU_UNIQUE_ID_BRIGHTNESS_CALIBRATION, "PSC value: MENU_UNIQUE_ID_BRIGHTNESS_CALIBRATION");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_TEXT_SELECTION == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_TEXT_SELECTION, "PSC value: MENU_UNIQUE_ID_HEADER_TEXT_SELECTION");
static_assert((long long)::MENU_UNIQUE_ID_LOBBY_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_LOBBY_LIST, "PSC value: MENU_UNIQUE_ID_LOBBY_LIST");
static_assert((long long)::MENU_UNIQUE_ID_LOBBY_LIST_ITEM == (long long)iosPauseReference::MENU_UNIQUE_ID_LOBBY_LIST_ITEM, "PSC value: MENU_UNIQUE_ID_LOBBY_LIST_ITEM");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_LOBBY == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_LOBBY, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_LOBBY");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_JOINED_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_JOINED_PLAYERS, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_JOINED_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_PLAYERS, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_INVITE_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_FRIENDS == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_FRIENDS, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_INVITE_FRIENDS");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_CREWS == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_CREWS, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_INVITE_CREWS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_JOINED_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_JOINED_PLAYERS, "PSC value: MENU_UNIQUE_ID_CORONA_JOINED_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE_PLAYERS, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE_FRIENDS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE_FRIENDS, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE_FRIENDS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE_CREWS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE_CREWS, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE_CREWS");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_FACEBOOK == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_FACEBOOK, "PSC value: MENU_UNIQUE_ID_SETTINGS_FACEBOOK");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_JOINING_SCREEN == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_JOINING_SCREEN, "PSC value: MENU_UNIQUE_ID_HEADER_JOINING_SCREEN");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_SETTINGS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_SETTINGS_LIST, "PSC value: MENU_UNIQUE_ID_CORONA_SETTINGS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_DETAILS_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_DETAILS_LIST, "PSC value: MENU_UNIQUE_ID_CORONA_DETAILS_LIST");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE_LIST, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE_LIST");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_JOINED_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_JOINED_LIST, "PSC value: MENU_UNIQUE_ID_CORONA_JOINED_LIST");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_MATCHED_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_MATCHED_PLAYERS, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_INVITE_MATCHED_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_LAST_JOB_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_CORONA_INVITE_LAST_JOB_PLAYERS, "PSC value: MENU_UNIQUE_ID_HEADER_CORONA_INVITE_LAST_JOB_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE_MATCHED_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE_MATCHED_PLAYERS, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE_MATCHED_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_CORONA_INVITE_LAST_JOB_PLAYERS == (long long)iosPauseReference::MENU_UNIQUE_ID_CORONA_INVITE_LAST_JOB_PLAYERS, "PSC value: MENU_UNIQUE_ID_CORONA_INVITE_LAST_JOB_PLAYERS");
static_assert((long long)::MENU_UNIQUE_ID_CREW_LEADERBOARDS == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_LEADERBOARDS, "PSC value: MENU_UNIQUE_ID_CREW_LEADERBOARDS");
static_assert((long long)::MENU_UNIQUE_ID_HOME_OPEN_JOBS == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_OPEN_JOBS, "PSC value: MENU_UNIQUE_ID_HOME_OPEN_JOBS");
static_assert((long long)::MENU_UNIQUE_ID_CREW_REQUEST == (long long)iosPauseReference::MENU_UNIQUE_ID_CREW_REQUEST, "PSC value: MENU_UNIQUE_ID_CREW_REQUEST");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_RACE == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_RACE, "PSC value: MENU_UNIQUE_ID_HEADER_RACE");
static_assert((long long)::MENU_UNIQUE_ID_RACE_INFO == (long long)iosPauseReference::MENU_UNIQUE_ID_RACE_INFO, "PSC value: MENU_UNIQUE_ID_RACE_INFO");
static_assert((long long)::MENU_UNIQUE_ID_RACE_INFOLIST == (long long)iosPauseReference::MENU_UNIQUE_ID_RACE_INFOLIST, "PSC value: MENU_UNIQUE_ID_RACE_INFOLIST");
static_assert((long long)::MENU_UNIQUE_ID_RACE_LOBBYLIST == (long long)iosPauseReference::MENU_UNIQUE_ID_RACE_LOBBYLIST, "PSC value: MENU_UNIQUE_ID_RACE_LOBBYLIST");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_BETTING == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_BETTING, "PSC value: MENU_UNIQUE_ID_HEADER_BETTING");
static_assert((long long)::MENU_UNIQUE_ID_BETTING == (long long)iosPauseReference::MENU_UNIQUE_ID_BETTING, "PSC value: MENU_UNIQUE_ID_BETTING");
static_assert((long long)::MENU_UNIQUE_ID_BETTING_INFOLIST == (long long)iosPauseReference::MENU_UNIQUE_ID_BETTING_INFOLIST, "PSC value: MENU_UNIQUE_ID_BETTING_INFOLIST");
static_assert((long long)::MENU_UNIQUE_ID_BETTING_LOBBYLIST == (long long)iosPauseReference::MENU_UNIQUE_ID_BETTING_LOBBYLIST, "PSC value: MENU_UNIQUE_ID_BETTING_LOBBYLIST");
static_assert((long long)::MENU_UNIQUE_ID_INCEPT_TRIGGER == (long long)iosPauseReference::MENU_UNIQUE_ID_INCEPT_TRIGGER, "PSC value: MENU_UNIQUE_ID_INCEPT_TRIGGER");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_SIXAXIS == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_SIXAXIS, "PSC value: MENU_UNIQUE_ID_SETTINGS_SIXAXIS");
static_assert((long long)::MENU_UNIQUE_ID_REPLAY_RANDOM == (long long)iosPauseReference::MENU_UNIQUE_ID_REPLAY_RANDOM, "PSC value: MENU_UNIQUE_ID_REPLAY_RANDOM");
static_assert((long long)::MENU_UNIQUE_ID_CUTSCENE_EMPTY == (long long)iosPauseReference::MENU_UNIQUE_ID_CUTSCENE_EMPTY, "PSC value: MENU_UNIQUE_ID_CUTSCENE_EMPTY");
static_assert((long long)::MENU_UNIQUE_ID_HOME_NEWSWIRE == (long long)iosPauseReference::MENU_UNIQUE_ID_HOME_NEWSWIRE, "PSC value: MENU_UNIQUE_ID_HOME_NEWSWIRE");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_CAMERA == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_CAMERA, "PSC value: MENU_UNIQUE_ID_SETTINGS_CAMERA");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_GRAPHICS == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_GRAPHICS, "PSC value: MENU_UNIQUE_ID_SETTINGS_GRAPHICS");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_ADVANCED_GFX == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_ADVANCED_GFX, "PSC value: MENU_UNIQUE_ID_SETTINGS_ADVANCED_GFX");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_VOICE_CHAT == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_VOICE_CHAT, "PSC value: MENU_UNIQUE_ID_SETTINGS_VOICE_CHAT");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_MISC_CONTROLS == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_MISC_CONTROLS, "PSC value: MENU_UNIQUE_ID_SETTINGS_MISC_CONTROLS");
static_assert((long long)::MENU_UNIQUE_ID_HELP == (long long)iosPauseReference::MENU_UNIQUE_ID_HELP, "PSC value: MENU_UNIQUE_ID_HELP");
static_assert((long long)::MENU_UNIQUE_ID_MOVIE_EDITOR == (long long)iosPauseReference::MENU_UNIQUE_ID_MOVIE_EDITOR, "PSC value: MENU_UNIQUE_ID_MOVIE_EDITOR");
static_assert((long long)::MENU_UNIQUE_ID_EXIT_TO_WINDOWS == (long long)iosPauseReference::MENU_UNIQUE_ID_EXIT_TO_WINDOWS, "PSC value: MENU_UNIQUE_ID_EXIT_TO_WINDOWS");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_LANDING_PAGE == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_LANDING_PAGE, "PSC value: MENU_UNIQUE_ID_HEADER_LANDING_PAGE");
static_assert((long long)::MENU_UNIQUE_ID_SHOW_ACCOUNT_PICKER == (long long)iosPauseReference::MENU_UNIQUE_ID_SHOW_ACCOUNT_PICKER, "PSC value: MENU_UNIQUE_ID_SHOW_ACCOUNT_PICKER");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_REPLAY == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_REPLAY, "PSC value: MENU_UNIQUE_ID_SETTINGS_REPLAY");
static_assert((long long)::MENU_UNIQUE_ID_REPLAY_EDITOR == (long long)iosPauseReference::MENU_UNIQUE_ID_REPLAY_EDITOR, "PSC value: MENU_UNIQUE_ID_REPLAY_EDITOR");
static_assert((long long)::MENU_UNIQUE_ID_KEYMAP == (long long)iosPauseReference::MENU_UNIQUE_ID_KEYMAP, "PSC value: MENU_UNIQUE_ID_KEYMAP");
static_assert((long long)::MENU_UNIQUE_ID_KEYMAP_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_KEYMAP_LIST, "PSC value: MENU_UNIQUE_ID_KEYMAP_LIST");
static_assert((long long)::MENU_UNIQUE_ID_KEYMAP_LISTITEM == (long long)iosPauseReference::MENU_UNIQUE_ID_KEYMAP_LISTITEM, "PSC value: MENU_UNIQUE_ID_KEYMAP_LISTITEM");
static_assert((long long)::MENU_UNIQUE_ID_SETTINGS_FIRST_PERSON == (long long)iosPauseReference::MENU_UNIQUE_ID_SETTINGS_FIRST_PERSON, "PSC value: MENU_UNIQUE_ID_SETTINGS_FIRST_PERSON");
static_assert((long long)::MENU_UNIQUE_ID_HEADER_LANDING_KEYMAPPING == (long long)iosPauseReference::MENU_UNIQUE_ID_HEADER_LANDING_KEYMAPPING, "PSC value: MENU_UNIQUE_ID_HEADER_LANDING_KEYMAPPING");
static_assert((long long)::MENU_UNIQUE_ID_PROCESS_SAVEGAME == (long long)iosPauseReference::MENU_UNIQUE_ID_PROCESS_SAVEGAME, "PSC value: MENU_UNIQUE_ID_PROCESS_SAVEGAME");
static_assert((long long)::MENU_UNIQUE_ID_PROCESS_SAVEGAME_LIST == (long long)iosPauseReference::MENU_UNIQUE_ID_PROCESS_SAVEGAME_LIST, "PSC value: MENU_UNIQUE_ID_PROCESS_SAVEGAME_LIST");
static_assert((long long)::MENU_UNIQUE_ID_IMPORT_SAVEGAME == (long long)iosPauseReference::MENU_UNIQUE_ID_IMPORT_SAVEGAME, "PSC value: MENU_UNIQUE_ID_IMPORT_SAVEGAME");
static_assert((long long)::MENU_UNIQUE_ID_CREDITS == (long long)iosPauseReference::MENU_UNIQUE_ID_CREDITS, "PSC value: MENU_UNIQUE_ID_CREDITS");
static_assert((long long)::MENU_UNIQUE_ID_LEGAL == (long long)iosPauseReference::MENU_UNIQUE_ID_LEGAL, "PSC value: MENU_UNIQUE_ID_LEGAL");
static_assert((long long)::MENU_UNIQUE_ID_CREDITS_LEGAL == (long long)iosPauseReference::MENU_UNIQUE_ID_CREDITS_LEGAL, "PSC value: MENU_UNIQUE_ID_CREDITS_LEGAL");
static_assert(eInstructionButtons_NUM_ENUMS == 54, "PSC enum count");
static_assert((long long)::ARROW_UP == (long long)iosPauseReference::ARROW_UP, "PSC value: ARROW_UP");
static_assert((long long)::ARROW_DOWN == (long long)iosPauseReference::ARROW_DOWN, "PSC value: ARROW_DOWN");
static_assert((long long)::ARROW_LEFT == (long long)iosPauseReference::ARROW_LEFT, "PSC value: ARROW_LEFT");
static_assert((long long)::ARROW_RIGHT == (long long)iosPauseReference::ARROW_RIGHT, "PSC value: ARROW_RIGHT");
static_assert((long long)::DPAD_UP == (long long)iosPauseReference::DPAD_UP, "PSC value: DPAD_UP");
static_assert((long long)::DPAD_DOWN == (long long)iosPauseReference::DPAD_DOWN, "PSC value: DPAD_DOWN");
static_assert((long long)::DPAD_LEFT == (long long)iosPauseReference::DPAD_LEFT, "PSC value: DPAD_LEFT");
static_assert((long long)::DPAD_RIGHT == (long long)iosPauseReference::DPAD_RIGHT, "PSC value: DPAD_RIGHT");
static_assert((long long)::DPAD_NONE == (long long)iosPauseReference::DPAD_NONE, "PSC value: DPAD_NONE");
static_assert((long long)::DPAD_ALL == (long long)iosPauseReference::DPAD_ALL, "PSC value: DPAD_ALL");
static_assert((long long)::DPAD_UPDOWN == (long long)iosPauseReference::DPAD_UPDOWN, "PSC value: DPAD_UPDOWN");
static_assert((long long)::DPAD_LEFTRIGHT == (long long)iosPauseReference::DPAD_LEFTRIGHT, "PSC value: DPAD_LEFTRIGHT");
static_assert((long long)::LSTICK_UP == (long long)iosPauseReference::LSTICK_UP, "PSC value: LSTICK_UP");
static_assert((long long)::LSTICK_DOWN == (long long)iosPauseReference::LSTICK_DOWN, "PSC value: LSTICK_DOWN");
static_assert((long long)::LSTICK_LEFT == (long long)iosPauseReference::LSTICK_LEFT, "PSC value: LSTICK_LEFT");
static_assert((long long)::LSTICK_RIGHT == (long long)iosPauseReference::LSTICK_RIGHT, "PSC value: LSTICK_RIGHT");
static_assert((long long)::LSTICK_CLICK == (long long)iosPauseReference::LSTICK_CLICK, "PSC value: LSTICK_CLICK");
static_assert((long long)::LSTICK_ALL == (long long)iosPauseReference::LSTICK_ALL, "PSC value: LSTICK_ALL");
static_assert((long long)::LSTICK_UPDOWN == (long long)iosPauseReference::LSTICK_UPDOWN, "PSC value: LSTICK_UPDOWN");
static_assert((long long)::LSTICK_LEFTRIGHT == (long long)iosPauseReference::LSTICK_LEFTRIGHT, "PSC value: LSTICK_LEFTRIGHT");
static_assert((long long)::LSTICK_ROTATE == (long long)iosPauseReference::LSTICK_ROTATE, "PSC value: LSTICK_ROTATE");
static_assert((long long)::RSTICK_UP == (long long)iosPauseReference::RSTICK_UP, "PSC value: RSTICK_UP");
static_assert((long long)::RSTICK_DOWN == (long long)iosPauseReference::RSTICK_DOWN, "PSC value: RSTICK_DOWN");
static_assert((long long)::RSTICK_LEFT == (long long)iosPauseReference::RSTICK_LEFT, "PSC value: RSTICK_LEFT");
static_assert((long long)::RSTICK_RIGHT == (long long)iosPauseReference::RSTICK_RIGHT, "PSC value: RSTICK_RIGHT");
static_assert((long long)::RSTICK_CLICK == (long long)iosPauseReference::RSTICK_CLICK, "PSC value: RSTICK_CLICK");
static_assert((long long)::RSTICK_ALL == (long long)iosPauseReference::RSTICK_ALL, "PSC value: RSTICK_ALL");
static_assert((long long)::RSTICK_UPDOWN == (long long)iosPauseReference::RSTICK_UPDOWN, "PSC value: RSTICK_UPDOWN");
static_assert((long long)::RSTICK_LEFTRIGHT == (long long)iosPauseReference::RSTICK_LEFTRIGHT, "PSC value: RSTICK_LEFTRIGHT");
static_assert((long long)::RSTICK_ROTATE == (long long)iosPauseReference::RSTICK_ROTATE, "PSC value: RSTICK_ROTATE");
static_assert((long long)::BUTTON_A == (long long)iosPauseReference::BUTTON_A, "PSC value: BUTTON_A");
static_assert((long long)::BUTTON_B == (long long)iosPauseReference::BUTTON_B, "PSC value: BUTTON_B");
static_assert((long long)::BUTTON_X == (long long)iosPauseReference::BUTTON_X, "PSC value: BUTTON_X");
static_assert((long long)::BUTTON_Y == (long long)iosPauseReference::BUTTON_Y, "PSC value: BUTTON_Y");
static_assert((long long)::BUTTON_L1 == (long long)iosPauseReference::BUTTON_L1, "PSC value: BUTTON_L1");
static_assert((long long)::BUTTON_L2 == (long long)iosPauseReference::BUTTON_L2, "PSC value: BUTTON_L2");
static_assert((long long)::BUTTON_R1 == (long long)iosPauseReference::BUTTON_R1, "PSC value: BUTTON_R1");
static_assert((long long)::BUTTON_R2 == (long long)iosPauseReference::BUTTON_R2, "PSC value: BUTTON_R2");
static_assert((long long)::BUTTON_START == (long long)iosPauseReference::BUTTON_START, "PSC value: BUTTON_START");
static_assert((long long)::BUTTON_BACK == (long long)iosPauseReference::BUTTON_BACK, "PSC value: BUTTON_BACK");
static_assert((long long)::SIXAXIS_YAW == (long long)iosPauseReference::SIXAXIS_YAW, "PSC value: SIXAXIS_YAW");
static_assert((long long)::SIXAXIS_PITCH == (long long)iosPauseReference::SIXAXIS_PITCH, "PSC value: SIXAXIS_PITCH");
static_assert((long long)::SIXAXIS_PITCH_UP == (long long)iosPauseReference::SIXAXIS_PITCH_UP, "PSC value: SIXAXIS_PITCH_UP");
static_assert((long long)::SIXAXIS_ROLL == (long long)iosPauseReference::SIXAXIS_ROLL, "PSC value: SIXAXIS_ROLL");
static_assert((long long)::ICON_SPINNER == (long long)iosPauseReference::ICON_SPINNER, "PSC value: ICON_SPINNER");
static_assert((long long)::ARROW_UPDOWN == (long long)iosPauseReference::ARROW_UPDOWN, "PSC value: ARROW_UPDOWN");
static_assert((long long)::ARROW_LEFTRIGHT == (long long)iosPauseReference::ARROW_LEFTRIGHT, "PSC value: ARROW_LEFTRIGHT");
static_assert((long long)::ARROW_ALL == (long long)iosPauseReference::ARROW_ALL, "PSC value: ARROW_ALL");
static_assert((long long)::BUTTONS_TRIGGERS == (long long)iosPauseReference::BUTTONS_TRIGGERS, "PSC value: BUTTONS_TRIGGERS");
static_assert((long long)::BUTTONS_BUMPERS == (long long)iosPauseReference::BUTTONS_BUMPERS, "PSC value: BUTTONS_BUMPERS");
static_assert((long long)::STICK_CLICKS == (long long)iosPauseReference::STICK_CLICKS, "PSC value: STICK_CLICKS");
static_assert((long long)::NOTHING == (long long)iosPauseReference::NOTHING, "PSC value: NOTHING");
static_assert((long long)::MAX_INSTRUCTIONAL_BUTTONS == (long long)iosPauseReference::MAX_INSTRUCTIONAL_BUTTONS, "PSC value: MAX_INSTRUCTIONAL_BUTTONS");
static_assert((long long)::ICON_INVALID == (long long)iosPauseReference::ICON_INVALID, "PSC value: ICON_INVALID");
static_assert(std::is_same<decltype(CMenuDisplayOption::cTextId),::rage::atHashWithStringDev>::value, "PSC member: CMenuDisplayOption.cTextId");
static_assert(std::is_same<decltype(CMenuDisplayValue::MenuOption),eMenuOption>::value, "PSC member: CMenuDisplayValue.MenuOption");
static_assert(std::is_same<decltype(CMenuDisplayValue::MenuDisplayOptions),::rage::atArray<CMenuDisplayOption,0,::rage::u16>>::value, "PSC member: CMenuDisplayValue.MenuDisplayOptions");
static_assert(std::is_base_of<::rage::datBase,SGeneralMovieData>::value, "PSC base: SGeneralMovieData");
static_assert(std::is_same<decltype(SGeneralMovieData::vPos),::rage::Vector2>::value, "PSC member: SGeneralMovieData.vPos");
static_assert(std::is_same<decltype(SGeneralMovieData::vSize),::rage::Vector2>::value, "PSC member: SGeneralMovieData.vSize");
static_assert(std::is_base_of<SGeneralMovieData,SGeneralPauseDataConfig>::value, "PSC base: SGeneralPauseDataConfig");
static_assert(std::is_same<decltype(SGeneralPauseDataConfig::RequiredMovies),::rage::atFixedArray<::rage::atString,4>>::value, "PSC member: SGeneralPauseDataConfig.RequiredMovies");
static_assert(std::is_same<decltype(SGeneralPauseDataConfig::bRequiresMovieView),bool>::value, "PSC member: SGeneralPauseDataConfig.bRequiresMovieView");
static_assert(std::is_same<decltype(SGeneralPauseDataConfig::bDependsOnSharedComponents),bool>::value, "PSC member: SGeneralPauseDataConfig.bDependsOnSharedComponents");
static_assert(std::is_same<decltype(SGeneralPauseDataConfig::LoadingOrder),::rage::u8>::value, "PSC member: SGeneralPauseDataConfig.LoadingOrder");
static_assert(std::is_same<decltype(SGeneralPauseDataConfig::HAlign),char[2]>::value, "PSC member: SGeneralPauseDataConfig.HAlign");
static_assert(std::is_same<decltype(CGeneralPauseData::MovieSettings),::rage::atBinaryMap<SGeneralPauseDataConfig,::rage::atHashWithStringBank>>::value, "PSC member: CGeneralPauseData.MovieSettings");
static_assert(std::is_base_of<SGeneralMovieData,CSpinnerData>::value, "PSC base: CSpinnerData");
static_assert(std::is_same<decltype(CSpinnerData::Offsets),::rage::atArray<::rage::Vector2,0,::rage::u16>>::value, "PSC member: CSpinnerData.Offsets");
static_assert(std::is_base_of<SGeneralMovieData,CArrowData>::value, "PSC base: CArrowData");
static_assert(std::is_same<decltype(CArrowData::vPosRight),::rage::Vector2>::value, "PSC member: CArrowData.vPosRight");
static_assert(std::is_same<decltype(CArrowData::shownAlpha),::rage::u8>::value, "PSC member: CArrowData.shownAlpha");
static_assert(std::is_same<decltype(CArrowData::hiddenAlpha),::rage::u8>::value, "PSC member: CArrowData.hiddenAlpha");
static_assert(std::is_base_of<SGeneralMovieData,CGradient>::value, "PSC base: CGradient");
static_assert(std::is_same<decltype(CGradient::minAlpha),::rage::u8>::value, "PSC member: CGradient.minAlpha");
static_assert(std::is_same<decltype(CGradient::maxAlpha),::rage::u8>::value, "PSC member: CGradient.maxAlpha");
static_assert(std::is_same<decltype(CGradient::flatAlpha),::rage::u8>::value, "PSC member: CGradient.flatAlpha");
static_assert(std::is_same<decltype(CPauseMenuPersistentData::Spinner),CSpinnerData>::value, "PSC member: CPauseMenuPersistentData.Spinner");
static_assert(std::is_same<decltype(CPauseMenuPersistentData::Gradient),CGradient>::value, "PSC member: CPauseMenuPersistentData.Gradient");
static_assert(std::is_same<decltype(CPauseMenuPersistentData::Arrows),CArrowData>::value, "PSC member: CPauseMenuPersistentData.Arrows");
static_assert(std::is_same<decltype(CPauseMenuDynamicData::type),::rage::atHashWithStringDev>::value, "PSC member: CPauseMenuDynamicData.type");
static_assert(std::is_same<decltype(CPauseMenuDynamicData::params),::rage::atBinaryMap<::rage::atString,::rage::atHashWithStringDev>>::value, "PSC member: CPauseMenuDynamicData.params");
