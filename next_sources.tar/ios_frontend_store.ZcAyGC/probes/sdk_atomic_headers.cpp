#include "GAtomic.h"
#include "GFunctions.h"
static_assert(sizeof(GAtomicOpsRaw<4>::T)==4, "atomic type width 4");
static_assert(sizeof(GAtomicOpsRaw<8>::T)==8, "atomic type width 8");
// These declarations do not verify atomic memory ordering or runtime semantics.
