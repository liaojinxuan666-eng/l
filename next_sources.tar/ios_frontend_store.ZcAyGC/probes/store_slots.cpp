#include "fwscene/stores/storeslotmanager.h"
