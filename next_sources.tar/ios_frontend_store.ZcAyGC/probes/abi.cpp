#include "GTypes.h"
#if !defined(GFC_OS_IPHONE) || !defined(GFC_CPU_ARM64) || !defined(GFC_64BIT_POINTERS)
#error "Previous Scaleform ARM64 ABI patch is required"
#endif
#if defined(GFC_CPU_ARM) || defined(GFC_CPU_X86) || defined(GFC_CPU_X86_64) || defined(GFC_CPU_OTHER)
#error "Wrong Scaleform CPU selection"
#endif
static_assert(sizeof(UInt32)==4 && sizeof(SInt32)==4, "32-bit widths");
static_assert(sizeof(UInt64)==8 && sizeof(SInt64)==8, "64-bit widths");
static_assert(sizeof(UPInt)==8 && sizeof(SPInt)==8, "pointer integer widths");
inline int fp_overload(UInt32) {return 32;}
inline int fp_overload(UInt64) {return 64;}
