#include <TargetConditionals.h>
#if !TARGET_OS_IOS || TARGET_OS_SIMULATOR
#error "Expected an iOS device SDK"
#endif
#if !defined(__arm64__) && !defined(__aarch64__)
#error "Expected an ARM64 target"
#endif
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <UIKit/UIKit.h>
id<MTLDevice> iosGfxSDKDevice;
CAMetalLayer* iosGfxSDKLayer;
UIView* iosGfxSDKView;
