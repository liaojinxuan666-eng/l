#include "vectormath/legacyconvert.h"
#include "math/vecmath.h"
rage::Vec::Vector_4V_Out iosAudioPacking(rage::Vec::Vector_4V_In a, rage::Vec::Vector_4V_In b) {
    const auto packed = rage::Vec::V4PackSignedIntToSignedShort(a,b);
    return rage::Vec::V4AddInt(rage::Vec::V4UnpackLowSignedShort(packed), rage::Vec::V4UnpackHighSignedShort(packed));
}
rage::Vec3V_Out iosLegacyVector(const rage::Vector3& a) { return VECTOR3_TO_VEC3V(a); }
rage::Vec2V_Out iosSinCos(rage::ScalarV_In x) { return rage::SinCosApprox(x); }
