#include <type_traits>
#ifndef INC_GAME_CONFIG_H_
#error original game_config.h not loaded
#endif
#ifndef INC_BASETYPES_H_
#error original game/basetypes.h not loaded
#endif
#ifndef INC_OPTIMISATIONS_H_
#error original optimisations.h not loaded
#endif
#if !RSG_IOS || RSG_PC || RSG_ORBIS || RSG_DURANGO || !RSG_CPU_ARM64
#error iOS platform changed
#endif
#ifdef USING_RAGE
#error ad-hoc USING_RAGE switch should not be required
#endif
static_assert(std::is_same<u32,rage::u32>::value,"original namespace import");
static_assert(std::is_same<s32,rage::s32>::value,"original namespace import");
static_assert(std::is_same<BankInt32,const int>::value,"original non-bank type");
static_assert(sizeof(u32)==4 && sizeof(u64)==8,"existing scalar sizes");
static_assert(MAX_UINT8==0xff && PHYSIC_REQUEST_LIST_SIZE>0,"original game constants");
u32 iosGameCommonHeadersProbe(u32 v) { return v; }
