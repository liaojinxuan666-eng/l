#include <TargetConditionals.h>
#if !defined(__APPLE__) || !(defined(__aarch64__) || defined(__arm64__))
#error "Real Apple ARM64 target required"
#endif
#if !TARGET_OS_IPHONE || TARGET_OS_SIMULATOR
#error "iOS device target required"
#endif
#if !RSG_IOS || !RSG_CPU_ARM64 || RSG_CPU_INTEL || RSG_PC || RSG_ORBIS || RSG_DURANGO || __BE
#error "Unexpected RAGE platform selection"
#endif
static_assert(sizeof(void*)==8, "64-bit pointer ABI required");
