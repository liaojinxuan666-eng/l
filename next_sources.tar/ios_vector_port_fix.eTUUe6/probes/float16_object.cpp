#include "math/float16.h"
static_assert(sizeof(rage::Float16) == 2, "legacy Float16 storage width");
// Real original-engine header object check; this is not a linked runtime test.
rage::ScalarV_Out iosFloat16Read(const rage::Float16& value) {
    return value.GetFloat32_FromFloat16_ScalarV();
}
