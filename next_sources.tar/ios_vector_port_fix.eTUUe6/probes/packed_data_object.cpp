#include "math/float16.h"
void iosPackedColorProbe(rage::Color32* color, rage::Vec::Vector_4V_In v) {
    rage::Vec::V4PackARGBColor32(color, v);
    (void)rage::Vec::V4UnpackARGBColor32(color);
}
rage::Vec4V_Out iosFixedPointProbe(rage::Vec4V_In p, rage::Vec4V_In v) {
    return rage::FixedPoint3_13Vec4UnpackFromXY(rage::FixedPoint3_13Vec4PackIntoXY(p, v));
}
