#include "audio/streamslot.h"
#include <type_traits>
static_assert(g_NumStreamSlots==5 && g_NumVirtualStreamSlots==2 && g_NullStreamSlot==g_NumStreamSlots, "original slot counts");
static_assert(std::is_same<streamStopCallbackPtr,bool(*)(rage::u32)>::value,"original callback type");
static_assert(std::is_same<decltype(&audStreamSlot::GetWaveSlot),rage::audWaveSlot*(audStreamSlot::*)()>::value,"original wave pointer type");
static_assert(std::is_same<decltype(&audStreamSlot::SetPriority),void(audStreamSlot::*)(rage::u32)>::value,"original priority signature");
audStreamClientSettings iosStreamDefaultSettings() { return audStreamClientSettings(); }
void iosStreamPriorityReference(audStreamSlot& slot, rage::u32 priority) { slot.SetPriority(priority); }
