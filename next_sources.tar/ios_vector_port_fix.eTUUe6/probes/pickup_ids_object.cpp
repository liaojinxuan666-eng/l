#include "pickups/Data/PickupIds.h"
#include <type_traits>
static_assert(std::is_same<decltype(PICKUP_HEALTH_STANDARD), const rage::atHashWithStringNotFinal>::value, "original pickup hash type");
const rage::atHashWithStringNotFinal& iosPickupReference() { return PICKUP_HEALTH_STANDARD; }
