#include "rline/rlsessioninfo.h"
#include <type_traits>
#if !RSG_IOS
#error "iOS-only session unavailability check"
#endif
using Session = rage::rlSessionInfo;
static_assert(Session::TO_STRING_BUFFER_SIZE == sizeof(""), "failure terminator only, not a wire capacity");
static_assert(std::is_empty<Session>::value, "no invented platform session data");
static_assert(std::is_same<decltype(&Session::FromString), bool(Session::*)(const char*, unsigned*, bool)>::value, "original import signature");
static_assert(std::is_same<decltype(&Session::Export), bool(Session::*)(void*, unsigned, unsigned*) const>::value, "original export signature");
const char* iosSessionToStringReference(const Session& s, char* p, unsigned n, unsigned* used) {
    return s.ToString(p, n, used);
}
bool iosSessionFromStringReference(Session& s, const char* p, unsigned* used) {
    return s.FromString(p, used, true);
}
