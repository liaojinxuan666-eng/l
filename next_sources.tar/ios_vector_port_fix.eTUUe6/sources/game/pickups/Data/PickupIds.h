
#ifndef PICKUP_IDS_H
#define PICKUP_IDS_H

#define LASSO_WEAPON_EXISTS 0

// Rage headers
#include "atl/hashstring.h"

// health types
extern const ::rage::atHashWithStringNotFinal PICKUP_HEALTH_STANDARD;
extern const ::rage::atHashWithStringNotFinal PICKUP_HEALTH_SNACK;
extern const ::rage::atHashWithStringNotFinal PICKUP_ARMOUR_STANDARD;

// money types
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_VARIABLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_CASE;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_WALLET;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_PURSE;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_DEP_BAG;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_MED_BAG;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_PAPER_BAG;
extern const ::rage::atHashWithStringNotFinal PICKUP_MONEY_SECURITY_CASE;
extern const ::rage::atHashWithStringNotFinal PICKUP_GANG_ATTACK_MONEY;

// weapon types
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_PISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_COMBATPISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_PISTOL50;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_APPISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_MICROSMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_SMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_ASSAULTSMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_ASSAULTRIFLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_CARBINERIFLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_HEAVYRIFLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_ADVANCEDRIFLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_MG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_COMBATMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_ASSAULTMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_PUMPSHOTGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_SAWNOFFSHOTGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_BULLPUPSHOTGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_ASSAULTSHOTGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_SNIPERRIFLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_ASSAULTSNIPER;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_HEAVYSNIPER;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_GRENADELAUNCHER;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_RPG;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_MINIGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_GRENADE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_SMOKEGRENADE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_STICKYBOMB;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_MOLOTOV;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_STUNGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_RUBBERGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_PROGRAMMABLEAR;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_FIREEXTINGUISHER;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_PETROLCAN;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_LOUDHAILER;
#if LASSO_WEAPON_EXISTS
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_LASSO;
#endif
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_KNIFE;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_NIGHTSTICK;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_HAMMER;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_CROWBAR;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_BAT;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_GOLFCLUB;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_HARPOON;
extern const ::rage::atHashWithStringNotFinal PICKUP_WEAPON_FERTILIZERCAN;


// ammo types
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_BULLET_MP;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_MISSILE_MP;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_FIREWORK_MP;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_GRENADELAUNCHER_MP;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_PISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_SMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_RIFLE;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_MG;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_SHOTGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_SNIPER;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_GRENADELAUNCHER;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_RPG;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_MINIGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_RUBBERGUN;
extern const ::rage::atHashWithStringNotFinal PICKUP_AMMO_HARPOON;

// vehicle pickups
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_HEALTH_STANDARD;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_ARMOUR_STANDARD;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_PISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_COMBATPISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_PISTOL50;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_APPISTOL;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_MICROSMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_SMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_SAWNOFF;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_ASSAULTSMG;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_GRENADE;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_SMOKEGRENADE;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_STICKYBOMB;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_WEAPON_MOLOTOV;
extern const ::rage::atHashWithStringNotFinal PICKUP_VEHICLE_CUSTOM_SCRIPT;

// portable pickups
extern const ::rage::atHashWithStringNotFinal PICKUP_PORTABLE_PACKAGE;
extern const ::rage::atHashWithStringNotFinal PICKUP_PORTABLE_CRATE_UNFIXED;
extern const ::rage::atHashWithStringNotFinal PICKUP_PORTABLE_CRATE_UNFIXED_INAIRVEHICLE_WITH_PASSENGERS;

// misc types
extern const ::rage::atHashWithStringNotFinal PICKUP_CUSTOM_SCRIPT;
extern const ::rage::atHashWithStringNotFinal PICKUP_HANDCUFF_KEY;
extern const ::rage::atHashWithStringNotFinal PICKUP_CAMERA;
extern const ::rage::atHashWithStringNotFinal PICKUP_SUBMARINE;
extern const ::rage::atHashWithStringNotFinal PICKUP_PARACHUTE;
extern const ::rage::atHashWithStringNotFinal PICKUP_JETPACK;

enum PickupRewardType
{
	PICKUP_REWARD_TYPE_NONE = 0,

	PICKUP_REWARD_TYPE_AMMO					= (1<<0),
	PICKUP_REWARD_TYPE_BULLET_MP			= (1<<1),
	PICKUP_REWARD_TYPE_MISSILE_MP			= (1<<2),
	PICKUP_REWARD_TYPE_GRENADE_LAUNCHER_MP	= (1<<3),
	PICKUP_REWARD_TYPE_ARMOUR				= (1<<4),
	PICKUP_REWARD_TYPE_HEALTH				= (1<<5),
	PICKUP_REWARD_TYPE_MONEY				= (1<<6),
	PICKUP_REWARD_TYPE_WEAPON				= (1<<7),
	PICKUP_REWARD_TYPE_STAT					= (1<<8),
	PICKUP_REWARD_TYPE_VEHICLE_FIX			= (1<<9),
	PICKUP_REWARD_TYPE_FIREWORK_MP			= (1<<10),

	// *** IF ALTERING THIS ENUM, REMEMBER TO ADJUST THE CORRESPONDING EMUM IN commands_object.sch ***

	PICKUP_REWARD_TYPE_ALL					= (1<<11) - 1
};

// old pickup enums, to be removed once the scripts are using the new hashes
enum OldPickupTypes
{
	PICKUP_HEALTH_STANDARD_TYPE,
	PICKUP_ARMOUR_STANDARD_TYPE,
	PICKUP_MONEY_VARIABLE_TYPE,
	PICKUP_MONEY_CASE_TYPE,
	PICKUP_MONEY_WALLET_TYPE,
	PICKUP_MONEY_PURSE_TYPE,
	PICKUP_MONEY_DEP_BAG_TYPE,
	PICKUP_MONEY_MED_BAG_TYPE,
	PICKUP_MONEY_PAPER_BAG_TYPE,
	PICKUP_MONEY_SECURITY_CASE_TYPE,
	PICKUP_CUSTOM_SCRIPT_TYPE,
	PICKUP_HANDCUFF_KEY_TYPE,
	PICKUP_CAMERA_TYPE,
	PICKUP_PORTABLE_PACKAGE_TYPE,

	// Weapons
	PICKUP_WEAPON_PISTOL_TYPE,
	PICKUP_WEAPON_COMBATPISTOL_TYPE,
	PICKUP_WEAPON_PISTOL50_TYPE,
	PICKUP_WEAPON_APPISTOL_TYPE,
	PICKUP_WEAPON_MICROSMG_TYPE,
	PICKUP_WEAPON_SMG_TYPE,
	PICKUP_WEAPON_ASSAULTSMG_TYPE,
	PICKUP_WEAPON_ASSAULTRIFLE_TYPE,
	PICKUP_WEAPON_CARBINERIFLE_TYPE,
	PICKUP_WEAPON_HEAVYRIFLE_TYPE,
	PICKUP_WEAPON_ADVANCEDRIFLE_TYPE,
	PICKUP_WEAPON_MG_TYPE,
	PICKUP_WEAPON_COMBATMG_TYPE,
	PICKUP_WEAPON_ASSAULTMG_TYPE,
	PICKUP_WEAPON_PUMPSHOTGUN_TYPE,
	PICKUP_WEAPON_SAWNOFFSHOTGUN_TYPE,
	PICKUP_WEAPON_BULLPUPSHOTGUN_TYPE,
	PICKUP_WEAPON_ASSAULTSHOTGUN_TYPE,
	PICKUP_WEAPON_SNIPERRIFLE_TYPE,
	PICKUP_WEAPON_ASSAULTSNIPER_TYPE,
	PICKUP_WEAPON_HEAVYSNIPER_TYPE,
	PICKUP_WEAPON_GRENADELAUNCHER_TYPE,
	PICKUP_WEAPON_RPG_TYPE,
	PICKUP_WEAPON_MINIGUN_TYPE,
	PICKUP_WEAPON_GRENADE_TYPE,
	PICKUP_WEAPON_SMOKEGRENADE_TYPE,
	PICKUP_WEAPON_STICKYBOMB_TYPE,
	PICKUP_WEAPON_MOLOTOV_TYPE,
	PICKUP_WEAPON_STUNGUN_TYPE,
	PICKUP_WEAPON_RUBBERGUN_TYPE,
	PICKUP_WEAPON_PROGRAMMABLEAR_TYPE,
	PICKUP_WEAPON_FIREEXTINGUISHER_TYPE,
	PICKUP_WEAPON_PETROLCAN_TYPE,
	PICKUP_WEAPON_LOUDHAILER_TYPE,
#if LASSO_WEAPON_EXISTS
	PICKUP_WEAPON_LASSO_TYPE,
#endif
	PICKUP_WEAPON_KNIFE_TYPE,
	PICKUP_WEAPON_NIGHTSTICK_TYPE,
	PICKUP_WEAPON_HAMMER_TYPE,
	PICKUP_WEAPON_BAT_TYPE,
	PICKUP_WEAPON_GOLFCLUB_TYPE,
	PICKUP_WEAPON_UNUSED_TYPE,

	// vehicle pickups
	PICKUP_VEHICLE_HEALTH_STANDARD_TYPE,
	PICKUP_VEHICLE_ARMOUR_STANDARD_TYPE,
	PICKUP_VEHICLE_WEAPON_PISTOL_TYPE,
	PICKUP_VEHICLE_WEAPON_COMBATPISTOL_TYPE,
	PICKUP_VEHICLE_WEAPON_PISTOL50_TYPE,
	PICKUP_VEHICLE_WEAPON_APPISTOL_TYPE,
	PICKUP_VEHICLE_WEAPON_MICROSMG_TYPE,
	PICKUP_VEHICLE_WEAPON_SMG_TYPE,
	PICKUP_VEHICLE_WEAPON_SAWNOFF_TYPE,
	PICKUP_VEHICLE_WEAPON_ASSAULTSMG_TYPE,
	PICKUP_VEHICLE_WEAPON_GRENADE_TYPE,
	PICKUP_VEHICLE_WEAPON_SMOKEGRENADE_TYPE,
	PICKUP_VEHICLE_WEAPON_STICKYBOMB_TYPE,
	PICKUP_VEHICLE_WEAPON_MOLOTOV_TYPE,

	PICKUP_AMMO_BULLET_MP_TYPE,
	PICKUP_AMMO_MISSILE_MP_TYPE,

	PICKUP_PORTABLE_CRATE_UNFIXED_TYPE,
	PICKUP_VEHICLE_CUSTOM_SCRIPT_TYPE,
	PICKUP_SUBMARINE_TYPE,

	PICKUP_WEAPON_CROWBAR_TYPE,
	PICKUP_HEALTH_SNACK_TYPE,

	PICKUP_PARACHUTE_TYPE,

	PICKUP_AMMO_PISTOL_TYPE,
	PICKUP_AMMO_SMG_TYPE,
	PICKUP_AMMO_RIFLE_TYPE,
	PICKUP_AMMO_MG_TYPE,
	PICKUP_AMMO_SHOTGUN_TYPE,
	PICKUP_AMMO_SNIPER_TYPE,
	PICKUP_AMMO_GRENADELAUNCHER_TYPE,
	PICKUP_AMMO_RPG_TYPE,
	PICKUP_AMMO_MINIGUN_TYPE,
	PICKUP_AMMO_RUBBERGUN_TYPE,

	NUM_PICKUP_TYPES
};

#endif // PICKUP_IDS_H

