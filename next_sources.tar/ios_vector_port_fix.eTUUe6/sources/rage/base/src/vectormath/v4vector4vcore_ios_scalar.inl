#ifndef VECTORMATH_V4VECTOR4VCORE_IOS_SCALAR_INL
#define VECTORMATH_V4VECTOR4VCORE_IOS_SCALAR_INL

#include <cmath>
#include <cstdint>
#include <cstring>

namespace rage {
namespace Vec {

static __forceinline float IOSMaskFloat(bool b)
{
    uint32_t u = b ? 0xffffffffu : 0u;
    float f;
    memcpy(&f, &u, sizeof(f));
    return f;
}

__forceinline Vector_4V_Out V4IsTrueV(bool b)
{
    const float m = IOSMaskFloat(b);
    return Vector_4V(m, m, m, m);
}

__forceinline Vector_4V_Out V4IsNonZeroV(u32 b)
{
    return V4IsTrueV(b != 0);
}

__forceinline Vector_4V_Out V4IsZeroV(Vector_4V_In v)
{
    return Vector_4V(
        IOSMaskFloat(v.x == 0.0f),
        IOSMaskFloat(v.y == 0.0f),
        IOSMaskFloat(v.z == 0.0f),
        IOSMaskFloat(v.w == 0.0f));
}

__forceinline unsigned int V2IsFiniteAll(Vector_4V_In v)
{
    return std::isfinite(v.x) && std::isfinite(v.y);
}

__forceinline unsigned int V3IsFiniteAll(Vector_4V_In v)
{
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
}

__forceinline unsigned int V4IsFiniteAll(Vector_4V_In v)
{
    return std::isfinite(v.x) && std::isfinite(v.y) &&
           std::isfinite(v.z) && std::isfinite(v.w);
}

__forceinline Vector_4V_Out V4PowPrecise(Vector_4V_In x, Vector_4V_In y)
{
    return Vector_4V(
        powf(x.x, y.x),
        powf(x.y, y.y),
        powf(x.z, y.z),
        powf(x.w, y.w));
}

__forceinline Vector_4V_Out V3RotateAboutXAxis(
    Vector_4V_In v, Vector_4V_In s, Vector_4V_In c)
{
    const float sv = s.x, cv = c.x;
    return Vector_4V(v.x, v.y*cv - v.z*sv, v.y*sv + v.z*cv, v.w);
}

__forceinline Vector_4V_Out V3RotateAboutYAxis(
    Vector_4V_In v, Vector_4V_In s, Vector_4V_In c)
{
    const float sv = s.x, cv = c.x;
    return Vector_4V(v.x*cv + v.z*sv, v.y, -v.x*sv + v.z*cv, v.w);
}

__forceinline Vector_4V_Out V3RotateAboutZAxis(
    Vector_4V_In v, Vector_4V_In s, Vector_4V_In c)
{
    const float sv = s.x, cv = c.x;
    return Vector_4V(v.x*cv - v.y*sv, v.x*sv + v.y*cv, v.z, v.w);
}

__forceinline Vector_4V_Out V3RotateAboutXAxis(
    Vector_4V_In v, Vector_4V_In radians)
{
    const float s = sinf(radians.x);
    const float c = cosf(radians.x);
    return V3RotateAboutXAxis(v, Vector_4V(s,s,s,s), Vector_4V(c,c,c,c));
}

__forceinline Vector_4V_Out V3RotateAboutYAxis(
    Vector_4V_In v, Vector_4V_In radians)
{
    const float s = sinf(radians.x);
    const float c = cosf(radians.x);
    return V3RotateAboutYAxis(v, Vector_4V(s,s,s,s), Vector_4V(c,c,c,c));
}

__forceinline Vector_4V_Out V3RotateAboutZAxis(
    Vector_4V_In v, Vector_4V_In radians)
{
    const float s = sinf(radians.x);
    const float c = cosf(radians.x);
    return V3RotateAboutZAxis(v, Vector_4V(s,s,s,s), Vector_4V(c,c,c,c));
}

} // namespace Vec
} // namespace rage

#endif
