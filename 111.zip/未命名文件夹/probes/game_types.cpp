#include <type_traits>
#ifndef INC_GAME_CONFIG_H_
#error original game_config.h not loaded
#endif
#ifndef INC_BASETYPES_H_
#error original game/basetypes.h not loaded
#endif
static_assert(sizeof(u32)==4 && sizeof(u64)==8,"game scalar widths");
